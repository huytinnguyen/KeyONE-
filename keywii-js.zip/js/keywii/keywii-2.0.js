//<script>
/** namespace declaration */
Jpackage({
	name		: "ng.wii",
	/*
	Imports		: {
		//javascript : '/keyjs/jclass/jclass.js.jsp'
	},*/
	alias		: "keywii",
	xmlns		: {
		prefix	: "wii",
		uri		: "http://www.keyonesoft.com/js/keywii"
	},
	//uri			: "http://www.keyonesoft.com/js/keywii",
	title		: "KeyONE WIdget library for Internet",		
	version		: 2.0,
	"@company"	: "NGUYEN S.n.c.",
	"@copyright": "Copyright(C) 2006-2017, by NGUYEN S.n.c.",
	"@license"	: "MIT-style license"
});
/***
 * alias of package
 */
wii=ng.wii;
kwii=ng.wii;
// defines OverText as tag.
ng.wii.tag("over-text",OverText);
//</script>