Locale.define('it-IT','keywii',{
	REFERENCE_NOT_VALID: "il valore di riferimento: {.} non e' valido!",
	button_annull: "annulla",
	button_ok: "OK",
	confirm_window_title: "conferma"
});