/***
 * KeyWII - Keyone Widget For Internet
 * @copyright	Copyright (c) 2003-2017, NGUYEN S.n.c.
 * @license		MIT-style license
 */
Jpackage({
name:"ng.wii",
"@company"	: "NGUYEN S.n.c.",
"@copyright": "Copyright(C) 2006-2017 by NGUYEN S.n.c.",
"@license"	: "MIT-style license",

tags:{
	'grid'	: 'Grid'
	//,'scrollable-table' : 'ScrollTable'
},
/***
 * the scrollable table widget.
 */
/*
ScrollTable : new Class({
	Extends : ScrollableTable,
	options: {
	},
	initialize: function(el,options){
		this.parent(el,options);
	}
}),
*/
/***
 * Grid panel class.
 */
Grid: new Class({
	Extends		: ng.wii.Widget,
	rows		: null,
	header		: null,
	columns		: null,
	selected	: null,
	options		: {
		'class'		: 'wii-grid-panel',	
		facets: {
			header		: '.wii-header,THEAD',
			column		: {'class': 'wii-column',query:'TR TH', plurial: true},
			body		: '.wii-body,TBODY,UL',
			row			: {'class': 'wii-grid-row',   query: 'TR,LI', plurial: true},
			cell		: {'class': 'wii-cell', query: 'TD,SPAN', plurial: true},
			footer		: '.wii-footer',
			selected	: {'class': 'selected', plurial: true},
			hover		: {'class': 'hover', plurial:true},
			rowTemplate	: '.wii-row-template'
		},
		template		: {
			content		: null,
			header		: null,
			row			: null
		}
	},
	/***
	 * costruisce il grid-panel
	 */
	initialize : function key$wii$Grid (el, options) {
		//var me=this;
		//this.addEvent("load",function(){
			//me.render();
		//});
		this.parent(el,options);
		if(this.options['class'] && !this.getElement().hasClass(this.options['class']))
			this.getElement().addClass(this.options['class']);
		if(!this.getLoader())
			this.render();
		this.getElement().addEvent("keydown",
			function(ev){
				this.onkeydown(ev);
			}.bind(this));
		var rowTpl;
		if((rowTpl=this.getFacet('rowTemplate'))!=null){
			this.rowTemplate=rowTpl;
			var body=rowTpl.getParent();
			body.removeChild(rowTpl);
		}
	},
	/***
	 * focus the grid panel.
	 */
	setFocus: function(delay) {
		var me=this;
		if(!me.selected){
			if(me.focusTimeout){
				clearTimeout(me.focusTimeout);
				me.focusTimeout=0;
			}
			var focusFunc=(function() {
				me.next(null);
				if(me.selected){
					var fields=me.selected.getElements("INPUT,TEXTAREA,SELECT");
					if(fields[0])
						try{fields[0].focus();}catch(e){}
						else
							try{me.getElement().focus();}catch(e){}
				}
			});
			if(delay)
				me.focusTimeout=focusFunc.delay(delay);
			else
				focusFunc();
		}
	},
	/***
	 * 
	 * @returns
	 */
	getRows: function(){
		//if(!this.rows)
		this.rows= this.getFacets('row',this.getContent());
		return this.rows;
	},
	/***
	 * 
	 */
	getCells: function(row){
		return this.getFacets("cell",row);
	},
	/***
	 * render the grid.
	 */
	render: function(html) {
		this.parent(html);
		this.rows=null;
		var body=this.getContent();
		var self=this;
		if(body){
			// render rows
			var rows=this.getRows(); 
			// add rows events
			for(var i=0; rows && i< rows.length; i++){
				var row=$(rows[i]);
				row.addEvent("click",function(ev){ 
					this.removeClass(self.options.facets.hover['class']);
					self.selectRow(this); 
				});
				row.addEvent("keydown", function(ev){
					this.onkeydown(ev);
				}.bind(this));				
				row.addEvent("mouseover", function(ev) { 
					if(!this.hasClass(self.options.facets.selected['class']))
						this.addClass(self.options.facets.hover['class']); 
				});
				row.addEvent("mouseout", function(ev) { 
					this.removeClass(self.options.facets.hover['class']); 
				});				
			}			
		}		
		this.selected=null;
	},
	/***
	 * on keydown handle
	 */
	onkeydown: function(ev){
		var target=ev.target;
		switch(ev.key){
		case "up":
			ev.stop();
			this.previous(ev);
			break;
		case "down":
			ev.stop();
			if(this.popup && ((this.isDataInput && this.isDataInput(target)) || this.popup.options.opener.target==target)){
				//ev.stop();
				this.popup.setFocus();
			}else
				this.next(ev);
			break;
		}
	},
	/***
	 * @private
	 */
	focusInput: function(row,inputPath){
		if(inputPath){
			var input;
			var fields=row.getElements("INPUT,SELECT,TEXTAREA");
			for(var j=0;j<fields.length;j++){
				e=fields[j];
				if(e.name == inputPath){
					input=e;
					break;
				}
			}
			if(input)
				try {input.focus();}catch(ex){}
		}					
	},
	/***
	 * 
	 */
	previous: function(ev) {
		var target=ev && ev.target;
		this.getRows();
		if(!this.selected){
			this.selectRow(this.rows[0]);
		}else{
			var i = this.rows.indexOf(this.selected);
			if(i>0){
				var cells = this.getCells(this.selected);
				var col=-1;
				for(var c=0; c<cells.length; c++){
					if(cells[c].contains(target)){
						col=c;
						break;
					}
				}				
				this.selectRow(this.rows[--i]);
				//this.focusInput(this.selected,inputPath);
				if(col>=0){
					cells = this.getCells(this.selected);
					var input = cells[col].getElement(target.tagName);
					if(input && ["INPUT","SELECT","TEXTAREA"].indexOf(input.tagName)>=0)
						input.focus();
				}
				var previous=this.selected;
				for(var i=0; i<2; i++){
					if(previous.getPrevious())
						previous=previous.getPrevious();
					else
						break;
				}
				var container=this.selected.getParent(".wii-grid");				
				if((container.getPosition().y) > 
						  (this.selected.getPosition().y))				
				this.getScroller().toElement(previous);
			}
		}
	},
	getScroller: function(){
		if(!this.scroller)
			this.scroller=new Fx.Scroll(this.selected.getParent(".wii-grid"),{duration:'short'});
		//new Fx.Scroll(parent).toElement(this.selected);
		return this.scroller;
	},
	/***
	 * 
	 * @param el
	 * @returns {Boolean}
	 */
	isDataInput: function(el){
		return el && el.tagName=='INPUT';
	},
	/***
	 * 
	 */
	next: function(ev){
		var target=ev && ev.target;
		this.getRows();
		if(!this.selected){
			this.selectRow(this.rows[0]);
		}else{
			var i=this.rows.indexOf(this.selected);
			if(i<(this.rows.length-1)){
				/*
				var inputPath;
				if(target && this.isDataInput && this.isDataInput(target)){
					inputPath=target.name.replace("["+i+"]","["+(i+1)+"]");
				}*/
				var cells = this.getCells(this.selected);
				var col=-1;
				for(var c=0; c<cells.length; c++){
					if(cells[c].contains(target)){
						col=c;
						break;
					}
				}
				this.selectRow(this.rows[++i]);
				//this.focusInput(this.selected,inputPath);
				if(col>=0){
					cells = this.getCells(this.selected);
					var input = cells[col].getElement(target.tagName);
					if(input && ["INPUT","SELECT","TEXTAREA"].indexOf(input.tagName)>=0)
						input.focus();
				}
				var next=this.selected;
				for(var i=8; i>=0; i--){
					if(next.getPrevious())
						next=next.getPrevious();
					else
						break;
				}
				var container=this.selected.getParent(".wii-grid");
				if((container.getSize().y+container.getPosition().y) < 
					  (this.selected.getPosition().y+(this.selected.getSize().y*1)))
					this.getScroller().toElement(next);
				
			}
		}
	},
	/***
	 * select the passed row.
	 */
	selectRow: function(row) {
		if(typeof row == "number"){
			var i=row;
			if(i<this.getRows().length){
				row=this.getRows()[i];
			}else
				return this;
		}
			
		if(this.selected){
			this.selected.removeClass(this.options.facets.selected['class']);
		}
		if(row){
		  this.selected=row;
		  this.selected.addClass(this.options.facets.selected['class']);
		}
	},
	/***
	 * return the selected row.
	 */
	getSelected: function() {
		var grid=this.getContent();
		if(grid){
		    if(this.getData && this.getData()){
		    	var selected=this.getFacets("selected",grid)[0];
		    	var rows=grid.getRows();
		    	var result=[];
		    	var i;
		    	for(var j=0; j<selected.length; j++){
		    		if((i=rows.indexOf(selected[j]))>=0){
		    			result.push(this.getData()[i]);
		    		}
		    	}
		    	return result;
		    }else
				return this.getFacets("selected")[0];
		}else
			return [];
	}	
})
});
ng.wii.addTag({name:'grid', tagClass:ng.wii.Grid});
//