/***
 * KeyWII - KeyOne WIdget for Internet
 * @copyright	Copyright (c) 2003-2017, NGUYEN S.n.c.
 * @license		MIT-style license
 */
Jpackage({
name: "ng.wii",
"@company"	: "NGUYEN S.n.c.",
"@copyright": "Copyright(C) 2006-2017 by NGUYEN S.n.c.",
"@license"	: "MIT-style license",

tags: {
	'lookup' : 'Lookup'
},
/***
 * Lookup widget
 */
Lookup : new Class({
	Extends		: ng.wii.Widget,
	queryValue	: "",
	options		: (ng.wii.LookupOptions={
		model			: null, // data layout model : 
								//   {'attribute-path': {title: 'title', type: 'type-name',format:'format',width:'width%'... },...}
		client			: null, // web-client to get the data from server.
		request			: null, // ajax request to get data
		autoExpand		: true, // auto expand the input value.
		delay			: 600,  // query execution delay 
		minLength		: 0,
		selectMode		: 'pick',
		editable 		: true,
		selectedQuery	: '.selected',		
		filterSubset	: false,
		queryAll		: false,
		wildcard		: "*",
		width			: 'auto',
		fieldSelector	: ['span', 0],
		entitySelector 	: "TR", 	
		postData		: null,
		postVar			: null,
		optional		: true,
		dataValidators 	: "",
		'class'			: 'wii-lookup-choices',
		selectEvent		: "click",
		// element reference or element-id or element-classes of the elements 
	    // which will open / close the lookup box		
		attach			: {
			element		: null,
			position		: "upperRight",
			offset		: {x: 0, y: -1},
			event		: "click",	// event to open the lookup box
			fixed		: false
		},
		event			: "click",  // event to open the lookup box
		windowOptions	: {
			type		: ng.wii.Box
			,zIndex		: 3000
			,content 	: 'Loading ...'
			,pointer	: ['left', 3]
			,offset 	: {x:-1, y: -5}
			,setStyles	: {content	:{cursor:'pointer',overflow:'auto','max-height':'300px'}}
			,addClass	: {content	:"wii-grid" }
			,classOptions: {
				content : {
					'wii-grid': { 
						load	: {}
					} 
				}
			}
			,template	: {
				url				: null   // url to get layout template from server
				,content		: "<div class='wii-body'>{rows}</div>"
				,row			: "<li class='wii-grid-row'><span>{.}</span></li>"
				,fieldSelector 	: ['span', 0]
				// layout model template
				,model			: {
			    	content			: ['<table><thead><tr>{columns}<tr></thead>',
			    	       			   '<tbody>{rowsTpl}</tbody></table>']
			    	,column			: '<th>{title}</th>'
			    	,row			: '<tr class=wii-grid-row >{fieldsTpl}</tr>'
					,field			: '<td>{fieldTpl}</td>'
					,fieldSelector	: ['td',0]
				}	
			}			
		},
		onRequest	: function(element, data, queryValue){},
		onSelect	: function(element, object){}
	}),
	/***
	 * 
	 * @param options
	 */
	initialize : function(element,options){
		options = options || {};
		Object.append(this.options.attach,ng.wii.LookupOptions.attach);
		this.options.windowOptions.template = 
			  Object.merge(this.options.windowOptions.template, 
					  	   ng.wii.LookupOptions.windowOptions.template);
		
		if(options.client && options.client.constructor == Object){
			options.client = new Jclient(options.client);
		}else if(options.request && options.request.constructor == Object){
			options.request = new Request(options.request);
		}
		options.controller = options.client || options.request;
		this.parent(element, options);	
		if(!this.options.postVar){
			var names=this.element.name.split(".");
			this.options.postVar=names[names.length-1];
		}
		this.addEvent("onRequest", this.onrequest.bind(this));
	},
	/***
	 * build the layout template by data model.
	 */
	setupLayoutModel: function(){
		if(this.options.model){
			for(var field in this.options.model){
				if(typeof this.options.model[field] == "string"){
					this.options.model[field]={title: this.options.model[field]};
				}
			}
			if(this.options.windowOptions.template.url){
				var me=this;
				var req=new Request.JSON({
					async	: true,
					method	: "get",
					url		: me.options.windowOptions.template.url,
					data	: {model: JSON.encode(this.options.model)},
					onSuccess: (function(responseJSON, responseText){
						if(responseJSON){
							this.options.windowOptions.template.content=responseJSON.content;
							this.options.windowOptions.template.row=responseJSON.row;
							this.options.windowOptions.template.fieldSelector=responseJSON.fieldSelector;
							this.options.fieldSelector = this.options.windowOptions.template.fieldSelector;
						}else{
							alert(responseText);
						}
					}).bind(me)
				});
				req.send();
			}else{
				var modelTpl=this.options.windowOptions.template.model;
				var columnTpl=new Jtemplate(modelTpl.column);
				var fieldTpl=new Jtemplate(modelTpl.field);
				var rowTpl=new Jtemplate(modelTpl.row);			
				var columns="", fields="";
				for(var name in this.options.model){
					var fieldModel = this.options.model[name];
					columns += columnTpl.apply(fieldModel);
					fields += fieldTpl.apply({fieldTpl: "{"+name+"}"});
				}
				var row=rowTpl.apply({fieldsTpl:fields});
				var contentTpl = new Jtemplate(modelTpl.content);
				var content= new Jtemplate(contentTpl).apply({columns: columns, rowsTpl: "{rows}"});
				// set layout template info
				this.options.windowOptions.template.content=content;
				this.options.windowOptions.template.row=row;	
				this.options.windowOptions.template.fieldSelector = modelTpl.fieldSelector;
				this.options.fieldSelector = this.options.windowOptions.template.fieldSelector || this.options.fieldSelector;
			}
		}
	},
	/***
	 * setup the lookup.
	 */
	setup : function(){
		this.parent();
		this.setupLayoutModel();
	},
	/***
	 * add listeners.
	 */
	setupListeners: function(){
		this.parent();
		this.element.autocomplete="off";
		this.element.addEvents({
			//"click"	: this.openLink.bind(this),
			"keydown"	: this.onKeypress.bind(this),
			"keyup"		: this.onquery.bind(this)
		});
		if(this.options.attach.element){
			this.attachTo();
		}
		if(this.options.selectEvent == "click")
			this.element.addEvents({
				"blur" 		: this.closeLink.bind(this)
			});
		if(this.controller){
			this.controller.addEvent("success",this.queryResponse.bind(this));	
			this.controller.addEvent("failure",this.onQueryFailure.bind(this));			
		}
	},
	/****
	 * attach the specified toggler element to the open of lookup box. 
	 */
	attachTo: function(){
		if(this.options.attach.element){
			var toggler;
			var parent = this.element.getParent();
			if(!$(this.options.attach.element)){
				var html = this.options.attach.element;
				var tpl = new Jtemplate(html);
				var div = new Element("div");
				toggler = div.set("html",tpl.apply(this.options)).getFirst();
				parent.grab(toggler);	
				this.attach = toggler;
				//this.hideAttach=true;
			}else{
				if($(this.options.attach.element).getStyle("visibility")=="hidden"
					|| $(this.options.attach.element).getStyle("display")=="none")
				{
					toggler = $(this.options.attach.element).clone();
					toggler.setStyle("visibility","visible");
					toggler.setStyle("display","");
				}else
					toggler = $(this.options.attach.element);
				toggler.setStyle("visibility","");
				parent.grab(toggler);
				this.attach = toggler;
				if(this.attach.getStyle("position")!="absolute")
					this.options.attach.fixed=true;
			}
			if(!this.options.attach.fixed){
				this.attach.hide();				
				this.element.addEvent("focus",this.showAttach.bind(this));
				//this.element.addEvent("blur",(function(){this.attach.hide();}).bind(this));
				$(document.body).addEvent("click",(function(ev){
					if(ev.target!=this.attach && ev.target!=this.element)
						this.attach.hide();
				}).bind(this));								
			}
			this.attach.addEvent(this.options.attach.event,this.toggleLink.bind(this));
		}
	},
	/***
	 * show attach element
	 */
	showAttach: function() {
		this.attach.setStyle("position","absolute");	
		this.attach.show();
		var pos = {relativeTo: this.element};
		Object.append(pos,this.options.attach);
		pos.element = null;
		this.attach.position(pos);							
	},
	/***
	 * 
	 */
	toggleLink: function(ev){
		ev.stop();
		//var link=this.buildLink(ev);
		if(!this.link || this.link.element.getStyle("display")=="none"){
			this.openLink(ev);
		}else{
			this.closeLink(ev);
		}
	},
	/***
	 * returns true if the lookup is local.
	 * @returns {Boolean}
	 */
	isLocal: function(){
		return this.options.data; 
	},
	/***
	 * 
	 * @param data
	 */
	markQueryValue:function(queryValue){
		var data=Jobject.splat(this.getData());
		var pattern=new RegExp((this.options.filterSubset?'':'^')+queryValue,"i");
		var index=-1;
		var num=0;
		if(queryValue.length>0)
		for(var i=0; i<data.length;i++){
			var value;
			if(typeof data[i] == "string"){
				value=data[i];
			}else {
				value=data[i][this.options.postVar];
			}
			if(pattern.test(value)){
				num++;
				if(index<0){
					index=i;
					this.getSelector().selectRow(index);
				}
			}
		}
		if(num==1 && this.options.autoExpand){
			this.select();
		}else if(num==0){
			this.getSelector().selectRow(null);
		}
		
	},
	/***
	 * query
	 */
	query: function(ev,queryValue){
		this.openLink(ev,true);
		var wildcard = this.options.wildcard;
		queryValue = /*queryValue ||*/ this.element.value;
		this.queryValue=queryValue;
		var data = {};
		Object.append(data,this.options.postData);
		this.applyEntityData(data);
		if(this.options.postData && this.options.postData[this.options.postVar]){
			if (queryValue != ""){
			  var tpl = new Jtemplate(this.options.postData[this.options.postVar]);
			  var ent = {};
			  ent[this.options.postVar] = queryValue;
			  var value=tpl.apply(ent);
			  // @TODO
			  if(value != data[this.options.postVar]){
				if(value && value.test(/(^<>)|(^\!=)/))
					this.element.value="";
			  }
			  var doLike=true;
			  var op="";
			  if(queryValue.test(/(^<)|(^>)|(^=)|(^\!)|(^=)|(^#in[ ]*$)|(^#not[ ]*([ ]+in[ ]*)?$)/i))
				  doLike=false;
			  if(doLike)
			    queryValue = (this.options.filterSubset?wildcard:'')+queryValue+wildcard;
			  if(data[this.options.postVar].test(/[ ]+#or[ ]+/))
			    queryValue = "( "+data[this.options.postVar]+" )" + " #and " +op+queryValue;
			  else
				queryValue = data[this.options.postVar] +" #and "+ op+queryValue;  
			}else{
			  queryValue=data[this.options.postVar];	
			}
		}else if(this.controller){
		    if(!queryValue.test(/(^<)|(^>)|(^=)|(^\!)|(^=)|(^#in[ ]*$)|(^#not[ ]*([ ]+in[ ]*)?$)/i))
			  queryValue = (this.options.filterSubset?wildcard:'')+queryValue+wildcard;
		}
		if(this.isLocal()){
			this.markQueryValue(this.queryValue);
		}else if(this.controller){
			if(!this.options.queryAll)
				data[this.options.postVar] = queryValue;
			else 
				data[this.options.postVar] = "";
			this.fireEvent('onRequest', [this,this.element, data, queryValue]);
			this.controller.send(data);	
		}else if(this.getWinContentLoader()){
			//if(queryValue!="" || !data[this.options.postVar])
			if(!queryValue.test(/(^<)|(^>)|(^=)|(^\!)|(^=)|(^#in[ ]*$)|(^#not[ ]*([ ]+in[ ]*)?$)/i))
			    data[this.options.postVar] = (this.options.filterSubset?wildcard:'')+queryValue+wildcard;
			else
				data[this.options.postVar] = queryValue;
			this.fireEvent('onRequest', [this, this.element, data, queryValue]);
			this.getSelector().load(data);
		}
	},
	/***
	 * returns the entity of the specified input element.
	 */
	getEntity: function(){
		var entity = Jelement.toData(this.element.getParent(this.options.entitySelector),true);
		if(entity && /^[0-9]+$/.test(Object.keys(entity)[0])){
			entity=entity[Object.keys(entity)[0]];
		}	
		return entity;
	},
	/***
	 * handles the query data.
	 */
	onrequest: function(lookup, element, data, queryValue){
		//this.applyEntityData(data);
	},
	/***
	 * apply entity data to query data.
	 * @param data query data.
	 */
	applyEntityData: function(data){
		var entity = this.getEntity();
		if(entity!=null){
			for(var p in data){
				if(data[p] && typeof data[p] == "string" && /\{[^\}]+\}/.test(data[p])){
				  var tpl = new Jtemplate(data[p]);
				  var value = tpl.apply(entity);
				  if(value && JsqlExpr.CompareOperators.indexOf(value) < 0)
					  data[p] = value;
				}
			}
		}		
	},
	/****
	 * 
	 */
	getWinContentLoader: function(){
		if(this.link){
			if(this.getSelector().getLoader())
				return this.getSelector().getLoader();
		}
	},
	/***
	 * 
	 */
	queryResponse: function(response,text){
		if(instanceOf(this.controller,Request)){
			if(!response){
				response = JSON.decode(text);
			}
			this.controller.response=response;			
		}
		if(this.controller && Jclass.instanceOf(this.controller,Jdataset) )
		{
		  var isstring = this.controller.getItems() && this.controller.getItems().length>0 
						 && typeof this.controller.getItems()[0] == "string";
		  if(this.options.optional!='false' && !isstring){
			var newent = {};
			this.controller.getItems().unshift(newent);
		  }
		}
		if(this.controller && Jclass.instanceOf(this.controller,Jdataset) 
			&& isstring) //this.controller.options.componentType==String)
		{
			this.options.data=this.controller.getItems();
		}	

		this.update(this.getData());
		this.markQueryValue(this.queryValue);
	},
	/***
	 * 
	 * @param xhr
	 */
	onQueryFailure: function(xhr){
		
	},
	/***
	 * open the link window.
	 * @param ev
	 * @returns {___anonymous105_1132}
	 */
	openLink: function(ev,noQuery){
		var open = this.link;
		var link = this.buildLink(ev);
		if(link && !link.isOpen){
		  link.open();
		  link.raise();
		  if(!open)
			link.content.addEvent(this.options.selectEvent,this.select.bind(this));
		  if(!noQuery){
		    if(this.controller /*&& !(this.getData() && this.getData().length>0)*/) {
		    	this.query(null,this.element.value);
		    }else if(!this.getWinContentLoader()){ 
			    this.update(this.getData());
		    }else{
		    	if(!noQuery)
		    		this.query(ev);
		    }
		  }
		}
		return this;
	},
	/**
	 * close the open link window.
	 */
	closeLink: function(ev){
		if(this.link && this.linkIsOpen){
			this.link.close();
			//this.linkIsOpen=false;
		}
	},
	/***
	 * 
	 * @returns
	 */
	getData: function(){
		if(this.isLocal()){
			return this.options.data;
		}else if(this.controller && !instanceOf(this.controller,Request) && this.controller.getItems){
			return this.controller.getItems();
		}else if(this.controller){
			var data = this.controller.response;
			if(!(data instanceof Array)){
				for(var p in data){
					if(data[p] instanceof Array){
						data=data[p];
						break;
					}	
				}
			}
			return data;
		}
	},
	/***
	 * 
	 */
	update: function(data){
	  if(data){
		var windowOptions=this.options.windowOptions;
		if(windowOptions.template.row){
			var rowsHtml="";
			var rowTpl=new Jtemplate(windowOptions.template.row);
			rowTpl.defaultValue = "&nbsp;"
			data=Jobject.splat(data);
			data.each(function(object){
				var record=object; 
				rowsHtml += rowTpl.apply(record);
			});
			if(windowOptions.template.content){
				var bodyTpl = new Jtemplate(windowOptions.template.content);
				rowsHtml = bodyTpl.apply({rows:rowsHtml});
			}
			this.getSelector().render(rowsHtml);
			windowOptions.template.content && 
			  !this.link.content.getFirst().hasClass(this.options['class']) &&
				 this.link.content.getFirst().addClass(this.options['class']);
		}	
	  }
	},
	/***
	 * 
	 * @param ev
	 */
	onKeypress: function(ev){
		var target=ev.target;
		if(!ev.shift && !ev.control && !ev.alt && !ev.meta){
			switch(ev.key){
			case "up":
				this.previous && this.previous(ev);
				break;
			case "down":
				this.next && this.next(ev);
				break;
			case 'enter':
				if(this.link && this.link.isOpen){
					this.select(ev);
				}
			case 'left': 
			case 'right':
			case 'space':
			case 'backspace': 
			case 'delete': 
			case 'esc':				
			default:
				//if(ev.key.length==1 || ev.key=='backspace' || ev.key=='space' || ev.key=='delete'){
				//}
				break;
			}
		}
	},
	/***
	 * on query event handler
	 * @param ev
	 */
	onquery: function(ev){
		switch(ev.key){
		case 'left': 
		case 'right':
		case 'space':
		case 'backspace': 
		case 'delete': 
		case 'esc':				
		default:
			if(ev.key.length==1 || ev.key=='backspace' || ev.key=='space' || ev.key=='delete'){
				if(ev.type=="keyup"){
					if(this.delayTimer)
						clearTimeout(this.delayTimer);	
					this.delayTimer = this.query.delay(this.options.delay,this,[ev]);
				}
			}		
		}
	},
	/***
	 * 
	 */
	clear: function(){
		
	},
	/***
	 * @private
	 * @returns
	 */
	getSelector: function(){
		var names = this.options.windowOptions.addClass.content ? this.options.windowOptions.addClass.content.split(" "):[];
		for(var i=0; i<names.length; i++){
		  var selector=this.link.content.retrieve(names[i]);
		  if(selector)
			  return selector;
		}
	},
	/***
	 * 
	 */
	getSelected: function(selector){
		selector = selector || this.getSelector();
		if(selector && selector.getSelected){
			return selector.getSelected();
		}else{
			var selecteds=this.link.content.getElements(this.options.selectedQuery);
			if(selecteds.length>0)
				return selecteds[0];
		}
	},
	/***
	 * select the choice
	 * @param ev
	 */
	select: function(ev,noclose){
		if(this.link){
			ev && ev.stop();
			var selected = this.getSelected();
			if(selected && !this.isReadonly()){
				var entity=this.storeChoice(selected);
				this.fireEvent("select",[this.element, selected, entity]);
				ev && this.element.retrieve("wii-input") && 
				  this.element.retrieve("wii-input").fireEvent("change",[ev,this.element]);
			}
			!noclose && ev && this.link.close();
		}
	},
	/***
	 * return true if the input element is read-only.
	 */
	isReadonly: function() {
		return this.element.readOnly;
	},
	/***
	 * validate the choice before store it.
	 */
	validateChoice: function(choice){
		var result=true;
		if(!choice) return result;
		var data={};
		Object.append(data,this.options.postData);
		this.applyEntityData(data);
		for(var p in choice){
			if(data[p] && data[p].test(/(^<>)|(^!=)|(^>)|(^<)/) && !data[p].test(/(^>=)|(^<=)/)){
				if(data[p].test(/^<>/) && "<>"+choice[p] == data[p]){
					result=false;
				}else if(data[p].test(/^!=/) && "!="+choice[p] == data[p]){
					result = false;
				}else if(data[p].test(/^>/) && ">"+choice[p] == data[p]){
					result = false;
				}else if(data[p].test(/^</) && "<"+choice[p] == data[p]){
					result = false;
				}
				if(!result) break;
			}
		}
		return result;
	},
	/***
	 * clear/reset the selected entity stored in relative inputs.
	 */
	resetChoice: function(entity,sameLevel,onlyHidden) {
		if(!this.element.name)
			return;
		var elNames=Jbean.parseName(this.element.name);
		entity = entity || {};
		var isString = this.getData() && typeof this.getData()[0] == "string";
		if(entity && !isString && 
		   ((/^[0-9]$/.test(elNames[0].text) && elNames.length > 2)
			|| (!/^[0-9]$/.test(elNames[0].text) && elNames.length>1)))
		{
			var steps=elNames;
			var parent=this.element.getParent();
			var path = steps.slice(0,steps.length-1).join("");
			var rootPath = steps.slice(0,steps.length-2).join("")+".";
			var path2;
			if(/^[0-9]+$/.test(steps[steps.length-2/*0*/].text))
				path2 = steps[steps.length-1].text;
			else
				path2 = steps[steps.length-2].text;
			var query="";
			query = "input,textarea,select";
			inputs = $(this.element.form).getElements(query);
			var self = this;
			//inputs.each(function(input){
			for(var i=0; i < inputs.length; i++){
				var inp, input = inputs[i];
				if(((!onlyHidden || input.type=="hidden") && input.name != self.element.name) 
					&& input.name && input.name.startsWith(path+"."))
				{
					var tokens = Jbean.parseName(input.name);
					if(!sameLevel || tokens.length == steps.length){
						var name=input.name.replace(path+".","");
						var val = Jobject.get(entity,name);
						val = (typeof val!='undefined'? val: "");
						input.value = val;
					}
				}
			}			
		}
	},
	/***
	 * store the selected entity into input elements of container entity.
	 */
	storeChoice: function(selected){
		var i=0, entity=null;
		var prev=selected.getPrevious();
		while(prev){
			i++;
			prev=prev.getPrevious();
		}
		var data=this.getData();
		var object=Jelement.toData(selected,true);
		var isString = false;
		if(data && data[0] && typeof data[0] != "string")
			entity=data[i];
		if(data && data[0] && typeof data[0] == "string"){
			entity = data[i];
			isString = true;
		}
		if(object && !entity)
			entity=object;
		var validated = this.validateChoice(entity);
		if(validated) {
			if(isString)
				this.element.value = entity;
			else	
				this.element.value=this.getValueOf(selected);
		}
		var elNames=Jbean.parseName(this.element.name);
		if(!isString && elNames.length>1 && entity
		   && elNames[elNames.length-1].text!=this.options.postVar
		   && entity[this.options.postVar])
		{
			this.element.value = entity[this.options.postVar];
			//return entity;
		}else
		if(entity && !isString && (
			(/^[0-9]$/.test(elNames[0].text) && elNames.length>2)
			|| (!/^[0-9]$/.test(elNames[0].text) && elNames.length>1)))
		{
			var steps=elNames;
			var parent=this.element.getParent();
			var path = steps.slice(0,steps.length-1).join("");
			var rootPath = steps.slice(0,steps.length-2).join("")+".";//steps[0]+".";
			if(this.options.postVar && this.element.name.endsWith(this.options.postVar)){
				var elName = this.element.name;
				path = elName.substring(0,elName.length-this.options.postVar.length-1);
			}
			var path2;
			if(/^[0-9]+$/.test(steps[steps.length-2/*0*/].text))
				path2 = steps[steps.length-1].text;
			else
				path2 = steps[steps.length-2].text;
			var query="";
			query = "input,textarea,select";
			inputs = $(this.element.form).getElements(query);
			inputs.each(function(input){
				var inp;
				if(input.name && input.name.startsWith(path+".")){
					var tokens = Jbean.parseName(input.name);
					var name=input.name.replace(path+".","");
					var val = Jobject.get(entity,name);
					val = (typeof val!='undefined'? val: "");
					input.value=(validated? val :"");
				}else{
				  if(input.name.startsWith(rootPath) && (inp=input.retrieve("wii-input"))){
					if(inp.options.linkedInput && inp.options.linkedInput.startsWith(path2+".")){
						var name = inp.options.linkedInput.substring((path2+".").length);
						var value = Jobject.get(entity,name);
						value = (typeof value != 'undefined'? value: "")
						input.value = (validated? value :"");
					}
				  }
				}
			});
		}
		var validator = $(this.element.form) && $(this.element.form).retrieve("validator")
		if(validator){
			validator.validateField(this.element,true);
		}
		return entity;
	},
	/***
	 * 
	 * @param object
	 * @returns
	 */
	getValueOf: function(object){
		if(object instanceof Element){
			var fieldPath=Jobject.splat(this.options.fieldSelector);
			var fields=object;
			for(var i=0; i<fieldPath.length; i++){
				if(typeof fieldPath[i]=="string")
					fields=fields.getElements(fieldPath[i]);
				else
					fields=fields[fieldPath[i]];
			}
			if(fields)
				return fields.get("html");
			else
				return "";
		}
		return object;
	},
	/***
	 * goto next choice.
	 * @param ev
	 */
	next: function(ev){
		ev && ev.stop();
		var wasOpen = this.link && this.link.isOpen;
		this.openLink();
		if(this.link){
			var selector=this.getSelector();
			wasOpen && selector.element.fireEvent("keydown",[ev]);
			this.select();
		}
	},
	/***
	 * goto previous choice.
	 * @param ev
	 */
	previous: function(ev){
		ev && ev.stop();
		var wasOpen = this.link && this.link.isOpen;

		this.openLink();		
		if(this.link){
			var selector=this.getSelector();
			wasOpen && selector.element.fireEvent("keydown",[ev]);			
			this.select();
		}

	},
	/***
	 * construct the link window for selection.
	 * @param ev
	 * @returns
	 */
	buildLink: function(ev){
		if(!this.link){
			var options=this.options.windowOptions || {};
			if(this.options.width == 'auto'){
				options.width = options.width || this.element.getStyle("width");
			}else{
				options.width = options.width || this.options.width;
			}
			options.target = options.target || this.element;
			//alert(this.options.windowOptions.type);
			var layoutType = this.options.windowOptions.type || ng.wii.Box;
			if(typeof layoutType=="string")
				layoutType=eval(layoutType);
			this.link = new layoutType(options);
		}
		return this.link;
	}
})

});
/***
 * enumeration lookup.
 * the specified url must return the following format of json:
 * { name : "(enumeration-type)", "values": ["(value1)","(value2)",...] }
 * for example:
 * {"name":"AlertTypeEnumeration","values":["RAIN","STORM","SNOW","WIND","ICE"]}
 */
ng.wii.DomainLookup = new Class({
	Extends		: ng.wii.Lookup,
	options		: {
		client	: {
			url	: null,
			componentType: String
			,binding: { items: 'Enumeration.values' }
		},
		windowOptions	: {
			//pointer	: ['left', 3]
			//,offset 	: {x: 0, y: -9}			
		}
	},
	/***
	 * Initialize the lookup.
	 */
	initialize	: function(element, options) {
		options = options || {};
		this.parent(element, options);
	}
});
ng.wii.addTag({
	name	: 'lookup-domain',
	tagClass: ng.wii.DomainLookup
});
/***
 * Lookup window
 */
ng.wii.LookupWindow = new Class({
	Extends		: ng.wii.Lookup,
	options 	: (ng.wii.LookupWindowOptions={
		selectEvent	: "dblclick",
		windowOptions	: {
			 type		: ng.wii.Window
			,closeOnBodyClick: false
			,closeOnElementClick : {
				
			}
			,overlay	: false
			,overlayStyles: {			// set the color and the opacity of the overlay
				color: 'black',
				opacity: 0.1
			}			
			,setStyles	: {content	: {cursor:'pointer',overflow:'auto','max-height':''}}			
			,addClass	: {content	:'wii-frame'}
			,classOptions: {
				content : {'wii-frame': {}}
			 }
			,contentLoad	: {
				encodeNestedData: true,
				url		: null,
				data	: {
				}
			 }			
		}
	}),
	initialize	: function(element, options) {
		this.options = Object.merge(this.options,ng.wii.LookupWindowOptions);
		this.parent(element,options);
		this.setupWindow();
		if(!this.options.windowOptions.closeOnBodyClick && !this.options.windowOptions.closeOnElementClick.element){
			var submitter = ng.wii.Frame.getSubmiter(null,this.element);
			var element=$(document.body);
			
			if(typeof submitter == "object")
				element = $(submitter.element);
			else
				element = $(submitter);
			var form = this.element.getParent("form");
			if(form && form!=element)
				element = form;
			
			this.options.windowOptions.closeOnElementClick={
				element: element	
			};
		}
	},
	/***
	 * setup the select window.
	 */
	setupWindow: function(){
		if(this.options.windowOptions.contentLoad && this.options.windowOptions.contentLoad.url){
			var contentClass = this.options.windowOptions.addClass.content;
			var opt=this.options.windowOptions.classOptions.content[contentClass];
			opt = opt || {};
			opt = Object.merge(opt,{load: this.options.windowOptions.contentLoad});
			this.options.windowOptions.contentLoad=null;
			//if(opt.load && opt.load.data)
				//this.applyEntityData(opt.load.data);
			this.options.windowOptions.classOptions.content[contentClass]=opt;
		}
	}
});
ng.wii.addTag({
	name	: 'lookup-popup',
	tagClass: ng.wii.LookupWindow
});
/***
 * http Link class.
 */

ng.wii.Link=new Class({
	Extends : ng.wii.Widget,
	options : {
		//attach	: null,
		src 	: null, // image src
		href 	: null, // href
		enctype : '',
		method  : 'POST',
		data	: null,
		target	: "_self",
		event 	: "click",
		validate: false,
		useQueryString: false,
		attach	: "<button class='wii-button-img'><img src='{src}' style='width:20px;height:20px;'></img></button>"
	},
	/***
	 * class initializer
	 */
	initialize: function(el,options){
		options = options || {};
		this.parent(el,options);
		if(['INPUT','SELECT','TEXTAREA'].indexOf(this.element.tagName)>=0){
			if(this.options.attach){
				if(!$(this.options.attach)){
					var html = this.options.attach;
					var tpl = new Jtemplate(html);
					var attach = new Element("DIV").set("html",tpl.apply(this.options)).getFirst();
					this.element.getParent().grab(attach);
					attach.store("wii-link",this);
					this.attach = attach;
				}else{
					if($(this.options.attach).getStyle("visibility")=="hidden"||
							$(this.options.attach).getStyle("display")=="none"){
						this.attach = $(this.options.attach).clone();
					    this.attach.setStyle("visibility","visible");
					    this.attach.setStyle("display","");
					}
					else
						this.attach = this.options.attach;
					$(this.attach).setStyle("visibility","");
					this.element.getParent().grab($(this.attach));
				}
			}else
				this.attach = this.element;
		}else{
			this.attach = this.element;
		}
		this.attach.addEvent(this.options.event, this.open.bind(this));			
	},
	/***
	 * open the link
	 * @param ev event
	 */
	open : function(ev){
		var form = ev.target.getParent("form");
		var fv = form && form.retrieve && form.retrieve('validator');
		ev.stop();
		if(this.element.type == 'submit' && this.options.validate && fv)
		{
			if(!fv.validate(ev)){
				var msg = this.options.errorMsg || "Errori trovati nella pagina!";
				alert(msg);
				return;
			}
		}
		var tpl = new Jtemplate(this.options.href);
		var href = tpl.apply(this.element.value);
		var data = this.options.data;
		if(data && this.options.method == 'POST' && !this.options.useQueryString){
			var uri = new URI(href);
			var queryString = uri.get("query");
			if(queryString){
				href = href.split("?")[0];
				queryData = queryString.parseQueryString();
				data=Object.merge(data,queryData);
			}
		}
		if(data){
			var value = ['INPUT','SELECT','TEXTAREA'].indexOf(this.element.tagName)>=0 ? this.element.value : '';
			if(['INPUT','SELECT','TEXTAREA'].indexOf(this.element.tagName)>=0){
				if(!value)
					return;
				else if(this.element.get("class").contains("validation-failed"))
					return;
			}
			var form = new Element('FORM',{
				target : this.options.target,
				action : href,
				enctype: this.options.enctype,
				method : this.options.method
			});
			form.setStyle("display","none");
			$(document.body).grab(form);
			var input;
			var postData = data;
			if(typeof this.options.data == "function")
				postData = this.options.data(); 
			for(var p in postData){
				var tpl2 = new Jtemplate(postData[p]);
				var dataValue = tpl2.apply(value);
				input = new Element('INPUT',{
					type : 'text',
					name : p,
					value : dataValue
				});
				input.inject(form);
			}
			form.submit();
		}else
		  window.open(href,this.options.target);
	}
});
ng.wii.addTag({
	name	: 'link',
	tagClass: ng.wii.Link
});
//
