/***
 * KeyWII - Keyone Widget For Internet
 * @copyright	Copyright (c) 2003-2017, NGUYEN S.n.c.
 * @license		MIT-style license
 */
Jpackage({
  name:"ng.wii",
  "@company"	: "NGUYEN S.n.c.",
  "@copyright": "Copyright(C) 2003-2017 by NGUYEN S.n.c.",
  "@license"	: "MIT-style license",  
  tags:{
	'file'	: 'File'
  },
  /***
   * File input class.
   */
  File : new Class({
	  Extends	: ng.wii.Input,
	  options	: {
		  mimeTypeInput: null,
		  fileNameInput: null,
		  uriInput : null,
		  mimeTypeView : {
			  'image/' : {query: null, el: 'IMG'},
			  'text/'  : {query: null, el: 'TEXTAREA'}
			  ,'application/' : {query: null, el: 'IMG'}
		  }
	  },
	  /***
	   * 
	   */
	  initialize : function(el, options){
		  this.parent(el,options);
		  this.addEvents({
			 "change" :  this.onchange.bind(this)
		  });
	  },
	  /***
	   * 
	   */
	  onchange : function(ev){
		  var input = ev.target;
		  if(input.type == "file"){
			var form=$(input.form);
	        if (input.files && input.files[0]) {
	        	var file = input.files[0];
    			if(this.options.mimeTypeInput)
    				form.getElements("input[name="+this.options['mimeTypeInput']+"]").set("value",file.type);
    			if(this.options.fileNameInput)
    				form.getElements("input[name="+this.options.fileNameInput+"]").set("value",file.name);
    			if(this.options.uriInput){
    				var uri = form.getElements("input[name="+this.options.uriInput+"]")[0].get("value");
    				var i=uri.lastIndexOf("/");
    				if(i>0) uri=uri.substr(0,i+1);
    				form.getElements("input[name="+this.options.uriInput+"]").set("value",uri+file.name);
    			}	        	
	        	for(var contentType in this.options.mimeTypeView){
	        		if(this.options.mimeTypeView[contentType].query && file.type.indexOf(contentType)==0){
	        			var query=this.options.mimeTypeView[contentType].query;
	        			var conds=query.split(" ");
	        			var contentImages=form.getElements(query);
	        			var contentImage;
	        			var elTag = this.options.mimeTypeView[contentType].el;
	        			if(!contentImages.length){
	        				var id = conds[conds.length-1].indexOf('#')==0 ? conds[conds.length-1].substring(1) : '';
	        				var className = conds[conds.length-1].indexOf('.')==0 ? conds[conds.length-1].substring(1) : '';
	        				contentImage=new Element(elTag,{id: id, 'class': className,styles: {width:"512px"}});
	        				form.getElements(conds[0])[0].grab(contentImage);
	        			}else
	        				contentImage=contentImages[0];
	        			var reader = new FileReader();
	        			reader.onload = function (e) {
	        				contentImage.set('src',e.target.result);
	        			};
	        			reader.readAsDataURL(input.files[0]);
	        			/*
	        			if(this.options.mimeTypeInput)
	        				form.getElements("input[name="+this.options['mimeTypeInput']+"]").set("value",file.type);
	        			if(this.options.fileNameInput)
	        				form.getElements("input[name="+this.options.fileNameInput+"]").set("value",file.name);
	        			if(this.options.uriInput){
	        				var uri = form.getElements("input[name="+this.options.uriInput+"]")[0].get("value");
	        				var i=uri.lastIndexOf("/");
	        				if(i>0) uri=uri.substr(0,i+1);
	        				form.getElements("input[name="+this.options.uriInput+"]").set("value",uri+file.name);
	        			}
	        			*/
	        		}
	        	}
	        }		    
		  }
	  }
  })
});
/***
 * add tags.
 */
ng.wii.addTag({
	name: 'file', 
	tagClass: ng.wii.File
});
//