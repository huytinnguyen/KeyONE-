/***
 * KeyWII - Keyone Widget For Internet
 * @copyright	Copyright (c) 2003-2017, NGUYEN S.n.c.
 * @license		MIT-style license
 */
Jpackage({
name	: "ng.wii",
"@company"	: "NGUYEN S.n.c.",
"@copyright": "Copyright(C) 2003-2017 by NGUYEN S.n.c.",
"@license"	: "MIT-style license",

tags 	: {
	'box'	: 'Box',
	'window': 'Window'
}
});
/***
 * Box widget.
 */
ng.wii.Box	= new Class({
	Extends		: mBox,
	//Implements	: [ng.wii.Widget],
	options		: (ng.wii.BoxOptions = {
		addClass: {					// add additional classes to wrapper, container, title and/or footer
			wrapper		: 'wii-box',
			container	: 'wii-container',
			content		: 'wii-content',
			title		: 'wii-title',
			footer		: 'wii-footer',
			controls 	: 'wii-controls',
			resizer		: 'wii-resizer'
		},			
		target		: $(window),
		container	: $(document.body),
		resizable	: false,
		resizeLimits: false,
		resizer		: '&nbsp;',
		zIndex		: 1000,
		raiseOnClick: true,
		width		: '',				// width of the content area
		height		: '',				// height of the content area
		/*
		setStyles	: {
			content : {overflow: "auto", width: "90%", height:"95%"}
		},*/
		closeInTitle: true,			
		event		: 'mouseenter',

		position	: {
			x: ['left', 'inside'],				
			y: ['bottom']
		},
		offset		: { x: 30, y: -5 },			
		//pointer: 'center',
		fixed		: false,
		delayOpenOnce: true,
		defaultInOut: 'outside',
		defaultTheme: 'Tooltip', 
		classOptions: {
			//'{className}' : {
			//	options ...
			//}
		},
		closeOnClick: false,
		closeOnBodyClick: true		
		//events
		//,onOpening: function(box){}

   }),
	/***
	 * initialize
	 * @param options
	 */
	initialize 	: function(options) {
		var el;
		if(arguments.length>1 && $(arguments[0])){
			el = arguments[0];
			options = arguments[1];
		}
		if(el && (!options || Object.getLength(options)==0)){
			return this;
		}
		this.defaultInOut = options.defaultInOut || this.options.defaultInOut;
		this.defaultTheme = options.defaultTheme || this.options.defaultTheme;	
		if(this.options.resizable)
			this.options.footer='';
		this.parent(options);
		this.element = this.wrapper;
		if($(this.options.container)){
			this.wrapper.inject($(this.options.container),"bottom");
		}
		if(this.options.resizable){
			this.setResizer();
		}
		this.setClassOptions();
		var draggable;
		if(!this.options.raiseOnClick){
		  if((draggable=this.wrapper.getElement(".mBoxDraggable"))){
			draggable.addEvent("click",this.raise.bind(this));
		  }
		}else
		  this.wrapper.addEvent("click",this.raise.bind(this));
	},
	/***
	 * 
	 * @param ev
	 */
	raise: function(ev) {
		//var highest_index=this.wrapper.getStyle("z-index") ? eval(this.wrapper.getStyle("z-index"))+1: 1000;
		
		var highest_index = 0;
		var boxes=$$(".wii-box");
		boxes.each(function(el) {
		    if (el.getElement(".mBoxDraggable")!=null && $(el).getStyle("z-index") > highest_index) {
		         highest_index = eval($(el).getStyle("z-index"));
		    }
		});	
		this.wrapper.setStyle("z-index",(highest_index)+boxes.length+1);
	},
	/***
	 * set class options
	 */
	setClassOptions: function(){
		for(var facet in this.options.classOptions){
			var el=this.getFacet(facet);
			if(el){
				for(var name in this.options.classOptions[facet]){
					el.store(name,this.options.classOptions[facet][name]);
				}
			}
		}		
	},
	/***
	 * get title container.
	 * @returns
	 */
	getTitleContainer: function(){
		return this.getFacet("titleContainer");
	},
	/***
	 * get footer container.
	 * @returns
	 */
	getFooterContainer: function() {
		return this.getFacet("footerContainer");		
	},
	/***
	 * get facet element.
	 * @param name
	 * @returns
	 */
	getFacet: function(name) {
		if(this.options.addClass[name] && this.options.addClass[name].length)
			return this.wrapper.getElement("."+this.options.addClass[name]);
		else{
			var el=this.wrapper.getElement(".mBox"+name.charAt(0).toUpperCase()+name.substring(1));
			return el || this[name];
		}
	},
	/***
	 * open the box.
	 * @param options
	 */
	open: function(options){
		Jlibrary.build(this.wrapper);
		this.fireEvent("opening", [this]);
		this.parent(options);
	},
	/***
	 * get the attached html element.
	 * @returns
	 */
	getElement: function(){
		return this.wrapper;
	},
	setResizer: function(){
		if(!this.options.resizable) return this;
		this.resizer = new Element('div', {
			'class': 'mBoxResizer ' + (this.options.addClass.resizer || ''),
			styles: (this.options.setStyles.footer || {})
		}).inject(this.footerContainer);	
		if(this.options.resizer){
			this.setContent(this.options.resizer, 'resizer');
		}
		var self=this;
		this.content.makeResizable({
			handle: this.resizer,
			limit: this.options.resizeLimits,
			onComplete: function(theDiv, event) { 
				self.fireEvent('resize', [event]); 
			} 
		});
		this.wrapper.addClass("isResizable");
		return this;
	}
});
/****
 * window class.
 */
ng.wii.Window = new Class({
	Extends: ng.wii.Box,
	options : (ng.wii.WindowOptions={
		title		: '&nbsp;',
		footer		: '&nbsp;',        			
		closeInTitle: true,						
		//position	: {x:['center'], y:['center']},
		resizable	: true,
		draggable	: true,
		position 	: {
			x: 'center',
			y: 'center'
		},
		closeOnClick: false,
		closeOnBodyClick: false,
		closeOnElementClick: {
			element : null
		}
	}),
	/***
	 * 
	 * @param options
	 * @param element
	 */
	initialize: function(options,element) {
		this.parent(options,element);
		if (!this.options.closeOnBodyClick && this.options.closeOnElementClick.element){
			this.closeOnElementClickEvent = function(ev) {
				if(this.isOpen && ($(this.options.attach) != ev.target 
						&& !$$('.' + this.options.attach).contains(ev.target)) 
						&& ev.target != this.wrapper && !this.wrapper.contains(ev.target)) 
				{
					this.ignoreDelayOnce = true;
					this.close();
				}
			}.bind(this);
			
			$(this.options.closeOnElementClick.element).addEvent('mouseup', this.closeOnElementClickEvent);
		}
	}
});
/***
 * 
 */
ng.wii.Window.Modal = new Class({
	Extends: ng.wii.Window,
	options: {
		event: 'click',		
		target: $(window),
		position: {
			x: ['center', 'inside'],
			y: ['center', 'inside']
		},
		zIndex: 5000,
		fixed: true,
		draggable: true,
		resizable : true,
		overlay: true,
		overlayStyles: {
			color: 'black',
			opacity: 0.1
		},
		closeInTitle: true,
		closeOnClick: false,
		closeOnBodyClick: true,		
		buttons: null					
			// you can add buttons into the footer by defining them as following:
			// buttons: [
			//  {value: 'Cancel', addClass: 'button_cancel'},
			//	{value: 'Submit', addClass: 'button_submit', setStyles: {'margin-left': 10}, 
			//	 event: function() { alert('form submitted'); }, 
			//   id: 'submit_button'}]
	},
	// initialize parent
	initialize: function(options) {
		this.defaultInOut = 'inside';
		this.defaultTheme = 'Modal';
		
		// add buttons once constructed
		if(options.buttons) {
			options.onSystemBoxReady = function() {
				this.addButtons(options.buttons);
			};
		}
		// set options
		this.parent(options);
	},
	
	// add buttons into footer
	addButtons: function(buttons) {
		if(typeof buttons != 'object') return false;
		this.setFooter('');
		this.buttonContainer = new Element('div', {'class': 'mBoxButtonContainer'}).inject(this.footerContainer, 'top');
		buttons.each(function(button, index) {
			//var buttonEl = 
			new Element('button', {
				id: button.id || '',
				value: button.value,
				name: button.name,
				type: button.type,
				html: '<label>' + (button.title || button.value) + '</label>',
				'class': 'mBoxButton ' + (button.addClass || '') + ' ' + (index == 0 ? 'mBoxButtonFirst' : (index == (buttons.length - 1) ? 'mBoxButtonLast' : '')),
				styles: (button.setStyles || {}),
				events: {
					'click': function(ev){ 
						//(button.event || this.close)
						if(button.event)
							button.event(ev);
						//else
						this.close();
						if(button.type!='submit')
							ev.stop();						
					}.bind(this)
				}
			}).inject(this.buttonContainer);
		}.bind(this));
		new Element('div', {styles: {clear: 'both'}}).inject(this.footerContainer, 'bottom');
		return this;
	}	
});
/***
 * 
 */
ng.wii.Window.Confirm = new Class({
	Extends: ng.wii.Window.Modal,
	options: {
		addClass: {
			wrapper: 'Confirm'
		},
		buttons: [
			{ addClass: 'mBoxConfirmButtonCancel' },
			{ addClass: 'button_green mBoxConfirmButtonSubmit', event: function(ev) { this.confirm(ev); } }
		],
		confirmAction: function() {}, 			// action to perform when no data-confirm-action and no href given
		preventDefault: true,
		constructOnInit: true
	},
	// initialize and add confirm class
	initialize: function(options) {
		this.defaultSubmitButton = 'Yes';		// default value for submit button
		this.defaultCancelButton = 'No';		// default value for cancel button
		// destroy mBox when finished closing
		options.onSystemCloseComplete = function() {
			this.destroy();
		};
		// add buttons once constructed
		options.onSystemBoxReady = function() {
			this.addButtons(this.options.buttons);
		};
		// set options
		this.parent(options);
	},
	// submit the confirm and close box
	confirm: function(ev) {
		eval(this.options.confirmAction);
		this.close();
	}
});
/***
 * Box widget.
 */
ng.wii.Box.Notice= new Class({
	Extends		: mBox.Notice,
	options		: {
		addClass: {					// add additional classes to wrapper, container, title and/or footer
			wrapper		: 'wii-box',
			container	: 'wii-container',
			content		: 'wii-content',
			title		: 'wii-title',
			footer		: 'wii-footer',
			controls 	: 'wii-controls',
			resizer		: 'wii-resizer'
		}			
	}
	/***
	 * initialize
	 * @param options
	 */
	,initialize 	: function(options) {
		this.parent(options);
	}
});
// add confirm-events to all elements with attribute 'data-confirm'
ng.wii.Window.Confirm.addConfirmEvents = function() {
	$$('*[data-confirm]').each(function(el) {
		if(!el.retrieve('hasConfirm')) {
			var attr = el.getAttribute('data-confirm').split('|'),
				action = el.getAttribute('data-confirm-action') || (el.get('href') ? 'window.location.href = "' + el.get('href') + '";' : 'function() {}');
			
			el.addEvent('click', function(ev) {
				ev.preventDefault();
				if(confirm_box) {
					confirm_box.close(true);
				}
				//var confirm_box = 
				new mBox.Modal.Confirm({
					content: attr[0],
					confirmAction: action,
					onOpen: function() {
						if(!this.footerContainer) { return;
							this.setFooter(null);
						}
						this.footerContainer.getElement('.mBoxConfirmButtonSubmit').set('html', '<label>' + (attr[1] || this.defaultSubmitButton) + '</label>');
						this.footerContainer.getElement('.mBoxConfirmButtonCancel').set('html', '<label>' + (attr[2] || this.defaultCancelButton) + '</label>');
					}
				}).open();
			});
			el.store('hasConfirm', true);
		}
	});
};
/***
 * Desktop
 */
ng.wii.Desktop = {
	openedWindows : {},
	options : {
		 marginTop : 10
		,marginLeft : 10
	},
	/***
	 * open and register the window.
	 */
	openWindow : function(windowType,windowOpt){
		var window;
		if(windowOpt.id!=null && this.openedWindows[windowOpt.id]){
			window = this.openedWindows[windowOpt.id];
			window.open();
		}else {
		   Object.append(windowOpt,{
				offset 		: {
					y: this.options.marginTop+(Object.keys(this.openedWindows).length)*40, 
					x: this.options.marginTop+(Object.keys(this.openedWindows).length)*80
				}			   
		   });
		   window = new windowType(windowOpt);
		   if(window.options.id){
			 this.openedWindows[window.options.id]=window;
		   }
		   window.open();
		}
		window.raise();
	}
};
// 