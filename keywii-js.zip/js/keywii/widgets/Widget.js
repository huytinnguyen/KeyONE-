/***
 * KeyWII - Keyone Widget For Internet
 * @copyright	Copyright (c) 2003-2017, NGUYEN S.n.c.
 * @license		MIT-style license
 */
//
Jpackage({
  name: "ng.wii",
  "@company"	: "NGUYEN S.n.c.",
  "@copyright": "Copyright(C) 2006-2017 by NGUYEN S.n.c.",
  "@license"	: "MIT-style license",
  
  tags: {
	'loader' 	: 'Loader',
	'widget'	: 'Widget'
  }
});
/***
 * HTML loader
 */
ng.wii.Loader= new Class({
	Extends	: Jloader,
	options	: (LoaderOptions={
		loading	: "wii-loading",	
		load	: {
			url			: null,
			evalScripts	: true,
			method		: 'post',
			data		: {}
		}
	}),
	/***
	 * Class constructor.
	 * @param el
	 * @param options
	 */
	initialize : function ng$wii$Loader (el,options){
		options = options || {};
		var args=this.parseArguments(arguments);
		this.parent(args.element,args.options);
	},
	/***
	 * on html load event handler.
	 * @param responseTrees
	 * @param responseElements
	 * @param responseHtml
	 * @param responseScripts
	 */
	onLoad: function(response){
		this.hideLoading();
		Jlibrary.build(this.getElement());
		this.parent(response);
	},		
	/***
	 * failure event handler
	 * @param xhr XmlHttpRequest
	 */
	onFailure: function(xhr){
		this.hideLoading();
		this.element.set("html",xhr.responseText);
		this.fireEvent("failure",[xhr]);
	},
	/***
	 * load start event handler.
	 * @param ev
	 * @param xhr
	 */
	onLoadstart: function(ev,xhr){
		this.showLoading();
		this.fireEvent("loadstart",[ev,xhr]);
	},
	/***
	 * show loading ...
	 */
	showLoading: function() {
		ng.wii.Loader.showLoading(this);
	},
	/***
	 * hide loading...
	 */
	hideLoading: function() {
		ng.wii.Loader.hideLoading(this);
	}
});
/***
 * 
 */
Object.append(ng.wii.Loader,{
	/***
	 * show loading
	 */
	showLoading: function(element,loadingClass){
		var loader;
		if(instanceOf(element,ng.wii.Loader)){
			loader = element;
			loadingClass = loadingClass || loader.options.loading;
			element = loader.element;
		}else
			loadingClass = loadingClass || LoaderOptions.loading;
		if(element && loadingClass){
			  var loading=null;
			  if(element && !(loading=element.getElement("."+loadingClass))){
			    loading=new Element('div', {
				  'class': loadingClass
			    });
			    element.appendChild(loading);
			  }
			  loading && loading.show();
		}			
	},
	/***
	 * hide loading
	 */
	hideLoading : function(element,loadingClass){
		var loader;
		if(instanceOf(element,ng.wii.Loader)){
			loader = element;
			loadingClass = loadingClass || loader.options.loading;
			element = loader.element;
		}else
			loadingClass = loadingClass || LoaderOptions.loading;		
		if(loadingClass && element) {
			  var loading=element.getElement("."+loadingClass);
			  if(loading)
				loading.hide();		
		}			
	}
});
/***
 * @class ng.wii.Widget 
 * The generic widget class to handle a html element.
 */
ng.wii.Widget = new Class({
	Extends		: ng.wii.Loader,
	id			: null,
	logger		: new Jlogger(JlogType.ERROR),
	isDynamic	: false,
	options		: (ng.wii.WidgetOptions={
	 	useFrame	: false,
	 	events		: null,
		element		: null,
		controller	: null, // ajax request/web client to get the data from server
		data		: null,
		// style class and facets of widget
		'class'		: "wii-widget",
		facets: {
	 		header  	: {'class': "wii-header", fixed: true},
	 		body 		: {'class': "wii-body",	fixed: true},
	 		content 	: {'class': "wii-body", fixed: true},
	 		footer  	: {'class': "wii-footer", fixed: true}
	 	},
		template	: null,
		transition  : null,
		onDataLoad	: function(widget, response, responseText){},
		onDataFailure : function(widget, xhr) {}
	}),
	// the wrapped html element 
	element		: null,
	/***
	 * class constructor (initialize for mootools).
	 * @param el	html element.
	 * @param options widget options.
	 * @return class instance.
	 */
	initialize : function ng$wii$Widget (element,options){
		options = options || {};
		this.parent(element,options);
		// generate widget's id
		this.id=ng.wii.Widget.generateId(this.element);
		this.setup();
	},
	/***
	 * setup the widget.
	 */
	setup: function(){
		this.parseFacets();		
		this.setupFacets();
		this.controller = this.options.controller;	
		this.setupListeners();	
		if(this.element.tagName=='INPUT' || this.element.tagName=='TEXTAREA' || this.element.tagName=='SELECT'){
		  var form = this.element.getParent("form");
		  var validator=form.retrieve("validator");
		  if(validator){
			validator.watchFields([this.element]);
		  }
		}
	},
	/***
	 * 
	 */
	setupListeners: function() {
		if(this.controller){
			this.controller.addEvents({
				success: this.onDataLoad.bind(this),
				failure: this.onDataFailure.bind(this)
			});
		}
	},
	/***
	 * 
	 * @param response
	 * @param responseText
	 */
	onDataLoad : function(response, responseText){
		if(instanceOf(this.controller,Request)){
			this.controller.response=response;
		}
		this.fireEvent("dataLoad",[this, response, responseText]);		
	},
	/***
	 * 
	 * @param xhr
	 */
	onDataFailure : function(xhr){
		this.fireEvent("dataFailure", [this, xhr]);		
	},
	/****
	 * 
	 */
	getData: function(){
		if(this.options.data){
			return this.options.data;
		}else if(this.controller){
			return (typeof this.controller.getItems == "function" && this.controller.getItems()) ||
			       (instanceOf(this.controller,Request) && this.controller.response) ||			       
			       (typeof this.controller.getData == "function" && this.controller.getData()) ||			       
			       (this.controller.data);
		}
	},
	/***
	 * @private
	 */
	parseFacets: function(){
		if(this.options.facets && !this.parsedFacets){
			this.parsedFacets=true;
			for(var name in this.options.facets){
				if(typeof this.options.facets[name] == "string"){
					var querys=this.options.facets[name].split(",");
					var facet={};
					querys.each(function(query){
						query=query.trim();
						if(query.charAt(0)=='.'){
							if(!facet['class'])
								facet['class']=query.substring(1);
							else
								facet['class'] += " "+query.substring(1);
						}else{
							if(!facet.query)
								facet.query = query;
							else
								facet.query += "," + query;	
						}
					});
					this.options.facets[name]=facet;
				}
			}
		}
	},
	/***
	 * @protected
	 */
	build: function(){
		var el;
		this.isDynamic=true;
		el=new Element("div",{
			style	: "position:absolute;"
		});
		el.addClass(this.options['class'] || this.options.className || '');
		if(document && document.body)
			$(document.body).appendChild(el);
		return el;
	},
	/***
	 * focus the widget.
	 */
	setFocus: function() {
		try{ 
			this.element.focus(); 
		}catch(e){
			//throw e;
		}
	},
	/***
	 * return the html element id. 
	 */
	getId: function() {
		if(this.id)
			return this.id;
		else
			return this.element.id;
	},
	/***
	 * show the wiidget.
	 */
	show: function(){
		if(this.element){
			this.element.show();
			if(this.options.transition && this.options.transition.method){
				var fx=new this.options.transition.method(
						this.element,
						this.options.transition.options
				);
				fx.start();
			}
		}
	},
	/***
	 * hide the widget.
	 */
	hide: function() {
		if(this.element)
			this.element.hide();		
	},
	/***
	 * close and hide the widget.
	 */
	close: function() {
		this.hide();
		if(this.isDynamic){
			this.removeEvents();
			this.removeEvents("load");
			if(this.element)
				this.element.removeEvents();
			if(this.restoreOriginalHtml && this.originalHtml)
				this.element.set("html",this.originalHtml);
		}
	},
	/***
	 * 
	 * @param name
	 */
	getFacet: function(name,container){
		return this.getFacets(name,container)[0];
	},
	/***
	 * returns the face element by it's name.
	 */
	getFacets: function(name,container){
		this.parseFacets();	
		var elements=[];
		container = container || this.element;
		if(name in this.options.facets){
			var facet=this.options.facets[name];
			elements = container.getElements("."+facet['class']);
			if(elements.length==0 && facet.query){
				var query=facet.query.split(',');
				for(var i=0; i< query.length; i++){
					var eles=container.getElements(query[i]);
					//elements.push.apply(elements,eles);
					elements = elements.concat(eles);
					if(!facet.plurial && eles.length>0)
						break;
				}
			}
		}
		return elements;
	},
	/***
	 * 
	 * @returns {Boolean}
	 */
	getContent: function(){
		if(!this.content)
			this.content = this.getFacet("body") || this.getFacet("content") || this.element;
		return this.content;
	},
	getHeader: function(){
		if(!this.header)
			this.header=this.getFacet("header") || this.element;
		return this.header;
	},
	getFooter: function(){
		if(!this.footer)
			this.footer=this.getFacet("footer");
		return this.footer;
	},
	/***
	 * 
	 */
	setupFacets: function(clear){
	},
	/***
	 * 
	 */
	render: function(html){
		if(html){
			this.getContent().set("html",html);
		}
	},
	/***
	 * update widget layout.
	 * @param html
	 */
	update : function(html){
		this.render(html);
	}
});

/***
 * static properties of class Widget
 */
Object.append(ng.wii.Widget,{
	_widgetCount	: 0,
	_widgetPrefix	: "$widget",
	//
	// generate identifier for given element.
	//
	generateId: function(el) {
		var id;
		var prefix=ng.wii.getNSPrefix(el)+this._widgetPrefix;
		if(!el || !el.id || el.id == ""){
			id=prefix+"$"+(++this._widgetCount);
			if(el)
				el.id=id;
		}else if(el)
			id=el.id;
		return id;
	}
});
/***
 * register the class as a Tag: wii-frame
 */
ng.wii.addTag({
	name	: "widget", 
	tagClass: ng.wii.Widget
});
//