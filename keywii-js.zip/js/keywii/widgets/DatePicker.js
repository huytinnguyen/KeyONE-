/***
 * KeyWII - Keyone Widget For Internet
 * @copyright	Copyright (c) 2003-2017, NGUYEN S.n.c.
 * @license		MIT-style license
 */
Jpackage("ng.wii");
/***
 * @class ng.wii.DatePicker
 * the date picker widget
 */
ng.wii.DatePicker=new Class({
	//Extends			: ng.wii.Input,
	Implements		: [Events,Options],
	options			: (ng.wii.DatePickerOptions={
		useCalendar	: false,
		prefill		: true,
		destroyOnHide: false,
		pickOnly		: false,
		//toggler	: null,
		//format		: '%Y-%m-%d',
		alignY		: 'bottom',
		alignX		: 'left',
		offsetX		: -7,
		offsetY		: 0,
		zIndex		: 3000,
		timePicker	: true,
		pickerClass	: 'datepicker_vista'
	}),
	/***
	 * initilize the istance of class.
	 */
	initialize : function (el,options) {
		this.options = Object.merge(this.options,ng.wii.DatePickerOptions);
		this.setOptions(options);
		this.element = $(el);
		this.options.onselect = options.onselect || options.onchange || options.onChange;
		//this.parent(el,options);
		if(!el.hasClass("wii-filter-input") && !el.get("readonly")){
			$(el).autocomplete="off";
			this.addListeners();
		}
	},
	onKeypress: function(ev){
		var target=ev.target;
		if(!ev.shift && !ev.control && !ev.alt && !ev.meta){
			switch(ev.key){
			case 'delete':
			case 'backspace':
				//alert(ev);
				this.element.value="";
				this.datePicker.fireEvent("select",[this.element.value,this.element]);
				break;
			}
		}
	},
	getElement : function(){
		return this.element;
	},
	addListeners: function(){
		this.getElement().addEvent("focus",(function(){
			this.buildPicker();
		}).bind(this));	
	},
	/***
	 * build date picker
	 */
	buildPicker: function(){
		if(!this.datePicker){
			var options = {};
			Object.append(options,this.options);
			options.pickerClass = this.options.pickerClass;
			options.timePicker = eval(this.options.timePicker);
			var datePicker = new Picker.Date(this.getElement(), options);	
			if(this.options.onselect){
				datePicker.addEvent("select",this.options.onselect);
			}
			this.datePicker=datePicker;
			this.element.addEvents({
				//"click"	: this.openLink.bind(this),
				"keydown"	: this.onKeypress.bind(this),
			});			
		}
	}
});
ng.wii.tag('date-picker',ng.wii.DatePicker);
