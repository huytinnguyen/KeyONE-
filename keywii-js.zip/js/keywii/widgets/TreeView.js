/***
 * KeyWII - Keyone Widget For Internet
 * @copyright	Copyright (c) 2003-2017, NGUYEN S.n.c.
 * @license		MIT-style license
 */
Jpackage("wii");
/***
 * Tree view class.
 */
wii.TreeView=new Class({
	//Extends : ECOTree,
	Implements: [Options,Events],
	options: {
		object				: null,
		element 			: null,
		iMaxDepth 		 	: 100,
		iLevelSeparation 	: 40,
		iSiblingSeparation 	: 40,
		iSubtreeSeparation 	: 80,
		iRootOrientation 	: ECOTree.RO_TOP,
		iNodeJustification 	: ECOTree.NJ_TOP,
    	topXCorrection 		: 0,	// from version 1.5
    	topYCorrection 		: 0,	// from version 1.5					
		topXAdjustment 		: 0,
		topYAdjustment 		: 0,		
		render 				: "AUTO",
		linkType 			: "M",
		linkColor 			: "blue",
		nodeColor 			: "#CCCCFF",
		shadowColor			: '#999',
		shadowBlur			: 10,
		nodeFill 			: ECOTree.NF_GRADIENT,
		nodeBorderColor 	: "blue",
		nodeSelColor 		: "#FFFFCC",
		levelColors 		: ["#5555FF","#8888FF","#AAAAFF","#CCCCFF"],
		levelBorderColors 	: ["#5555FF","#8888FF","#AAAAFF","#CCCCFF"],
		colorStyle 			: ECOTree.CS_NODE,
		useTarget 			: true,
		searchMode 			: ECOTree.SM_DSC,
		selectMode 			: ECOTree.SL_MULTIPLE,
		defaultNodeWidth 	: 80,
		defaultNodeHeight 	: 40,
		defaultTarget 		: 'javascript:void(0);',
		expandedImage 		: './img/less.gif',
		collapsedImage 		: './img/plus.gif',
		transImage 			: './img/trans.gif'
	},
	initialize: function(options){
		//this.parent(obj,elm);
		this.setOptions(options);
		this.element=$(options.element);
		var merged = Object.merge(ECOTree.prototype,this);
		Object.append(this,merged);
		ECOTree.apply(this,[options.object,this.element.id]);
		Object.append(this.config,this.options);
		this.render = (this.config.render == "AUTO" ) ? this._getAutoRenderMode() : this.config.render;	
		//this.configCanvas();
		//this.parent(options.object,this.element.id);
	},
	/***
	 * update tree layout.
	 */
	UpdateTree : function () {	
		this.elm.innerHTML = this;
		// configures the canvas context
		this.configCanvas();
		if (this.render == "CANVAS") {
			var canvas = document.getElementById(this.elm.id+"-ECOTreecanvas");
			if (canvas && canvas.getContext)  {
				this.canvasoffsetLeft = canvas.offsetLeft;
				this.canvasoffsetTop = canvas.offsetTop;
				this.ctx = canvas.getContext('2d');
				var h = this._drawTree();	
				var r = this.elm.ownerDocument.createRange();
				r.setStartBefore(this.elm);
				var parsedHTML = r.createContextualFragment(h);								
				//this.elm.parentNode.insertBefore(parsedHTML,this.elm)
				//this.elm.parentNode.appendChild(parsedHTML);
				this.elm.appendChild(parsedHTML);
				//this.elm.insertBefore(parsedHTML,this.elm.firstChild);
			}
		}
	},	
	/***
	 * configure the canvas context.
	 */
	configCanvas: function() {
		if (this.render == "CANVAS") {
			var canvas = document.getElementById(this.elm.id+"-ECOTreecanvas");
			if (canvas && canvas.getContext)  {
				ctx = canvas.getContext('2d');
				ctx.shadowColor = this.config.shadowColor;
				ctx.shadowBlur = this.config.shadowBlur;
			}
		}
	},
	show: function(){
		//alert("showed");
	},
	/***
	 * draw tree
	 */
	_drawTree : function () {
		var s = [];
		var node = null;
		var color = "";
		var border = "";
				
		for (var n = 0; n < this.nDatabaseNodes.length; n++)
		{ 
			node = this.nDatabaseNodes[n];
			
			switch (this.config.colorStyle) {
				case ECOTree.CS_NODE:
					color = node.c;
					border = node.bc;
					break;
				case ECOTree.CS_LEVEL:
					var iColor = node._getLevel() % this.config.levelColors.length;
					color = this.config.levelColors[iColor];
					iColor = node._getLevel() % this.config.levelBorderColors.length;
					border = this.config.levelBorderColors[iColor];
					break;
			}
			
			if (!node._isAncestorCollapsed())
			{
				switch (this.render)
				{
					case "CANVAS":
						//Canvas part...
						this.ctx.save();
						this.ctx.strokeStyle = border;
						switch (this.config.nodeFill) {
							case ECOTree.NF_GRADIENT:							
								var lgradient = this.ctx.createLinearGradient(node.XPosition,0,node.XPosition+node.w,0);
								lgradient.addColorStop(0.0,((node.isSelected)?this.config.nodeSelColor:color));
								lgradient.addColorStop(1.0,"#F5FFF5");
								this.ctx.fillStyle = lgradient;
								break;
								
							case ECOTree.NF_FLAT:
								this.ctx.fillStyle = ((node.isSelected)?this.config.nodeSelColor:color);
								break;
						}					
						
						ECOTree._roundedRect(this.ctx,node.XPosition,node.YPosition,node.w,node.h,5);
						this.ctx.restore();
						
						//HTML part...
						s.push('<div id="' + node.id + '" class="econode" style="top:'+(node.YPosition+this.canvasoffsetTop)+'; left:'+(node.XPosition+this.canvasoffsetLeft)+'; width:'+node.w+'; height:'+node.h+';" ');
						if (this.config.selectMode != ECOTree.SL_NONE)											
							s.push('onclick="javascript:ECOTree._canvasNodeClickHandler('+this.obj+',event.target.id,\''+node.id+'\');" ');										
						s.push('>');
						s.push('<font face=Verdana size=1>');					
						if (node.canCollapse) {
							s.push('<a id="c' + node.id + '" href="javascript:'+this.obj+'.collapseNode(\''+node.id+'\', true);" >');
							s.push('<img border=0 src="'+((node.isCollapsed) ? this.config.collapsedImage : this.config.expandedImage)+'" >');							
							s.push('</a>');
							s.push('<img src="'+this.config.transImage+'" >');						
						}					
						if (node.target && this.config.useTarget)
						{
							s.push('<a id="t' + node.id + '" href="'+node.target+'">');
							s.push(node.dsc);
							s.push('</a>');
						}				
						else
						{						
							s.push(node.dsc);
						}
						s.push('</font>');
						s.push('</div>');		
						break;
						
					case "VML":
						s.push('<v:roundrect id="' + node.id + '" strokecolor="'+border+'" arcsize="0.18"	');
						s.push('style="position:absolute; top:'+node.YPosition+'; left:'+node.XPosition+'; width:'+node.w+'; height:'+node.h+'" ');
						if (this.config.selectMode != ECOTree.SL_NONE)
							s.push('href="javascript:'+this.obj+'.selectNode(\''+node.id+'\', true);" ');										
						s.push('>');
						s.push('<v:textbox inset="0.5px,0.5px,0.5px,0.5px" ><font face=Verdana size=1>');
						if (node.canCollapse) {
							s.push('<a href="javascript:'+this.obj+'.collapseNode(\''+node.id+'\', true);" >');
							s.push('<img border=0 src="'+((node.isCollapsed) ? this.config.collapsedImage : this.config.expandedImage)+'" >');							
							s.push('</a>');
							s.push('<img src="'+this.config.transImage+'" >');						
						}					
						if (node.target && this.config.useTarget)
						{
							s.push('<a href="'+node.target+'">');
							s.push(node.dsc);			
							s.push('</a>');	
						}				
						else
						{						
							s.push(node.dsc);									
						}
						s.push('</font></v:textbox>');											
						switch (this.config.nodeFill) {
							case ECOTree.NF_GRADIENT:
								s.push('<v:fill type=gradient color2="'+((node.isSelected)?this.config.nodeSelColor:color)+'" color="#F5FFF5" angle=90 />');	
								break;
							case ECOTree.NF_FLAT:
								s.push('<v:fill type="solid" color="'+((node.isSelected)?this.config.nodeSelColor:color)+'" />');	
								break;
						}
						s.push('<v:shadow type="single" on="true" opacity="0.7" />');					
						s.push('</v:roundrect>');																									
						break;
				}	
				if (!node.isCollapsed)	s.push(node._drawChildrenLinks(this.self));
			}
		}	
		return s.join('');	
	},
	/***
	 * return the selected nodes..
	 * @returns {Array}
	 */
	getSelectedNodes : function () {
	    var node = null;
	    var selection = [];
	 
	    for (var n = 0; n < this.nDatabaseNodes.length; n++) {
	        node = this.nDatabaseNodes[n];
	        if (node.isSelected) {
	            selection[selection.length] = node;
	        }
	    }
	    return selection;
	},
	/***
	 * get auto render mode.
	 */
	_getAutoRenderMode : function() {
		var r = "VML";
		var is_ie6 = /msie 6\.0/i.test(navigator.userAgent);
		var is_ff = /Firefox/i.test(navigator.userAgent);	
		var is_ch = /chrome/.test(navigator.userAgent.toLowerCase()); 
		//if (is_ff || is_ch) r = "CANVAS";
		if(document.createElement("canvas").getContext)
			r="CANVAS";
	  	return r;
	}
});