/***
 * KeyWII - Keyone Widget For Internet
 * @copyright	Copyright (c) 2003-2017, NGUYEN S.n.c.
 * @license		MIT-style license
 */
/***
 * wii-each tag.
 * for example:
   <script>
   var items=[
      {name: "tin1", address: "Piobesi", phone: "011999999"},
      {name: "tin2", address: "Piobesi", phone: "011999999"},
      {name: "tin3", address: "Piobesi", phone: "011999999"}
   ];
   </script> 
   <tbody wii:items="@{items}" wii:var="item" wii:varStatus="status" class="wii-each">
     <tr><td>@{item.name}</td> <td>@{item.address}</td> <td>@{item.phone}</td></tr>
   </tbody>
 */
Jpackage({
name: "ng.wii",
"@company"	: "NGUYEN S.n.c.",
"@copyright": "Copyright(C) 2006-2017 by NGUYEN S.n.c.",
"@license"	: "MIT-style license",
tags: {
	"each": 'EachTag'
},
/***
 * @class : EachTag
 */
EachTag : new Class({
	Extends	: JbodyTag,
	tagName	: "each",
	items	: [],
	"var"	: null,
	status	: {},
	varStatus: null,
	options: {
		binding: {
			items : ng.wii.getNSPrefix()+":items",
			"var" : ng.wii.getNSPrefix()+":var",
			varStatus: ng.wii.getNSPrefix()+":varStatus"
		}
	},
	initialize : function(element,options){
		this.parent(element,options);
		this.items=Jevaluator.eval(this.items);
		this.bodyHtml=this.element.get("html");//new Element("div",{html:this.element.get("html")});
		this.hasChildNodes=ng.wii.$$(null,this.element,true).length>1;
		
	},
	doStartTag: function() {
		try {
			this.status={index:0};
			//empty the element body 
			this.element.set("html","");
			this.status={index:0};
			Jevaluator.pushStack({"this": this});
			return this.parent();
		}catch(e){
			throw e;
		}
	},
	doBodyTag: function(){
		try {
			this.bodyOut=this.element.get("html");
			Jevaluator.setVar(this.varStatus,this.status);
			for(var i=0; i<this.items.length; i++){
				this.status.index=i;
				Jevaluator.setVar(this["var"],this.items[i]);
				var html=this.bodyHtml;//.get("html");
				html=Jevaluator.eval(html);
				this.bodyOut += html;
			}
			this.element.set("html",this.bodyOut);
			this.bodyOut=null;
			return Jtag.DO_END;
		}catch(e){
			
		}
	},
	doEndTag: function() {
		try {
			Jevaluator.popStack();
			return 0;
		}catch(e){
			throw e;
		}
	}
})
});
//