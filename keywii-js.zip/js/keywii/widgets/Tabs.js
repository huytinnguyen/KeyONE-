/***
 * KeyWII - Keyone Widget For Internet
 * @copyright	Copyright (c) 2006-2017, NGUYEN S.n.c.
 * @license		MIT-style license
 */
Jpackage("ng.wii");
/***
 * Tabs menu widget class.
 * @class Tabs
 */
ng.wii.Tabs=new Class({
  Implements: [Options,Events],
  options	: {
  	target	: null,
  	varSelected : null,
  	facets : {
  		tabs : "wii-tabs-menu",
  		selected: "selected"
  	}
  },
  /***
   * class constructor.
   */
  initialize: function(el,options){
    this.setOptions(options);
    this.target=this.options.target;
  	this.element=$(el);
	$(el).setStyle('list-style', 'none'); 
		// This is to fix a glitch that occurs in IE8 RC1 when dynamically switching themes
	this.render(el);
  },
  /***
   * render the tabs layout.
   */
  render: function(el) {
	var self=this;
	var tabs=$(el).getElement("."+this.options.facets.tabs);
	var varSelected = $(this.options.varSelected);
	var self=this;
	if(tabs)
	tabs.getElements('li').each(function(listitem){
		listitem.getElements("A").each(function(A){
			A.addEvent("click",function(ev){
				ev.stop();
				self.selectTab(ev,listitem);
			});
		})
		listitem.addEvent('click', function(ev){
			self.selectTab(ev,listitem);
		});
		if(varSelected && varSelected.value != ""){
		    var link = listitem.getFirst('a');
		    var i = link.href.indexOf("#");
		    if(i>=0){
		    	var href=link.href.substring(i+1);
		    	if(href == varSelected.value){
		    		self.selectTab(null,listitem);
		    	}
		    }
		}
	}); 
	
  },
  /***
   * select a tab
   */
  selectTab: function(ev,listitem){
    var tabs = $(this.element).getElement("."+this.options.facets.tabs);
    var link = listitem.getFirst('a');
    var i = link.href.indexOf("#");
     
    if(i<0)
    	return;
    var linkUri =new URI(link.href);
    var myUri = new URI();
    if(linkUri.toString().indexOf(myUri.toString())!=0)
    	return;
    var activeTabs = tabs.getElements('li.'+this.options.facets.selected);
    activeTabs.removeClass(this.options.facets.selected);
    activeTabs.each(function(activeTab){
    	var A = activeTab.getFirst("A");
    	var i;
    	if((i=A.href.indexOf("#")) >= 0){
        	var element=$(A.href.substring(i+1));
        	if(element)
        		element.hide();
    	}
    });    
    listitem.addClass(this.options.facets.selected);
    if(i>=0){
    	var element=$(link.href.substring(i+1));
    	if(element){
    		if($(this.options.varSelected)){
    			$(this.options.varSelected).value=element.id;
			}
    		element.setStyle("display","block");
    	}
    }
  },
  /***
   * clear the tabs
   */
  clear: function(){
  	this.removeEvents('select');
  }
});
ng.wii.tag("tabs",ng.wii.Tabs);
/***
 * Simple tab folder.
 */
ng.wii.Jtabs=new Class({
	Extends : ng.wii.Tabs,
	options : {
	  	facets : {
	  		tabs : "ui-tabs",
	  		selected: "acted"
	  	}		
	}
});
ng.wii.tag("ui-tabs",ng.wii.Jtabs);
//