/***
 * KeyWII - Keyone Widget For Internet
 * @copyright	Copyright (c) 2003-2017, NGUYEN S.n.c.
 * @license		MIT-style license
 */
Jpackage ({
name: 'ng.wii',
"@company"	: "NGUYEN S.n.c.",
"@copyright": "Copyright(C) 2006-2017 by NGUYEN S.n.c.",
"@license"	: "MIT-style license",

tags: {
	input: 'Input',
	checkbox : 'Checkbox'
}
});

/***
 * The input widget class.
 * @class ng.wii.Input
 */
ng.wii.Input= new Class({
	//Extends	: ng.wii.Widget,
	Implements: [Options,Events],
	errorMsg: null,
	/***
	 * widget options.
	 */
	options	: {
		type		: 'text',
		minLength	: 0,
		maxLength	: 0,
		required	: false,
		dataType	: "", 	/** String, Date, Number, Boolean */
		upperCase	: false,
		lowerCase	: false,
		//maskType	: null,
		maskOptions	: {
			mask	: null,	// mask
			name	: null, // tipo di mask predefinito
			autoTab	: false // auto tab
		},
		format		: null,
		onError		: null,
		linkedInput : null
	},
	/***
	 * Class constructor.
	 */
	initialize : function keywii$Input(el,options){
		//this.parent(el,options);
		this.setOptions(options);
		this.element = $(el);
		var me=this;
		this.getElement().addEvents({
			"change":	this.onChange.bind(this),
			"blur"	: this.onBlur.bind(this),
			"show"	: this.onShow.bind(this)
		});			
		if(this.element.hasClass("uppercase"))
			this.options.upperCase = true;
		else if(this.element.hasClass("lowercase"))
			this.options.lowerCase = true;
		if(this.options.upperCase || this.options.upperCase){
			this.getElement().addEvents({
				"keyup": function(ev){
					if(me.options.upperCase){
						this.value=this.value.toUpperCase();
					}else
						this.value=this.value.toLowerCase();
				}
			});
		}
		//if(this.element.getStyle("visibility")!="hidden" && this.element.getStyle("display")!="none")
		this.fireEvent("show",[null,this]);
		if(typeof this.options.onError == "function"){
			this.addEvent("error",this.options.onError);
		}
		try{
		  if(this.getElement().meiomask && this.options.maskOptions 
			 && (this.options.maskOptions.name || this.options.maskOptions.mask))
		  {
			this.getElement().meiomask(this.options.maskOptions.name, this.options.maskOptions);
		  }	
		}catch(e){
		  alert(e);
		}
	},
	getElement: function(){
		return this.element;
	},
	/***
	 * on-change event handle.
	 */
	onChange: function(ev) {
		this.validate();
		this.fireEvent("change",[ev,this]);
	},	
	onBlur: function(ev){
		this.fireEvent("blur",[ev,this]);
	},
	onShow : function(ev){
		this.fireEvent("show",[ev,this]);
	},
	/***
	 * validate the input.
	 */
	validate: function() {
	},
	/***
	 * return the error msg of the input.
	 */
	getErrorMsg: function(){
		return this.errorMsg;
	}
});
/***
 * Checkbox widget class
 */
ng.wii.Checkbox= new Class({
	Extends		: ng.wii.Input,
	options		: {
		id		: null,
		type	: "checkbox",
		on 		: "1",
		off		: ""
	},
	initialize : function(el, options){
		this.parent(el,options);
		var input = new Element("input",{
			type : "hidden"
		});
		if(this.options.id)
			el.id=this.options.id;
		input.value = el.checked ? this.options.on : this.options.off;
		input.name = el.name;
		input.inject(el,"after");
		this.input=input;
		el.name="";
		el.addEvent("click", (function(ev){
			this.input.value = this.element.checked ? this.options.on : this.options.off;
		}).bind(this));
	}
});
	
//});
//end-package

