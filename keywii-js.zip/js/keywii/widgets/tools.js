/***
 * KeyWII - Keyone Widget For Internet
 * @copyright	Copyright (c) 2006-2017, NGUYEN S.n.c.
 * @license		MIT-style license
 */
Jpackage("ng.wii");
/***
 * Tips handle class.
 */
/*
ng.wii.Tips=new Class({
	Extends: FloatingTips, 
	initialize : function (els,options){
		this.parent(els,options);
	}
});
*/
//ng.wii.tag("tips",ng.wii.Tips);
/***
 * 
 */
ng.wii.Tooltip=new Class({
	Extends: mBox.Tooltip,
	options : {
	},
	initialize: function (el,options){
		options = options || {};
		if(el)
			options.attach=el;
		if(el.get("title") && !options.content)
			options.content=el.get("title");
		el.set("rel",el.get("title"));
		el.set("title","");
		this.setOptions(options);		
		this.parent(this.options);
	}
});
ng.wii.tag("tooltip",ng.wii.Tooltip);
ng.wii.tag("tips",ng.wii.Tooltip);

/***
 * Button class.
 */
ng.wii.Button = new Class({
	Extends: ng.wii.Widget,
	options	: {
		confirm: null,
		validate: false,
		errorBox : null,
		immediate: false,
		postData : null,
		action : null,
		value : null,
		href : null, // if it's not null, the button is a link
		target : null // target of action
	},
	/***
	 * class constructor.
	 * @param options
	 */
	initialize: function(element,options){
		this.parent(element,options);
		this.element.addEvent("click",this.onclick.bind(this));
	},
	/***
	 * on-click event handler.
	 * @param ev
	 */
	onclick: function(ev){
		var form = ev.target.getParent("form");
		var fv = form && form.retrieve && form.retrieve('validator');
		if(this.element.type == 'submit' && !this.options.confirm 
			&& (!this.options.validate || this.options.immediate))
		{
			//ev.stop(); moved in Frame.submit
			ng.wii.Frame.submit(ev, this.element, false);
		}else if(this.options.confirm){
			ev.stop();
			if(this.options.validate && fv && form.getElements(".validation-failed").length>0/*!fv.validate()*/)
				return;
			var annullButton = { 
					title	: Locale.get("keywii.button_annull"), 
					addClass: "button_cancel", 
					setStyles: {
						"float": 'right', "cursor": 'pointer'
					}
			};
			var okButton = { 
					title	: Locale.get("keywii.button_ok"), 
					setStyles: {
						"float" : 'right', "cursor": 'pointer'
					}, 
					value	: this.element.value,
					type	: 'submit', 
					addClass: 'button_submit', 
					name	: this.element.name,
					event 	: function(ev){
						ng.wii.Frame.submit(ev, this.element, this.options.validate);
					}.bind(this)
			};
			
			var form = this.element.getParent("form");
			var options={
					title 	: Locale.get("keywii.confirm_window_title"),
					content	: "Vuoi effettuare l'operazione richiesta?",
					//container: form,
					target 	: this.element,
					fixed 	: false,
					position	: {
						x: ['left', 'inside'],				
						y: ['top']
					},
					pointer	: ['right', 3],
					offset 	: {x:8, y: 0},	
					closeOnClick : false,
					closeOnBodyClick: true,
					buttons	: [ annullButton, okButton ]
			};	
			Object.append(options,this.options.confirm);
			var modalBox=new ng.wii.Window.Modal(options);
			modalBox.raise();
			modalBox.open();
		}
	}	
});
//
ng.wii.tag("button",ng.wii.Button);
/***
 *
 */
ng.wii.CheckAll=new Class({
	Implements: [Options,Events],
	options	: {
		parent: null,
		checkboxMatcher : null
	},
	/***
	 * class constructor.
	 * @param element
	 * @param options
	 */
	initialize: function(element,options){
		this.setOptions(options);
		this.element=$(element);
		if(typeof this.options.checkboxMatcher == "string"){
			this.options.checkboxMatcher = new RegExp(this.options.checkboxMatcher);
		}
		if(this.options.parent){
		  this.parent=this.element.getParent(this.options.parent);
		  this.element.addEvent("click", function(ev){
			 var self=this;
			 this.parent.getElements("input[type='checkbox']").each(function (checkbox){
				 if(self.options.checkboxMatcher.test(checkbox.name)){
					 checkbox.checked = self.element.checked;
				 }
			 });
		  }.bind(this));
		}
	}
});
ng.wii.tag("checkall",ng.wii.CheckAll);
//
