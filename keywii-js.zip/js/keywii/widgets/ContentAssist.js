/***
 * KeyWII - Keyone Widget For Internet
 * @copyright	Copyright (c) 2003-2017, NGUYEN S.n.c.
 * @license		MIT-style license
 */
Jpackage({
	name	: "ng.wii",
	title		: "KeyONE WIdget library for Internet",		
	version		: 2.0,
	"@company"	: "NGUYEN S.n.c.",
	"@copyright": "Copyright(C) 2003-2017 by NGUYEN S.n.c.",
	"@license"	: "MIT-style license",
	tags	:{
		'content-assist': 'ContentAssist'
		//,'form-validator': 'FormValidator'
	}
	,ContentAssist : new Class({
		Extends : MooContentAssist,
		options: {
			 delay : 1000
			,nsDot : "."
			,wordSepRegexp: /^\w$/
			,listSeparator: ','
			,vocabularyRequest : {
			   url : null
			  ,param: null
			  ,method: "GET"
			  ,data : {}
			  ,postVar: null
			  ,binding : {
				  "items" : "results"
			  }
			}
			,vocabularyManager_Extract: function(namespace,vocabulary){
				var extractedVocabulary=[];
				var value = null;
				if(typeof(namespace)=="string")
					value = namespace;
				else{
					if(namespace[0]=="/")
					  value = "";
					else
					  value=namespace.join(this.options.nsDot);
				}
				for(var p in vocabulary){
					if(value=="" || value=="*" || p.indexOf(value)>=0)
					  extractedVocabulary.push(p);
				}
				extractedVocabulary.sort();
				return extractedVocabulary;
			}	
		 }
		,initialize: function(options,el){
			if($(el)){
				options.source = $(el);
			}
			this.parent(options);
			this.options.source.removeEvent("keyup");
			this.options.source.addEvents({
			  "keyup": function(ev){
				this._setSourceCaretPosition();
				if (this.getAssistWindow()!==null||this.options.aggressiveAssist) {
					//removed control, for strange behaviour when selecting all with control+a
					//if(!ev.control && ev.key.length == 1 && !ev.key.test(this.options.wordSepRegexp)) {
					if((ev.key.length==1 || ev.key=='backspace' || ev.key=='space' || ev.key=='delete')
					   /*&& !ev.key.test(this.options.wordSepRegexp)*/)
					{
						if(ev.type=="keyup"){
							//this.fireEvent("start",this);
							this.onstart(ev);
						}
					}
				}
			  }.bind(this)
			});
		}
		,onstart: function(ev){
			if(ev.type=="keyup"){
				if(this.delayTimer)
					clearTimeout(this.delayTimer);	
				this.delayTimer = this.start.delay(this.options.delay,this,[ev]);
			}			
		}
		/***
		 * get the vocabulary
		 */
		,getVocabulary: function(namespace) {
			if(typeof(this.options.vocabularyRequest.url)=="string"){
				var currentNamespace = namespace;
				this._currentVocabulary = null;
			    var extractedVocabulary =	null;
			    var namespaceData = this.options.vocabularyRequest.data;
			    if(this.vocabularyRequest){
			    	this.vocabularyRequest.cancel();
			    	this.vocabularyRequest=undefined;
			    }
				if (this.vocabularyRequest === undefined) {
					//namespaceData = this.options.vocabularyLoader.param+"="+currentNamespace.join("."); 
					var self=this;
					this.vocabularyRequest = new Request.JSON({
						secure: true,
						url: this.options.vocabularyRequest.url,
						method: this.options.vocabularyRequest.method,
						//data: namespaceData,
						async: false,
						link: "cancel",
						onSuccess: function(object) {
							//this.currentVocabulary = obj;
							self.fireEvent("vocabularyLoad", [self,object]);
						},
						onFailure: function(xhr) {
							var messageEl = this._createMessage(this.options.labels.ajaxError);
							this.setAssistWindowContent(messageEl);
						}.bind(this)
					});
				}
				else {
					this.vocabularyRequest.cancel();
				}
				this.currentVocabulary = null;
				//var reqObj = {};
				//reqObj[this.options.vocabularyUrlParam] = currentNamespace;
				var postVar
				if((postVar=this.options.vocabularyRequest.postVar)){
					var value="";
					if(!(currentNamespace instanceof Array))
						value = currentNamespace;
					else{
						if(currentNamespace[0]=="/")
							value="";
						else{
							value = currentNamespace.join(this.options.nsDot);
						}
					}
					namespaceData[postVar] = "*"+value+"*";
				}
				var queryString = Object.toQueryString(namespaceData);
				this.vocabularyRequest.send(queryString);
				extractedVocabulary = this.options.vocabularyManager_Extract.call(this,currentNamespace,this.currentVocabulary);	
				return extractedVocabulary;
			}else{
			  var extractedVocabulary = this.options.vocabularyManager_GetVocabulary.call(this,namespace);
			  return extractedVocabulary;
			}
		}
	   ,getNameSpace: function(string) { 
			var namespace = [];
			if(!this.options.listSeparator){
			  namespace = this.parent(string);
			}else{
			  namespace=this.parseNamespace(string,null,this.options.listSeparator);
			}
			return namespace;
		}
	    ,parseNamespace:function(nameSpaceString,caretPosition,listSeparator){
	    	var namespace=[];
			if (nameSpaceString===undefined) { nameSpaceString=this.getSourceValue(); }
			if (typeOf(caretPosition)!="number") {
				caretPosition=this.getSourceCaretPosition();
			}
			var wordIndex=0;
			for(var i=nameSpaceString.length-1;i>=0;i--){
				if(nameSpaceString.charAt(i)==listSeparator){
					wordIndex=i+1;
					break;
				}
			}
			namespace = [nameSpaceString.substring(wordIndex)];
			return namespace;
	    }
	})
});