/***
 * KeyWII - Keyone Widget For Internet
 * @copyright	Copyright (c) 2003-2017, NGUYEN S.n.c.
 * @license		MIT-style license
 */
Jpackage({
name	: "ng.wii",
title		: "KeyONE WIdget library for Internet",		
version		: 2.0,
"@company"	: "NGUYEN S.n.c.",
"@copyright": "Copyright(C) 2003-2017 by NGUYEN S.n.c.",
"@license"	: "MIT-style license",
tags	:{
	'frame'	: 'Frame',
	'form-validator' : 'FormValidator'
},

/***
 * @class: wii.forms.Frame
 */
Frame: new Class({
	Extends : ng.wii.Widget,
	options	: {
		require: {
		}
	},
	initialize : function wii$Forms(el,options) {
		this.parent(el,options);
		this.addEvent("load",this.notice.bind(this));
	},
	notice: function(){
		if(this.submitAction){
			this.fireEvent("notice",['ok',this.submitTarget,this]);
			this.submitAction=null;
		}
	},
	onFailure: function(xhr){
		if(this.hasEvent("error")){
			this.hideLoading();
			this.fireEvent("error",["error", this.submitTarget, this]);
		}else
			this.parent(xhr);
	},
	/***
	 * 
	 */
	onsubmit: function(ev){
		var form=ev.target;
		var fv=form.retrieve("validator");
		if(fv)
			return false;
		else {
			return this.submit(ev);
		}
	},
	/***
	 * submit the form.
	 * @param ev
	 * @param form
	 */
	submit: function(ev,target,validate){
		target=target || ev.target;
		var form = null;	//target.tagName=="FORM" ? target : target.getParent("form");
		if(target.tagName=="FORM"){
			form=target;
		}else if(this.element.getElement("FORM")){
			form = target.getParent("form");
		}
		var submitter = form || this.element;
		var wiiButton = $(target).retrieve("wii-button");
		if(wiiButton && wiiButton.options.postData){
			for(var p in wiiButton.options.postData){
				actionInput = new Element("input",{
					type: "hidden",
					name: p,
					value: wiiButton.options.postData[p]
				});
				actionInput.inject(submitter);
			}
		}
		//if(wiiButton && wiiButton.options.action){
			//TODO:submitter.action = wiiButton.options.action;
		//}
		var buttonValue = ng.wii.Frame.getButtonValue(target,wiiButton);
		var data= form ? Jelement.toData(form): Jelement.toData(this.element);
		if(target.tagName=="BUTTON" /*&& !this.submitAction*/){
			this.submitAction = {};
			this.submitAction[target.name] = buttonValue;
		}
		if(this.submitAction)
			Object.append(data,this.submitAction);	
		var options=data;
		if(form && form.action!=""){
			options={url: form.action, data: data};
		}
		this.load(options);
		return false;
	},
	/****
	 * navigate to url.
	 * @param ev
	 */
	navigate: function(ev){
		if(!this.hasLoader())
			return;
		switch(ev.target.tagName){
		case 'A':
			if(ev.target.href!=""){
			  var options={url: ev.target.href};
			  var uri = new URI(options.url);
			  var myuri = new URI(this.options.load.url);
			  var url = uri.get("scheme")+"://"+uri.get("host")+":"+uri.get("port")+"/"+uri.get("directory")+"/"+uri.get("file");
			  var myurl = myuri.get("scheme")+"://"+myuri.get("host")+":"+myuri.get("port")+"/"+myuri.get("directory")+"/"+myuri.get("file");
			  if(!ev.target.target || ev.target.target=="_self" /*url == myurl*/){
				  if(ev.target.get("wii-options") && ev.target.get("wii-options")!=""){
					  var opts=JSON.decode(ev.target.get("wii-options"));
					  if(opts.data)
						  options.data=opts.data;
				  }
				  options.data = options.data || {};
				  Object.append(options.data,uri.getData());
				  ev.stop();
				  this.load(options);
			  }
			}
			break;
		}
	},
	/****
	 * returns the renderer of given input.
	 * @param input
	 */
	getSubmiter: function(ev){
		var parent=$(ev.target).getParent();
		var renderer=null;
		while(parent){
			if(parent.renderer && parent.renderer.hasLoader && parent.renderer.hasLoader()){
				renderer= parent.renderer;
				break;
			}
			if(parent.getParent()!=parent)
				parent=parent.getParent();
			else
				break;
		}
		return renderer;
	},
	/***
	 * parse the input button and returns the specified action. 
	 */
	parseInputAction: function(input){
		var action=null,options={};
		if(input.get("wii:options") && input.get("wii:options")!=""){
			options=JSON.decode(input.get("wii:options"));
		}		
		switch(input.tagName){
		case 'INPUT':
			if(input.type in {'button':1,'submit':1,'reset':1}){
				action={};
				var path=input.name.split(":");
				action[path[0]] = path[1];
			}
			break;
		case 'BUTTON':
			action= {};
			if(input.value==''){
				var path=input.name.split(":");
				action[path[0]] = path[1];
			}else{
				action[input.name] = input.value;
			}
			break;
		}
		if(action)
			Object.append(action,options);
		return action;
	},
	/***
	 * on click event handler.
	 * @param ev event
	 */
	onclick: function(ev){
		var action=null;
		var done=false;
		if(this.getSubmiter(ev) != this){
			return;
		}
		var target=ev.target;
		if(target.tagName == 'IMG'){ // && !(target.tagName in {'A':1,'BUTTON':1,'INPUT':1})
			var parent;
			if((parent=target.getParent("A,BUTTON,INPUT"))){
				target=parent;
			}
		}
		switch(target.tagName){
		
		case 'A':
			if(target.target=="" && this.hasLoader() && this.getSubmiter(ev) == this){
				this.navigate(ev);
				return;
			}
			break;
			
		case 'INPUT':
		case 'BUTTON':
			action = this.parseInputAction(target);
			break;
		}
		if(target.form && action && !done){
			this.submitTarget=target;
			this.submitAction=action;
		}
		if(target.name && action && action[target.name] && typeof this[action[target.name]] == "function"){
			ev.stop();
			this[action[target.name]](ev);
		}else if(!this.element.getElement("FORM") && this.hasLoader() && action){
			ev.stop();
			this.submit(ev,target);
		}	
	},
	/***
	 * on form validation event handler.
	 * @param valid
	 * @param ev
	 * @param object
	 */
	onFormValidate: function(valid,target,ev){
		if(valid){
			this.submit(ev, target);
		}
	},
	/***
	 * on html load event handler.
	 * @param responseTrees
	 * @param responseElements
	 * @param responseHtml
	 * @param responseScripts
	 */
	onLoad: function(response){
		this.hideLoading();
		var me=this;
		this.forms=this.getElement().getElements("form");
		this.forms.each(function(form){
			var fv = form.retrieve('validator');
			if(fv){
				fv.removeEvents("formValidate");
				fv.addEvent("formValidate", me.onFormValidate.bind(me));
			}
			form.removeEvents("submit");
			form.removeEvents("click");
			form.addEvent("submit",me.onsubmit.bind(me));
			form.addEvent("click",me.onclick.bind(me));						
		});
		if(!this.forms.length){
			this.element.removeEvents("submit");
			this.element.removeEvents("click");	
			this.element.addEvent("click",me.onclick.bind(me));	
			//this.element.addEvent("keydown",me.onkeypress.bind(me));
			//this.element.addEvent("keyup",me.onenter.bind(me));
			this.element.addEvent("keydown",me.onenter.bind(me));			
		}
		this.parent(response);
	},
	/***
	 * 
	 * @param ev
	 */
	onenter: function(ev){
		switch(ev.key){
		case "enter":
			var button;
			if(!this.element.getElement("FORM") && this.hasLoader() 
				&& (button=this.element.getElement("button[type='submit']"))!=null
				&& !button.disabled)
			{
				ev.stop();
				this.submit(ev,button);
			}
			break;
		}
	}
}),
/***
 * The class extends the Form.Validator.Inline class.
 * @class: wii.forms.Validator
 */
FormValidator: new Class({
	Extends	: Form.Validator.Inline,
	Jtag	: 'form-validator',
	options	: {
		errorPrefix : '',
		evaluateFieldsOnBlur : false,
		ignoreHidden : false,
		ignoreValidateReferenceOnSubmit : true,
		remoteValidator: {
			// URL of the remote validator
			url: null, 
			// initial data to pass to remote validator.
			data: {		 	
			}
		},
		serial : false,
		validators: {			
		}
	},
	/***
	 * Validator class constructor.
	 * @param el html element
	 * @param options validator options.
	 */
	initialize: function wii$form$Validator(el,options) {
		this.setOptions(options);
		this.parent($(el),this.options);
		this.addValidators();
		this.element = $(el);
		this.addEvents({
			"formValidate": this.onFormValidate.bind(this),
			"elementValidate" : this.onElementValidate.bind(this),
			"elementPass" : this.onElementPass.bind(this)
		});
		
		if(!this.options.ignoreHidden){
		  var inputs = $(el).getElements("input[type=hidden]");
		  for(var i=0; i<inputs.length; i++){
			var input = inputs[i];
			this.ignoreField(input);
		  }
		}
	},
	/***
	 * add customized validators.
	 */
	addValidators: function (){
		for(var validator in ng.wii.FormValidator.validators)
			this.add(validator,ng.wii.FormValidator.validators[validator]);
		for(var validator in this.options.validators)
			this.add(validator,this.options.validators[validator]);
	},
	/***
	 * 
	 */
	validate:function(options){
		var ignoreValidateReferenceOnSubmit = 
			  options && options.onsubmit && 
			  (options.ignoreValidateReferenceOnSubmit || this.options.ignoreValidateReferenceOnSubmit);
		if(ignoreValidateReferenceOnSubmit){
			var fields = this.element.getElements(
					".wii-validate-reference, .wii-validate-domain-value");
			for(var i=0; i<fields.length;i++){
				//this.ignoreField(fields[i]);
				fields[i].checkOptionalOnly=true;
			}
		}
		return this.parent();
	},
	/***
	 * add the fields to be watch
	 */
	watchFields: function(fields){
		this.parent(fields);
	},
	/***
	 * form-validate event handler.
	 */
	onFormValidate: function(validationPassed, form, ev) {
		if(validationPassed){
			if (this.options.remoteValidator.url){
				
			}
		}
	},
	onElementValidate: function(validationPassed, input, validatorName, isWarning) {
		//if(validationPassed){
			//if (this.options.remoteValidator.url){
				//alert(this.options.remoteValidator.url);
			//}
		//}
	},
	/***
	 * 
	 */
	onElementPass: function(input) {
		//if(input){
			//if (this.options.remoteValidator.url){
				//alert(this.options.remoteValidator.url);
			//}
		//}
	}
})
});
/***
 * Frame static methods.
 */
Object.append(ng.wii.Frame,{
	/****
	 * returns the renderer of event target.
	 * @param input
	 */
	getSubmiter: function(ev,target){
		target = target || ev.target;
		var form=$(target).getParent("form");
		var parent=$(target).getParent();
		var renderer=null;
		var load=null;
		while (parent){
			if (parent.renderer && parent.renderer.hasLoader && parent.renderer.hasLoader()){
				renderer= parent.renderer;
				break;
			}else if((load=parent.get("load"))){
				if (load.url && load.url!=''){
					renderer=parent;
					break;
				}
			}
			if (parent.getParent() != parent)
				parent=parent.getParent();
			else
				break;
		}
		return renderer || form;
	},
	/***
	 * 
	 */
	getButtonValue: function(button,wiiButton){
		wiiButton = wiiButton || button.retrieve("wii-button");
		return $(button).get("wii-value") ? $(button).get("wii-value") : 
				 (wiiButton && wiiButton.options.value ? wiiButton.options.value :button.value); 
	},
	/***
	 * submit a form.
	 * @param ev
	 */
	submit: function(ev,targetp,validate){
		var target = targetp || ev.target;
		var submitter = this.getSubmiter(ev,target);
		if(submitter.submit){
			ev.stop();
			var wiiButton;
			if(submitter.tagName == "FORM" && (submitter.get("load")==null || !submitter.get("load").url)){
				var sep = "?";
				if(submitter.action && submitter.action.indexOf("?")>=0)
					sep="&";
				if(submitter.action){
				  //submitter.action += sep+target.name+"="+target.value;
				  wiiButton = $(target).retrieve("wii-button");
				  var buttonValue = ng.wii.Frame.getButtonValue(target,wiiButton);
				  var actionInput = new Element("input",{
					type: "hidden",
					name: target.name,
					value : buttonValue
				  });
				  actionInput.inject(submitter);
				  if(wiiButton && wiiButton.options.postData){
					  for(var p in wiiButton.options.postData){
						  actionInput = new Element("input",{
							  type: "hidden",
							  name: p,
							  value: wiiButton.options.postData[p]
						  });
						  actionInput.inject(submitter);
					  }
				  }
				  if(wiiButton && wiiButton.options.action){
					  submitter.action = wiiButton.options.action;
				  }
				}
			}
			if(submitter && submitter.tagName == 'FORM' && validate){
				var fv = submitter.retrieve('validator');
				if(fv && !fv.validate({onsubmit:true})){
					if(wiiButton && wiiButton.options.errorBox){
						//alert(wiiButton.options.errorMsg);
					    var infoBox=new ng.wii.Window.Modal({
					        width	: '300px',
					        height  : '50px',
					        container: $(document.body),
					        title	: wiiButton.options.errorBox.title,
					        content	: wiiButton.options.errorBox.errorMsg,//$("applicationException").get("html"),
					        target 	: $(document.body)
					    });
					    infoBox.open();	  						
					}
					return true;
				}
				
			}	
			//ng.wii.Loader.showLoading(submitter);
			if(validate)
			if(!submitter.element || !submitter.options.load || !submitter.options.load.url){
			  new ng.wii.Window.Modal({
		        width	: '250px',
		        height  : '80px',
		        closeInTitle: false,
		        closeOnBodyClick: false,
		        container: $(document.body),
		        title	: "Please wait...",
		        content	: "<div class='wii-loading' style='top:-5%;'></div>",
		        target 	: $(document.body)
		      }).open();
			}
			submitter.submit(ev,target,validate);
		}
	}
	
});

/***
 * defines the default validators
 */
Object.append(ng.wii.FormValidator,{
	// reference validator
	validators: {
		"validate-reference" : {
			errorMsg: function(element, props){ 
				var path=element.name.split(".");
				var errorMsg = (props.errorType=='required'? props.requiredMsg : props.errorMsg);
				var tpl = new Jtemplate(errorMsg);
				return tpl.apply({title: props.title, value: element.value});
			},
			test : function(element, props){
				var path=element.name.split(".");
				props.errorType='';
				if(!element.checkOptionalOnly && element.value){
					var clientOpt=props.client;
					var lookup = $(element).retrieve("wii-lookup") 
					 		     || $(element).retrieve("wii-lookup-popup");

					clientOpt.async=false;
					var client = new Jclient(clientOpt);
					var data= props.data || {};
					var postVar=path[path.length-1];
					if(lookup && lookup.options.postVar)
						postVar = lookup.options.postVar;
					data[postVar]=element.value;
					var submiter = ng.wii.Frame.getSubmiter(null,element);
					ng.wii.Loader.showLoading(submiter || $(document.body));
					client.send(data);	
					ng.wii.Loader.hideLoading(submiter || $(document.body));
					if(client.getItems().length==0 
						|| !client.getItems()[0] 
					    || !Jobject.get(client.getItems()[0],postVar))
					{
						if(lookup){
							lookup.resetChoice(null,true,false);
						}
						props.errorType="referenced-not-found";
						return false;
					}
				}else if(!element.value){ // clear the choice
					var lookup = $(element).retrieve("wii-lookup") 
									|| $(element).retrieve("wii-lookup-popup");
					if(lookup){
						lookup.resetChoice(null,true,true);
					}
					if(props['data-validators'].indexOf("required")>=0){
						props.errorType='required';
						props.requiredMsg = props.requiredMsg;
						return false;
					}
				}
				return true;
			}				
		},
		/***
		 * domain value validator
		 */
		"validate-domain-value" : {
			errorMsg: function(element, props){ 
				var path=element.name.split(".");
				var errorMsg = (props.errorType=='required'? props.requiredMsg : props.errorMsg);
				var tpl = new Jtemplate(errorMsg);
				return tpl.apply({title: props.title, value: element.value});
			},
			test : function(element, props){
				if(!element.checkOptionalOnly && element.value){
					var clientOpt=props.client;
					clientOpt.async=false;
					var client = new Jclient(clientOpt);
					var data= {};
					var submiter = ng.wii.Frame.getSubmiter(null,element);
					ng.wii.Loader.showLoading(submiter || $(document.body));
					client.send(data);	
					ng.wii.Loader.hideLoading(submiter || $(document.body));
					if(client.getItems().length==0 || client.getItems().indexOf(element.value)<0)
						return false;
				}else if(!element.value){
					if(props['data-validators'].indexOf("required")>=0){
						props.errorType='required';
						props.requiredMsg = props.requiredMsg;
						return false;
					}					
				}
				return true;
			}				
		}
		,"validate-email-list" : {
			errorMsg: function(element, props){ 
				var tpl = new Jtemplate("La lista di email non e' valida!");
				return tpl.apply(element.value);
			},			
			test : function(element,props){
				if(element.value){
					var member_split = element.value.split(',');

					for (var n = 0; n < member_split.length; n++) {
						var member_info = member_split[n].trim();
						var validRegExp = /^\w+((-\w+)|(\.\w+))*\@[A-Za-z0-9]+((\.|-)[A-Za-z0-9]+)*\.[A-Za-z0-9]+$/;

						if (member_info.search(validRegExp) == -1) {	
							return false;
						}
					}
				}
				return true;
			}
		}
	},
	/***
	 * add new validators
	 */
	addValidators: function(validators){
		for(var validator in validators){
			this.validators[validator] = validators[validator];
		}
	}
});

