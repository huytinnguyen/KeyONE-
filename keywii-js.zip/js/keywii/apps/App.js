Jpackage({
  name: "ng.wii",
  '@company'	: "NGUYEN S.n.c.",
  '@copyright': 'Copyright (C) 2006-2017, NGUYEN S.n.c.',
  '@license'	: "MIT-style license",
  
  tags: {
	'app': 'App'  
  },
  /***
   * Internet application class.
   */
  App: new Class({
	Implements	: [Options,Events],
	options		: {
		assets	: {
			javascript	: null,
			css			: null,
			image		: null
		},
		widget	: {
			type		: ng.wii.Window,
			load		: {},
			minWidth	: 0,
			minHeight	: 0,
			maxWidth	: 0,
			maxHeight	: 0,
			top			: 0,
			left		: 0
			//,width	: 0
			//,height	: 0
		},
		data	: {
			
		}
	},
	/***
	 * class initializer.
	 * @return
	 */
	initialize	: function (options){
		this.setOptions(options);
	},
	/***
	 * open the application with parameters.
	 */
	open : function(options,targetEl) {
		options=options || {};
		if(!options.widget && !options.data)
			options={data: options};
		var myoptions=this.options;
		var opts=Jobject.merge(myoptions,options);
		var widget=this.createWidget(opts,targetEl);
		widget.show();
		return widget;
	},
	/**
	 *
	 */
	createWidget: function(options,targetEl) {
		var type=options.widget.type;
		options.widget.type=null;
		if(options.widget.load)
			options.widget.load.data=options.data;
		var widget=new type(targetEl,options.widget);
		//widget.show();
		return widget;	
	}
  })
});