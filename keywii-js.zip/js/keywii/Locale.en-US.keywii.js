Locale.define('en-US','keywii',{
	REFERENCE_NOT_VALID: "The reference value: {.} is not valid!",
	button_annull: "annull",
	button_ok: "OK",
	confirm_window_title: "confirm"
});