/***
 * Javascript Object Oriented Framework.
 * @version		2.1
 * @copyright	Copyright (c) 2003-2017 by NGUYEN S.n.c.
 * @license		MIT-style license
 */
/****
 * @class Jbinder
 * Data biding class.
 */
Jbinder=new Class({
	Implements : [Options],
	options	   : {
		checkAttribute: false, // controlla l'esistenza degli attributi durante il binding
		binding	 : {
			// @syntax: la sintassi dell'oggetto binding :
			// attribute-path : 
			//   (string | function | Jtemplate) | 
			//   { name: string|function|Jtemplate [, type: function] [,componentType: function] [,format: String] }
			// per esempio: 
			// "name" 		: "nome" ,
			// "addresses"	: { name: "indirizzi", type: Array, componentType: Indirizzo },
			// "date" 		: { name: "data", type: Date, format: "%Y/%m/%d" }
		}
	},
	/****
	 * class constructor.
	 */
	initialize : function Jbinder(options) {
		this.setOptions(options);
	},
	/***
	 * bind the given data to this.
	 * @param data (object) the given data to be loaded into this using the attribute binding specified in options.
	 * @param check (boolean) check the validity of the input data.
	 */
	bind: function(data,dest,check){
		dest = dest || this;
		check=check || this.options.checkAttribute;
		for(var p in this.options.binding){
			var value,getValue=false;
			var binder;
			var property=this.options.binding[p];
			if(property.constructor != Object)
				binder=property;
			else
				binder=property.name;
			if(binder instanceof Jtemplate){
				var tpl=binder;
				value=tpl.apply(data);
				getValue=true;
			}else if(typeof binder == "string"){
				if(/\{[^\}]+\}/.test(binder)){
					var tpl=new Jtemplate(binder);
					value=tpl.apply(data);
				}else {
					value=Jobject.get(data,binder);
				}
				getValue=true;
			}else if(typeof binder == "function"){
				value=binder.call(dest,data);
				getValue=true;
			}else{
				value=binder;
				getValue=true;
			}
			if(getValue){
				if(property.constructor == Object){
					value=this.convert(value, property.type, property.componentType);
				}
				if(!check || p in dest){
					Jobject.set(dest, p, value);
				}else if(!(p in dest))
					throw "Attribute: "+p+" does not exists!";
			}
		}
	},
	/***
	 * @private
	 * The method converts the given value into the specified type. If the given value is an array, it converts
	 * all the array components into the specified component type.
	 * @param value (object) the given value.
	 * @param type (function) the target type.
	 * @param componentType (function) the array component type.  
	 */
	convert: function(value, type, componentType){
		if(!value && typeof value != "number")
			return value;
		if(!type){
			// do nothing
		}else if(type == Array || value instanceof Array){
			if(value && componentType){
				for(var i=0; i<value.length; i++){
					value[i] = this.convert(value[i],componentType);
				};
			}
		}else if(type == String || type == Object || type == Number || type == Date){
		}else if(typeof type=="function"){
			value = new type(value);
		}	
		return value;
	}
});
/***
 * @class Jbean
 * The general purpose bean class.
 */
Jbean = new Class({
	/***
	 * bean constructor.
	 */
	initialize : function(source){
		if(source && source.constructor == Object){ // is json object
			Jobject.apply(source,this);
		}else if(source){ //wraps the source object
			this._source = source;
		}
	},
	/***
	 * returns the attribute value.
	 * @param name attribute name.
	 */
	get: function(name){
		var self = this._source || this;
		return Jobject.get(self, name, true);
	},
	/***
	 * set the attribute value.
	 * @param name attribute name/oath.
	 * @param value
	 */
	set: function(name,value){
		var self = this._source || this;
		return Jobject.set(self, name, value, true);
	}
});
/***
 * 
 */
Jtoken= new Class({
	type	: null,
	text	: "",
	initialize: function(options) {
		options = options || {};
		Object.append(this,options);
	},
	toString: function(){
		if(this.type.template){
			var template=new Jtemplate(this.type.template);
			return template.apply(this);
		}
		return this.text;
	}
});
/***
 * 
 */
Object.append(Jbean,{
	TOKENS_PATTERN: "(\\[[^\\]]+\\])|(\\.[^\\.]+)|([a-zA-Z0-9_\\$]+)",
	TOKENS:[
		{code: "[", template: "[{text}]"},
		{code: ".", template: ".{text}"},
		{code: "NAME", template: null}
	],
	/***
	 * parse the bean attribute path that can be:
	 * - <name>{[<name>]...}
	 * - <name>{.<name>...}
	 * for example:
	 * - 1[name][addresses][0][city]
	 * - 1.name.addresses.0.city
	 * - 1[name].addresses[0].city
	 * @param path
	 */
	parseName: function(path){
		var pattern = new RegExp(this.TOKENS_PATTERN,"g");
		var Matcher = new RegExp(this.TOKENS_PATTERN);
		var result=[];
		var self=this;
		path && path.replace(pattern, 
			function(match){
				//return self.replaceMatch(match,object)
			    var el=match;
	    		var matcher = Matcher.exec(match);
	    		if(matcher[1]){
	    			el=new Jtoken({type: self.TOKENS[0], text: match.substring(1,match.length-1)});
	    		}else if(matcher[2]){
	    			el=new Jtoken({type: self.TOKENS[1], text: match.substring(1)});
	    		}else if(matcher[3]){
	    			el=new Jtoken({type: self.TOKENS[2], text: match});
	    		}
	    		result.push(el);
	    		return match;
			});	
		return result;
	}	
});
/***
 * @class Jdataset
 * <p>
 * The class manages a json dataset with data binding. 
 * </p>
 * <p>
 * <h3>Syntax:</h3> new Jdataset(data[,options]);
 * </p>
 * <p>
 * <h3>Arguments:</h3>
 * <li>data: (Object,optional) the initial data. </li>
 * <li>options: (Object,optional) dataset options (see below).</li>
 * </p>
 * <p>
 * <h3>Options:</h3>
 * <li>componentType: the item type of dataset.</li>
 * <li>binding: dataset binding with following attribute mapping: 
 *   <ul>
 *     <li>start: the initial record.</li>
 *     <li>count: the record count.</li>
 *     <li>total: the total of record in the data store.</li>
 *     <li>items: the item array.</li>
 *   </ul>
 * </li>
 * </p>
 * <p>
 * For example:
 * </p>
 * <pre>
 *   MyDataset = new Class({
 *   	Extends: Jdataset,
 *      options: {
 *      	componentType : MyClass,
 *      	binding: {
 *      	  start	: {name: "rsStart", type: Number},
 *      	  count : {name: "rsCount", type: Number},
 *      	  total : "rsTotal",
 *      	  items : {name: "rsResults", type: Array}
 *      	}
 *      }
 *   });
 *   var myDataset=new MyDataset({
 *   	rsStart : 0,
 *      rsCount : 2,
 *      rsTotal : 2000,
 *      rsResults: [
 *      	{ countId: 198789, customerId: 98989, amount: 20000 },
 *      	{ countId: 222222, customerId: 77777, amount: 120000 },
 *      ]
 *   });
 *   var myamount=myDataset.getItem(0).amount; // myamount == 20000
 * </pre>
 */
Jdataset=new Class({
	Extends	: Jbean,
	Implements: [Jbinder,Events],
	options	: {
		componentType : Jbean,
		binding	: {
			start	: {name: "start"},
			count	: {name: "count"},
			total	: {name: "total"},
			items	: {name: "items", type: Array},
			contentType: {name: "contentType", type: Function}
		}
	},
	start	: 0,
	count	: 0,
	total	: 0,
	current	: 0,
	items	: [],
	/***
	 * class constructor.
	 * @param source
	 * @param options
	 */
	initialize : function JdataSet(source, options){
		this.setOptions(options);
		if(this.options.binding.items.constructor == Object && !this.options.binding.items.componentType){
			this.options.binding.items.componentType = this.options.componentType;
		}
		if(source){
			this.bind(source);
		}
	},
	setItems: function(items){
		this.items=Jobject.splat(items);
	},
	/***
	 * returns the item list of the dataset.
	 * @returns {Array}
	 */
	getItems: function() {
		if(!(this.items instanceof Array))
			this.items=Jobject.splat(this.items);
		return this.items;
	},
	/***
	 * returns i'th item.
	 * @param i index
	 * @returns
	 */
	getItem: function(i){
		if(i>=0 && i<this.getItems().length)
			return this.getItems()[i];
	},
	/***
	 * set the i'th item.
	 * @param i item index.
	 * @param item item.
	 * @returns
	 */
	setItem: function(i,item){
		if(i>=0){
			if(i<=this.getItems().length)
				return this.getItems()[i]=item;
			else{
				this.getItems().push(item);
				return item;
			}
		}
	},
	/***
	 * returns the first item.
	 * @returns (Object) the first item.
	 */
	getFirst: function() {
		return this.getItems()[0];
	},
	/***
	 * returns the last item.
	 * @returns (Object) the last item.
	 */
	getLast: function() {
		if(this.getItems().length>0)
			return this.getItems()[this.getItems().length-1];
	},
	/***
	 * load the data into dataset.
	 * @param data the data to be loaded in dataset.
	 */
	loadData: function(data){
		//Jdataset.call(this,data);
		this.bind(data);
	},
	/***
	 * return dataset size.
	 * @returns (number) the size of the item list.
	 */
	getSize: function() {
		return this.getItems().length;
	},
	size: function() {
		return this.getItems().length;
	},
	setCurrent: function(i){
		this.current=i;
	},
	getCurrentItem: function(){
		return this.getItem(this.getCurrent());
	}
});
/***
 * @class Jcontroller.
 * <p>
 * The class manages the data loading by XHR/script-tag. It extends the Jdataset class width data binding.
 * </p>
 * The class has following options:
 * <li>url: json data source url</li>
 * <li>data: query data/parameters.</li>
 * <li>ajaxOptions : ajax options</li>
 */
Jcontroller=new Class({
	Extends	: Jdataset,
	id		: null,
	useJSONP: false,
	options: {
		url		: null, // json data source url
		method	: "GET",
		encoding: "iso-8859-1",
		async	: true,
		data	: {},
		headers	: {
			"Accept": "application/json"
			,"X-Response-Encoding" : "iso-8859-1"
			//,"Content-Type" : "application/json"
		},
		// JSONP options
		callbackKey: "js:clbk",
		secure	: false,
		timeout	: 60000 // in ms
	},
	/***
	 * class constructor.
	 * @param options
	 * @param data
	 */
	initialize : function Jcontroller(options,data) {
		options = options || {};
		data = data || {};
		this.parent(data,options);
		this.uri=new URI(this.options.url);
	},
	/***
	 * return controller identifier.
	 * @returns
	 */
	getId: function() {
		return this.id;
	},
	/***
	 * Ajax on-success handle.
	 * @param text
	 * @param data
	 */
	onload: function(data,text){
		/*
		var xml;
		if(this.options.method.toLowerCase()!="get"){
			xml = text;
			text = data;
			data = null;
		}*/
		if(!data && text)
			data=JSON.decode(text);
		this.loadData(data);
		this.fireEvent("load",[data]);
		this.fireEvent("success",arguments);		
		//if(this.useJSONP)
			//this.fireEvent("complete",arguments);
		//else
		//this.fireEvent("success",arguments);	
	},
	/***
	 * Ajax on-error handle.
	 * @param xhr
	 */
	onerror: function(xhr){
		this.fireEvent("failure",[xhr]);
		if(xhr.status>=400){
			alert("ERROR: "+xhr.statusText);
		}
	},
	ontimeout: function() {
		//this.request=null
		throw "Timeout verified: "+this.options.timeout;
	},
	/***
	 * loads the data from server.
	 * @param params loading query parameters
	 */
	load: function(params) {
		params = params || {};
		if(!params.data && !params.url){
			params={data:params};
		}
		var options = Jobject.clone(this.options);
		options.binding=null;
		options.data = options.data || {};
		
		options.url = options.url || this.uri.toString();
		if(options.method.toLowerCase()!="post")
			Jobject.apply(params,options, Japply.merge);
		
		var req;
		var myuri=new URI();
		var useJSONP=false;
		
		if(myuri.getHostURL() != this.uri.getHostURL()){
			options.onComplete=this.onload.bind(this);
			options.onTimeout=this.ontimeout.bind(this);
			req=new Request.JSONP(options);
			this.useJSONP=useJSONP=true;
		}else{
			options.onSuccess=this.onload.bind(this);
			options.onFailure=this.onerror.bind(this);
			if(options.method.toLowerCase() == 'post'){
				//options.headers["Content-Type"]="application/json";
				//req=new Request.JSON(options);
				//req.setHeader("Content-Type","application/json");
				var xhr = window.XMLHttpRequest? new XMLHttpRequest() : new ActiveXObject("Microsoft.XMLHTTP");
				xhr.onreadystatechange=(function(){
					if (xhr.readyState == 4) {
						this.onReadyResponse(xhr);
					}
				}).bind(this);
				xhr.open(options.method.toUpperCase(),options.url,options.async);
				xhr.setRequestHeader("Accept","application/json");
				xhr.setRequestHeader("Content-Type","application/json");				
				req = xhr;
			}else
				req=new Request.JSON(options);
		}
		
		if(useJSONP)
			req.get();
		else if(this.options.method.toLowerCase()!="get")
			req.send(JSON.encode(params.data));
		else
			req.send();
	},
	/***
	 * 
	 */
	onReadyResponse: function(xhr){
		if(xhr.status>=400){
			var data;
			var ex;
			try {
				data=JSON.decode(xhr.responseText);
			}catch(e){
				ex=e;
				data = xhr.responseText;
			}
			if(!ex && xhr.status == 400){
			  this.loadData(data);
			  this.fireEvent("error",[data,xhr]);
			}else{
			  this.fireEvent("failure",[data,xhr]);
			}
		}else{
			var data=JSON.decode(xhr.responseText);
			this.loadData(data);
			this.fireEvent("load",[data]);
			this.fireEvent("success",[data]);
		}
	},
	/***
	 * send the load request to server.
	 * @param params query parameters.
	 */
	send: function(params){
		this.load(params);
	},
	/***
	 * set the current item.
	 * @param i
	 */
	setCurrent: function(i) {
		this.current=(i);
	},
	/***
	 * return the index of current item.
	 * @returns
	 */
	getCurrent: function(){
		return this.current;
	},
    /** 
     * select nested object by it's path 
     * @param path object path.
     * @param forUpdate create if the object is not exists for update.
     */
    getObject: function(path, forUpdate){
    	var steps;
    	steps=path.split(".");
    	var object=this;
    	for(var i=0; i<steps.length; i++){
    		var value;
    		if(i>0 || steps[i]!=this.getId()){
    			var ops=steps[i].split("[");
    			if(ops.length>1){
    				ops[1]=ops[1].split("]")[0];
    			}
    			value=Jobject.get(object,ops[0]);
    			if(value==null && forUpdate){
    				if(ops.length>1){
    					value=[];
    				}else{
    					value={};
    				}
    				object[ops[0]]=value;
    			}
    			if(value && ops.length>1){
    				var j=eval(ops[1]);
    				value=value[j];
    			}
    			if(value){
    				object=value;
    			}else
    				return null;
    		}
    	}
    	return object;
    },
    /** 
     * set the nested object attribute value.
     * @param path object path
     * @param value object value.
     */
    setObject: function(path,value){
    	var firstPath;
    	var i=path.lastIndexOf(".");
    	firstPath=path.substring(0,i);
    	lastPath=path.substring(i+1);
    	var object=this.getObject(firstPath,true);
    	Jobject.set(object,lastPath,value);
    }	
});

/***
 * web service rest client.
 */
Jclient=new Class({
	Extends: Jcontroller,
	options: (JclientOptions={
		componentType : Jbean,
		componentTypeName : null,
		method	: "GET",
		// Ajax request parameters.
		data	: {
			"scrollable-results": "false",
			"max-results"		: 25
		}
	}), 
	/***
	 * Class constructor.
	 */
	initialize: function(options,data) {
		Jobject.merge(this.options,JclientOptions);
		this.parent(options,data);
		if(this.uri && (!options.binding || !options.binding.items)){
			var file=this.uri.get("file");
			if(file){
				Object.append(this.options.binding,{"items": file});
			}
		}
		if(this.options.componentTypeName){
			this.setComponentTypeName(this.options.componentTypeName);
		}
	},
	/***
	 * 
	 */
	setComponentTypeName: function(typeName){
		this.options.componentTypeName=typeName;
		this.options.componentType = null;
	},
	/***
	 * 
	 */
	setComponentType: function(componentType){
		if(!componentType && this.options.componentTypeName && !this.options.componentType){
			var newTypeName=typeName=this.options.componentTypeName;
			var type; 
			try { 
				type= window.eval(typeName);
			}catch(e){
				
			}
			var model = {};
			if(this.getItems()[0]){
				for(var a in this.getItems()[0]){
					model[a]={title: a};
				}
			}
			if(!type){
				type = new Class({
					Extends: Jentity,
					options: {	
					},
					initialize: function(el,options){
						this.parent(el,options);
					}
				});
				try{
					eval("window."+newTypeName+"=type");
					this.options.componentType=window[newTypeName];
				}catch(e){
					  	
				}				
			}
			type.model=model;
			this.options.componentType=type;
			if(!this.options.componentType)
				this.options.componentType=Jbean;
		}else if(componentType)
		   this.options.componentType=componentType;
		return this.options.componentType;
	},
	/***
	 * load the data from server.
	 * @param data data load parameters.
	 */
	loadData: function(data){
		this.parent(data);
		if(!this.items || this.items.length==0){
			this.items = Jobject.splat(this.readJettisonResult(data));
			this.setComponentType();
		}
	},
	/***
	 * returns true if the data is empty.
	 */
	isEmpty : function(){
		if(!this.getItems() || this.getItems().length==0)
			return true;
		else if(this.getItems().length == 1){	
			if(typeof this.getItems()[0] == "string" && !this.getItems()[0])
				return true;
			if(typeof this.getItems()[0] == "object"){
				var keys=Object.keys(this.getItems()[0]);
				if(keys.length==0)
					return true;
				else if(keys.length==1 && typeof this.getItems()[0][keys[0]] == "string" && !this.getItems()[0][keys[0]])
					return true;
			}
		}
		return false;
	},
	/***
	 * returns the results as an array.
	 * @param data
	 */
	readJettisonResult: function(data){
		var result=data;
		var level = 0;
		var maxLevel=1;
		while(level <= maxLevel 
			  && !(result instanceof Array) 
			  && typeof result=="object" 
			  && Object.getLength(result)==1)
		{
			var p = Object.keys(result)[0];
			result=result[p];
			if(level==maxLevel)
				this.setComponentTypeName(p);
			level++;
		}
		return result;
	}
});
/***
 * element entity class
 */
Jentity=new Class({
	Extends	: Jbean,
	$inputs : {},
	Implements: [Options,Events],
	options : {
		autoListeners: true // setup automatically the input listeners
	},
	/***
	 * 
	 */
	initialize : function(el,options){
		options = options || {};
		this.setOptions(options);
		this.element=$(el);
		if(this.element){
			this.loadInputs();
			if(this.options.autoListeners)
				this.setupInputListeners();
		}else if(el){
			this.parent(el);
		}
	},
	/***
	 * load inputs.
	 */
	loadInputs : function(){
		Jentity.attach.bind(this)(this.element);
	},
	/***
	 * setup input listeners
	 */
	setupInputListeners: function(){
		for (var name in this.$inputs){
			var model = this.findModel(name);
			var input= this.$inputs[name].retrieve("wii-input") || this.$inputs[name];
			if(model){
				var attrName = model[0];// get attribute name
				var attrModel = model[1];
				for(var ename in attrModel){
					if(/^on[A-Z]/.test(ename) && typeof attrModel[ename] == "function"){
						var eventName = ename.substring(2).toLowerCase();
						if(instanceOf(input,wii.Input))
							input.removeEvent(eventName,attrModel[ename]);
						input.addEvent(eventName,attrModel[ename].bind(this));
					}
				}
				input.fireEvent("show",[null,input]);
			}
		}
	},
	/***
	 * find the nput model by it's name.
	 */
	findModel: function(inputName){
		var model=this.getModel();
		for(var p in model){
			if(inputName.endsWith(p))
				return [p,model[p]];
		}
	},
	/***
	 * get the input by it's name.
	 */
	getInput: function(name) {
		if(this.$inputs[name])
			return this.$inputs[name];
		var result=[];
		for(var p in this.$inputs){
			if(p.endsWith(name))
				result.push(this.$inputs[p]);
		}
		var l=0,j=0;
		if(result.length<=1)
			return result[0];
		for(var i=0;i<result.length;i++){
			if(l==0 || l>result[i].name.length){
				l=result[i].name.length;
				j=i;
			}
		}
		return result[j];
	},
	getModel: function(){
		return this.$constructor.model || {};
	}
});
/***
 * Jentity static methods
 */
Object.append(Jentity,{
	getElementValue: function(name){
		if(arguments.length>1)
			this.$inputs[name].value = arguments[1];
		return this.$inputs[name].get("value");
	},
	getCheckboxValue: function(name){
		if(arguments.length>1)
			return this.$inputs[name].checked = arguments[1];
		if(this.$inputs[name].checked)
			return this.$inputs[name].get('value');
		else 
			return "";		
	},
	getRadioValue: function(name,values){
		if(arguments.length>1)
			return this.$inputs[name].checked = arguments[1];
		if(this.$inputs[name].checked)
			return this.$inputs[name].get('value');
		else 
			return "";		
	},	
	getSelectValue: function(name,values){
		var e = this.$inputs[name];
		if(e.getSelected()){
			return e.getSelected()[0].value;
		}else
			return "";								
	},
	getElementHtml: function (name,values){
		if(arguments.length>1)
			this.$inputs[name].set('html',arguments[1])
		return this.$inputs[name].get('html').trim();
	},
	/***
	 * attach the data element to entity.
	 */
	attach : function(el,entity){
		entity = entity || this;
		el=$(el);
		entity.$inputs = entity.$inputs || {};
		el.getElements("input,select,textarea,td,span").each(function(e){
			var value;
			var getvalue=false;
			var name = e.name || e.getAttribute("name");
			if(!name) 
				return;
			switch(e.tagName){
			case 'INPUT' :
				switch(e.type){
				case 'text':
				case 'hidden':	
					entity.$inputs[name]=e;
					entity[name]=(function(){
						return Jentity.getElementValue.bind(this).call([name].concat(arguments));
					}).bind(entity);
					break;
				case 'checkbox':
					entity.$inputs[name]=e;
					entity[name]=(function(){
							return Jentity.getCheckboxValue.bind(this).call([name].concat(arguments));
						}).bind(entity);
					break;
				case 'radio':
					entity.$inputs[name]=e;
					entity[name]=(function(){
							return Jentity.getRadioValue.bind(this).call([name].concat(arguments));
						}).bind(entity);
					break;
				}
				break;
			case 'SELECT':
				entity.$inputs[name]=e;
				entity[name]=(function(){
						return Jentity.getSelectValue.bind(this).call([name].concat(arguments));						
					}).bind(entity);
				
				break;
			case 'TEXTAREA':
				entity.$inputs[name]=e;
				entity[name]=(function(){
					return Jentity.getElementValue.bind(this).call([name].concat(arguments));
				}).bind(entity);				
				break;
			case 'TD' :
			case 'SPAN':
				entity.$inputs[name]=e;
				entity[name]=(function(){
					return Jentity.getElementHtml.bind(this).call([name].concat(arguments));
				}).bind(entity);				
				break;
			}
		});
	}
});