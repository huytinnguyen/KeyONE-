/***
 * Jclass - Javascript Object Oriented Framework.
 * @version		2.1
 * @copyright	Copyright (c) 2003-2017 by NGUYEN S.n.c.
 * @license		MIT-style license
 */
/***
 * apply type enumeration
 */
Japply = {
	onlyFunction 	: 1,	// apply the origin functions
	onlyAttribute	: 2,	// apply the origin attributes 
	onlyIfAbsent	: 4,	// only if the property is not defined in destination object
	onlyIfDefined	: 8,	// only if the property is defined in destination object
	onlyIfNull		: 16,	// only if destination property is null
	onlyIfNotNull	: 32,	// only if the origin property is not null
	check			: 64,	// returns error if the property is not defined in destination object 
	merge			: 128	// merge origin with destination
};
// redefines typeof as function
if(!window['typeOf']) typeOf=function (o){ 
	return typeof o; 
};
/***
 * Functions to extend the generic object.
 */
Jobject={
  getterPrefix	: "get",
  setterPrefix	: "set",
  /** gli attributi riservati dell'oggetto generico di js */
  Keywords 	: {
	"constructor"	: true,
	"$constructor"	: true,
	"$class"		: true,	
	"$caller"		: true,	
	"$events"		: true,	
	"caller"		: true
  },
  // default object methods.
  Methods	: {
	/***
	 * returns the constructor of object.
	 */
	getClass : function() {
		return this.$class || this.$constructor || this.constructor;
	},	
	/***
	 * get the given attribute value.
	 * @param path attribute path.
	 * @param value default value if the value of the given attribute is null.
	 */
	get: function(path, value){
		if(!path) 
			return value;
		var properties={}, multi = path && typeof path == "object";
		if(multi)
			properties = path;
		else
			properties[path] = value;
		var object=this, name, propertyValue;
		for(var property in properties){
			if(!object) 
				break;
			path = property.split(".");
			propertyValue = properties[property];
			if(path.length>1 && object[property])
				object=object[property];
			else{
			  for(var i=0; i<path.length && object; i++){
				name = path[i];
				var getname = Jobject.getterPrefix + name.substring(0,1).toUpperCase() + name.substring(1,name.length);
				if(typeof object[getname] == "function"){
					value=object[getname].call(object);
				//}else if(name in object && (object[name] || !value)){
				}else if(typeof object[name] != 'undefined'){	
					value=object[name];	
				}else{
					value=propertyValue;
				}
				object=value;
			  }
			}
			if(multi && object && typeof(object) == "object" && 
			   propertyValue && typeof propertyValue == "object")
			{
				this.get.call(object,propertyValue);
			}else if(multi){
				properties[property]=object;
			}
		}
		return !multi? object: properties;
	},
	/***
	 * set the attribute's value.
	 * @param path attribute path
	 */
	set: function(path, value){
		var properties={};
		if(arguments.length == 1 && typeof arguments[0] == "object")
			properties=arguments[0];
		else
			properties[path]=value;
		for(var property in properties){
			path=property.split(".");
			value=properties[property];
			var object=this;
			var name;
			for(var i=0; i<path.length-1; i++){
				name=path[i];
				var getname=Jobject.getterPrefix+name.substring(0,1).toUpperCase()+name.substring(1,name.length);
				if(typeof object[getname] == "function")
					object=object[getname].call(object);
				else if(object[name])
					object=object[name];
				else {
					object[name]={};
					object=object[name];
				}
			}
			if(object){
				name=path[path.length-1];
				var setname=Jobject.setterPrefix+name.substring(0,1).toUpperCase()+name.substring(1,name.length);
				if(typeof object[setname] == "function")
					object[setname].call(object,value);
				else 
					object[name]=value;
			}		
		}
	}	
  },
  /***
   * converts the input object into an array.
   */
  splat  : function(obj){
	return obj ? (Jclass.isArray(obj) || (typeof obj != "string" && obj.length>0 && obj[0]) ? obj : [obj]) : [];
  },
  /***
   * copy the origin properties to the destination object.
   */
  apply	 : function(origin, dest, applyType, excluses){
	  origin = origin || {};
	  dest = dest || {};
	  var errors="";
	  for(var p in origin){
		  /** la propriet� � da escludere ? */
		  if(excluses && excluses[p]) continue;
		  /** � un attributo privato ? */
		  if(p.charAt(0) == "_") continue;
		  var toapply=errors.length==0;
		  if(applyType & Japply.onlyFunction && typeof origin[p] != "function") 
			  toapply=false;
		  if(applyType & Japply.onlyAttribute && typeof origin[p] == "function") 
			  toapply=false;
		  if(applyType & Japply.onlyIfAbsent && (p in dest)) 
			  toapply=false;
		  if(applyType & Japply.onlyIfNull && dest[p] && !origin[p]) 
			  toapply=false;
		  if(applyType & Japply.onlyIfNotNull && !origin[p]) 
			  toapply=false;
		  if((applyType & Japply.onlyIfDefined || applyType & Japply.check) && !(p in dest)){ 
			  if(applyType & Japply.check)
				  errors += "The property: '"+p+"' is not defined in the destination object!\n";
		  	  continue;
		  }
		  /** � da fare il merge ? */
		  if(applyType & Japply.merge && 
			 (!dest[p] || dest[p].constructor == Object) && 
			 (origin[p] && origin[p].constructor == Object))
		  {
		
			  dest[p]=dest[p] || {};
			this.apply(origin[p], dest[p], applyType, excluses);
		  }else if(toapply) {
			dest[p] = origin[p];
		  }
	  }
	  if(errors.length > 0)
		  throw new Error(errors);
	  return dest;
  },
  /***
   * extends a first object with the properties of next passed objects.
   * @param {Class/Object} clazz the class to be extended.
   * @params {Class/Object...} superclass the superclass
   */
  extend : function(clazz) {
	if(clazz){ 
		var applyType=0;
		for(var i=1; i<arguments.length; i++){
			if(typeof arguments[i] == "number"){
				applyType=arguments[i];
				i++;
			}
			arguments[i] && Jobject.apply.call(this, arguments[i], clazz, applyType, this.Keywords);
		}
	}
	return clazz;	
  },
  /***
   * get the attribute of given object.
   * @param {Object} object The object.
   * @param {String} name attribute name.
   * @param {Boolean} calljget call the get method of Jobject
   */
  get : function(object, name, calljget){
	  if(!calljget && typeof object.get=="function")
		  return object.get(name);
	  return Jobject.Methods.get.call(object,name);
  },
  /***
   * set the value of attribute.
   * @param {Object} object The object.
   * @param {String} name attribute path or name.
   * @param {Object} value new value of attribute.
   * @param {Boolean} calljset call the set method of Jobject
   */
  set: function(object,name,value, calljset){
	  if(!calljset && typeof object.set=="function")
		  return object.set(name,value);
	  return Jobject.Methods.set.call(object,name,value);
  },  
  /***
   * clone the given object.
   */
  clone	: function(obj,nodeep){
	  if(nodeep){
		  function Clone() {}
		  Clone.prototype=obj;
		  var clo=new Clone();
		  clo.constructor=obj.constructor;
		  return clo;
	  }else
		  return this.apply(obj, {}, Japply.merge);
  },
  /***
   * converts the input object in hash object.
   */
  toHash: function(object) {
  	var result={},toBeConverted=false;
  	for(var p in object){
  	   if(!Jclass.isPrimitive(object[p])){
  	     toBeConverted=true;
  	     break;
  	   }
  	}
  	if(!toBeConverted)
  		return object;
  	for(var p in object){
  		if(Jclass.isPrimitive(object[p])){
  			result[p]=object[p];
  		}else{
  			var nested=Jobject.toHash(object[p]);
  			for(var p2 in nested){
  				result[p+"."+p2]=nested[p2];
  			}
  		}
  	}
  	return result;
  },
  /***
   * converts the given object into query string.
   */
  toQueryString: function(object){
	  var query="";
	  for(var p in object){
		  if(typeof object[p] != "function"){
			  if(!object[p]){
				  if(query.length>0) query += "&";
				  query += p+"=";
			  }else if(Jclass.isPrimitive(object[p])){
				  if(query.length>0) query += "&";
				  query += p+"="+escape(object[p]+"");
			  }
		  }
	  }
	  return query;
  },
  /***
   * merge the first object with the second object, and then returns the second object.
   */
  merge : function(){
	  var result={};
	  var applyType=Japply.merge;
	  for(var i=0; i<arguments.length; i++){
		  if(arguments[i]){
			  if(typeof arguments[i] == "number"){
				  applyType = Japply.merge | arguments[i];
			  }else{
				  result=Jobject.apply(arguments[i],result,applyType);
			  }
		  }
	  }
	  return result;
  }  
};

/***
 * Trasforma Japply in una funzione di Jobject.apply.
 */
Japply=(function(){
	var japply=Japply;
	Japply=function() {
		return Jobject.apply.apply(Jobject,arguments);
	};
	Jobject.extend(Japply,japply);
	return Japply;
})();
/***
 * extends the native class Array
 */
Jobject.extend(Array.prototype, Japply.onlyIfAbsent, {
	add : function(){
		for(var i=0; i<arguments.length; i++)
			this.push(arguments[i]);
	}
});
/***
 * extends the native class Function
 */
Jobject.extend(Function.prototype, Japply.onlyIfAbsent, {
	/***
	 * return the super constructor of function
	 */
	getSuperClass: function(){
		return this.parent || this.superclass;
	},
	/***
	 * get the function / class name.
	 */
	getClassName : function(){
		if(!this.$className && !this.__parsedName){
			try {
			  if(!this.name){
				  var regex = /^function[ \t]+([a-zA-Z_\$][a-zA-Z_\$0-9]*)/;
				  var match=regex.exec(this.toString());
				  this.$className=match? match[1].replace(/\$/g,".") : "";
			  }else{
				  this.$className=this.name.replace(/\$/g,".");
			  }	  
			}catch(ex){
			  this.$className=this.name;
			}
			this.__parsedName=true;
		}
		return this.$className;
	},
	/***
	 * 
	 */
	isAssignableFrom: function(clazz) {
		return Jclass.isAssignableFrom(this,clazz);
	}	
});
/***
 * extends the String prototype.
 */
Jobject.extend(String.prototype, Japply.onlyIfAbsent,{
	/***
	 * trim the initial and final blanks.
	 */
	trim : function() { 
		return this.replace(/^\s+|\s+$/, ''); 
	}
});
/***
  Utility class for implementing class inheritance in Javascript.
    Usage:
	  <class-name> = new Class(options);
	Example:
	  MyClass = new Class({
	    $className: "MyClass",
	    Extends		: SuperClass,
	    Implements	: [ImplementedClass,...],
	    initialize	: function MyClass(name){ this.name=name; },
	    getName		: function(){ return this.name; }
	  });
*/
Jclass = function(options) {
	return Jclass.create(options);
};
if(!MooTools || !KeyJclass.options.useMooToolsClass){
  JClass = Jclass;
}else{
/***
 * Java script class.
 * @param options
 * @returns
 */
  (function(){
	  var JClass = this.JClass = new Type('JClass', function(params){
		  if (instanceOf(params, Function)) params = {initialize: params};
		  params.initialize = params.initialize || params.Constructor;
		  if(params.Constructor)
			  params.Constructor=null;
		  var newClass = new Class(params);
		  newClass.Implements = params.Implements;
		  Jobject.apply(Jobject.Methods, newClass.prototype, Japply.onlyIfAbsent);
		  return newClass;
	  }); 
  })();
}
/***
 * implements Jclass.
 */
Jobject.extend(Jclass, {
  // reserved words in class configuration.
  Keywords		: {
	"constructor"	: 1,
	superclass		: 2,
	Extends			: 3,
	Implements		: 4,
	$class			: 5,
	$className  	: 6,
	class$family	: 7,
	"caller"		: 8,
	$constructor	: 9,
	$caller			: 10	
  },
  /***
   * standard methods for an instance of a specified class.
   */
  Methods	: {
	  instanceOf : function(obj){
			return Jclass.instanceOf(obj,this);
	  },
	  /***
	   * return true if the current class is assignable from the specified class.
	   */
	  isAssignableFrom : function(from){
		  return Jclass.isAssignableFrom(this,from);
	  }
  },
  /***
   * @private
   * @param options
   */
  parse: function(options){
	  if(options.Extends && Jclass.isArray(options.Extends))
		  throw new Error("The superclass must be one: "+options.Extends+"!");
  },
  /**
     Creates a new class.  Adds instanceOf and supercall methods for type checking
     and accessing methods of super classes
          className: name of new class
          superclass: class that the new class will extend
          initialize : class constructor
  */
  create: function(options) {
	options = options && typeof options != "function" ?  options : {initialize: options};
	// check the class config
	this.parse(options);
	var superclasses = [];
	superclasses.push.apply(superclasses, Jobject.splat(options.Extends));
	superclasses.push.apply(superclasses, Jobject.splat(options.Implements));
	var $construct = options.Constructor || options.initialize ;
	// Create the class
	var clazz = $construct ||
		function() { 
			var self;
			if(this.initializer){ // for Jnative initializer (see initializer)
				self = this.initializer.apply(this,arguments);
			}else if(this.initialize) {// per essere compatibile con mootools
				self = this.initialize.apply(this,arguments);
			}
			if(self && self!=this) {
				// copy all attributes of this to self only if it's absent in self
				Jclass.applys(this, self, 0, {$class: 0, $constructor: 0}); // includes the attribute $class
				return self;
			}			
		};
	clazz.prototype.$constructor = clazz;
	clazz.$className = options['$className'] || clazz.getClassName();
	// 
	Jobject.extend(clazz, Jclass.Methods);
	// add super call
	clazz.prototype.parent = clazz.prototype.Super = Jclass.Super;
	// add class properties (attributes & methods)
	Jobject.extend.call(this, clazz.prototype, options);
	// If a superclass is given then inherit the prototype and set the
	// superclass property on the prototype.	
	this.extend.apply(this, [clazz].concat(superclasses));
	// adds object default methods (get & set).
	Jobject.apply(Jobject.Methods, clazz.prototype, Japply.onlyIfAbsent);
	// Returns the new class.
	return clazz;
  },
  /***
   * @private
   * super call.
   */
  Super : function(){
	  var clazz = this.constructor;
	  var caller = arguments.callee.caller;
	  var superclass= caller.getSuperClass();
	  if(superclass){
		  return superclass.apply(this,arguments);
	  }else{
		  var sup=clazz;
		  var name;
		  while(sup){
			if((name=Object.keyOf(sup.prototype,caller)) && (superclass=sup.getSuperClass())){
		      if(typeof superclass.prototype[name] == "function" && 
		    	 superclass.prototype[name]!=caller)
		      {
		    	return superclass.prototype[name].apply(this,arguments);
		      }
			}
		    sup = superclass;
		  }
		  
	  }
  },  
  /***
   * extends the first class with the next classes
   */
  extend : function(clazz){
	  var superclasses=arguments;
	  for(var i=1; i<superclasses.length; i++){
		  var yproto = Jclass.isFunction(superclasses[i]) ? superclasses[i].prototype : superclasses[i];
		  var applyType = Jclass.isFunction(superclasses[i]) ? Japply.onlyIfAbsent : 0;
		  if(Jclass.isFunction(superclasses[i])){
			  Jobject.apply(yproto, clazz.prototype, applyType, this.Keywords);
			  var yattrs=Jobject.apply(yproto,{},Japply.onlyAttribute, this.Keywords);
			  Jobject.apply(yattrs, clazz.prototype, applyType|Japply.merge, this.Keywords);
		  }else
			  Jobject.apply(yproto, clazz.prototype, 0, this.Keywords);
		  if(Jclass.isFunction(superclasses[i])) {
			  if(!clazz.parent){
				  clazz.parent = superclasses[i];
				  if(!("parent" in clazz.prototype)) 
					  clazz.prototype.parent = clazz.prototype.Super;
			  }else{
				  clazz.Implements = clazz.Implements || [];
				  clazz.Implements.push(superclasses[i]);
			  }		
		  }
	  }
  },
  /***
   * implements the given interfaces.
   */
  //implement: function(clazz){
	  //this.extend.apply(this,arguments);
  //},
  /** Returns true if the given object is an instance of the given class.
      JavaScript 1.5 has instanceof built in, but here is an implementation for older browsers
            obj: object to test
            clazz: class to test against
  */
  instanceOf: function(obj, clazz) {
	  if(obj==null)
		  return false;
	  if(obj instanceof clazz)
		  return true;
	  var objectClass = obj.$class || obj.$constructor || obj.constructor;
	  if(!objectClass)
		  return false;
	  return clazz.isAssignableFrom(objectClass);
  },
  /**
   * il metodo ritorna true se la prima classe e' assegnabile dalla seconda.
   */
  isAssignableFrom: function(clazz,fromClass){
	    if(!fromClass)
	    	return false;
	    var supers=[fromClass];
	    fromClass.Implements && fromClass.Implements.each(function(cls){supers.push(cls)});
	    for(var i=0; i < supers.length; i++){
	    	if(clazz == supers[i])
	    		return true;
	    	if(supers[i].getSuperClass() && this.isAssignableFrom(clazz,supers[i].getSuperClass()))
	    		return true;
	    }
		return false;  
  },     
  /** 
   * test if the input object is primitive 
   */
  isPrimitive: function(object){
    return (!object || object instanceof Date || typeof(object) == "string" || typeof(object) == "number");
  },
  /** test if the input object class is an array */
  isArray: function(object){
    return (object && object instanceof Array) || (object && typeof object != "string" && object.length>0 && object[0]);
  },
  /***
   * returns true if the passed object is a function.
   */
  isFunction : function(obj){
	  return typeof obj == "function";
  },
  /***
   * 
   */
  applys: function(origin, dest, applyType, excluses){
	  excluses = excluses || {};
	  Jobject.apply(this.Keywords,excluses);
	  Jobject.apply(origin, dest, applyType, excluses);
  }
});
/***
 * extends a native/external object.
 */
Jnative=function() {
	return Jnative.create.apply(Jnative, arguments);
};
/***
 * defines the prototype for Jnative
 */
Jobject.extend(Jnative,{
	create : function(){
		var args=Array.prototype.slice.call(arguments,0,arguments.length-2);
		var config = arguments[arguments.length-1] || {};
		if(config.constructor && !config.initializer){ 
			config.initializer = config.constructor;
		}
		config.constructor=null;
		args.push(config);
		var clazz=Jclass.create.apply(Jclass,args);
		return clazz;
	}
});

/****
 * extends Options
 */
Options.prototype.$setOptions = Options.prototype.setOptions;
Object.append(Options.prototype,{
  setOptions: function(options) {
	this.$setOptions(options);
	var assets = this.options.Assets || this.options.Imports || this.options.requires;
	if(assets){
		for(var type in assets){
			if(assets[type] && typeof Asset[type] == "function"){
			  var query="unknown";
			  switch(type){
			  case 'javascript':
				  query="script[src='{src}']";
				  break;
			  case 'css':
				  query="link[type='text/css'][href='{src}']";
				  break;
			  case 'image':
			  case 'images':	  
				  query="img[src='{src}']";
				  break;
			  }
			  var tpl=new Jtemplate(query);
			  Jobject.splat(assets[type]).each(function(source){
				if($$(tpl.apply({src:source})).length == 0)  
					Asset[type](source);
			  });
			}
		}
	}
  }
});

/***
 * extends URI class of MooTools.
 */
if (typeof MooTools != "undefined" || typeof URI == "function"){
  Jobject.extend(URI.prototype, {
	/***
	 * returns the host URL
	 * @returns {String}
	 */
	getHostURL : function() {
		return this.get("scheme")+"://"+this.get("host")+":"+this.get("port");
	},
	/***
	 * returns the context path of URI
	 * @returns
	 */
	getContextPath : function() {
		var path = this.getHostURL();
		var dir = this.get("directory"), j;
		if(this.get("scheme") != "file"){
			if(dir!="/" && (j=dir.indexOf("/",1))>0){
				dir = dir.substring(0,j);
			}else if(dir=="/" && this.get("file")!="")
				dir = dir + this.get("file");
		}
		return path+dir;
	}
  });
}
/***
 * Require class.
 */
Jrequire=new Class({
	Implements: [Options,Events],
	options 	: {
		javascript: [],
		css		  : [],
		image	  : [],
		onLoad	  : null
	},
	initialize	: function(options){
		this.setOptions(options);
		this.options.javascript=Jobject.splat(this.options.javascript);
		this.options.css=Jobject.splat(this.options.css);
		this.options.image=Jobject.splat(this.options.image);
		this.assetsToLoad=this.options.javascript.length+this.options.css.length+this.options.image.length;
		this.assetsLoaded=0;	
		this.loadAssets();
	},
	loadAssets: function(){
		this.loaded=0;
		this.toload=this.options.javascript.length; //+this.options.image.length;
		for(var assetType in this.options){
			switch(assetType){
			case 'javascript':
				this.options[assetType].each(function(js){
				  if(js){
					this[assetType]=this[assetType] || {};
					if(!this[assetType][js]){
					  this[assetType][js]="loading";
					  //this[assetType].loaded = this[assetType].loaded || 0;
					  Asset.javascript(js,{
						onLoad: this.onload.bind(this,[js,assetType])
					  });
					}else
					  this.loaded++;
				  }
				}.bind(this));
				break;
			case 'css':
			case 'image':
				if(assetType=='image'){
					
				}
				this.options[assetType].each(function(source){
					Asset[assetType](source,{
						onLoad: this.onload.bind(this,[source,assetType])
					});
				});
				break;
			}
		}
	},
	onload: function(source, assetType) {
		switch(assetType){
		case 'javascript':
			this.loaded++;
			this[assetType][source]="loaded";
			if(this.loaded==this.toload)
				this.fireEvent("load",[this]);
			break;
		}
	}
});
/***
 * extends Events
 */
Jobject.extend(Events.prototype, Japply.onlyIfAbsent, {
	hasEvent: function(type){
		return this.$events && this.$events[type] && this.$events[type].length>0; 
	}
});
