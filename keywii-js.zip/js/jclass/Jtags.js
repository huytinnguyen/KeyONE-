/***
 * Javascript Object Oriented Framework.
 * @version		2.1
 * @copyright	Copyright (c) 2003-2017, NGUYEN S.n.c.
 * @license		MIT-style license
 */
/**
 * @class Jevaluator
 * Expression evaluator class.
 */
Jevaluator = {
	//template	: "",
	defaultValue: "",	
	pattern		: "\\@\\{(.*?)\\}",
	matcher		: null,
	stack		: [window],
    compile: function (template) {
	  if(template instanceof Jtemplate)
		  return template;
	  var jtemplate=new Jtemplate(template,this.pattern);
	  if(!this.matcher)
		  this.matcher=jtemplate.matcher;
	  return jtemplate;
    },
    /**
     * replace the match with an object attribute value.
     */
	replaceMatch: function(match,objects,noDefValue){
    	var matcher = this.matcher.exec(match);
		var path = matcher? matcher[1] : match.substring(1,match.length-1);
		var object,getObject=false;
		for(var i=this.stack.length-1; i>=0; i++){
			//object=Jobject.get(this.stack[i],path);
			if(typeof Jobject.get(this.stack[i],path) != "undefined"){
				object=Jobject.get(this.stack[i],path);
				getObject=true;
				break;
			}
		}
		objects.push(object);
		if(getObject && (object || typeof object=="number")){
			return "{"+(objects.length-1)+"}";
		}else if(typeof Jobject.get(this.stack[i],path) == "undefined" && noDefValue )
			return match;
		else
			return this.defaultValue;
	},
	/***
	 * push a new element in variable stack.
	 * @param vars
	 */
	pushStack: function(vars){
		this.stack.push(vars);
	},
	/***
	 * removes a top element from variables stack.
	 */
	popStack: function(){
		this.stack.pop();
	},
	/***
	 * set the variable value.
	 * @param name variable name
	 * @param value variable value.
	 */
	setVar: function(name,value){
		this.stack[this.stack.length-1][name]=value;
	},
	/**
	 * Evaluate the values using the template string.
	 */
    eval: function(text,noDefValue) {
		var self=this;
		var tpl = this.compile(text);
		var objects=[];
		var result=tpl.template.replace(tpl.pattern, 
			function(match){
				return self.replaceMatch(match,objects,noDefValue)
			});
		if(objects.length==1 && typeof objects[0] == "object" && (result=="{0}"))
			return objects[0];
		else if(objects.length>0){
			tpl=new Jtemplate(result);
			return tpl.apply(objects);
		}
		return result;
    }
};
/***
 * extends Jtag.
 */
Jobject.extend(Jtag,{
	DO_START	: 1,
	DO_BODY		: 2,
	DO_END		: 3
});
/***
 * body tag class.
 * @class JbodyTag
 */
JbodyTag=new Class({
	Extends: Jtag,
	Implements: [Options],
	id	   : null,
	tagName: "div",
	options : {
		dynamicAttrs: true,
		binding : {
			id	: "id"
		}
	},
	Implements: [Options, Events, Jbinder],
	initialize : function(element,options) {
		this.setOptions(options);
		this.element=$(element);
		if(options && Jobject.getLength(options)>0)
			this.bind(this.options);
		else
			this.bind(this.element);
	},
	/***
	 * do start tag.
	 * @returns
	 */
	doStartTag: function(){
		try {
			return Jtag.DO_BODY;
		}catch(e){
			throw e;
		}
	},
	/***
	 * do end tag.
	 * @returns {Number}
	 */
	doEndTag: function(){
		try {
			return 0;
		}catch(e){
			throw e;
		}
	},
	/***
	 * do body tag.
	 * @returns
	 */
	doBodyTag: function(){
		try {
			return Jtag.DO_END;
		}catch(e){
			throw e;
		}
	},
	/***
	 * render the tag.
	 * @return
	 */
	render: function(){
		var status=Jtag.DO_START;
		while(status){
			switch(status){
			case Jtag.DO_START:
				status=this.doStartTag();
				break;
			case Jtag.DO_BODY:
				status=this.doBodyTag();
				break;
			case Jtag.DO_END:
				status=this.doEndTag();
				break;
			}
		}
		
	}
});