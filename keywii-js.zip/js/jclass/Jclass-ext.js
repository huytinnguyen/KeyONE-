/***
 * extends Jobject
 * @copyright	Copyright (c) 2003-2017 NGUYEN S.n.c.
 * @license		MIT-style license 
 */
if(!MooTools || !KeyJclass.options.useMooToolsClass){
Jobject.extend(Jobject,{
  /***
   * returns the length of object.
   */
  getLength: function(object){
	  var count=0;
	  for(var p in object){
		  if(typeof object[p] != "function")
			  count++;
	  }
	  return count;
  },  
  /***
   * appends the second object to the first object.
   */
  append: function(original){
		for (var i = 1, l = arguments.length; i < l; i++){
			var extended = arguments[i] || {};
			for (var key in extended) 
				original[key] = extended[key];
		}
		return original;
  },  
  /***
   * call the specified function on each attribute of the object.
   * @param object
   * @param fn
   * @param bind
   */
  each: function(object,fn,bind){
	  if(typeof fn == "function"){
		  if(bind)
			  fn=fn.bind(bind);
		  for(var p in object){
			  if(object[p]/* && typeof object[p]!="function"*/)
				  fn(object[p],p,object);
		  }
	  }	  
  },
  /***
   * return the subset that having the given properties.
   */
  subset: function(object, props){
	  var result={};
	  if(!props) return result;
	  for(var p in object){
		  if((Jclass.isArray(props) && props.indexOf(p)>=0) || p in props)
			  result[p]=object[p];
	  }
	  return result;
  },
  /***
   * for every property of the object.
   * @param object
   * @param fn
   * @param bind
   * @returns {Boolean}
   */
  every: function(object,fn,bind){
	  if(typeof fn == "function"){
		  var result=false;
		  if(bind)
			  fn=fn.bind(bind);
		  for(var p in object){
			  if(typeof object[p] != "function"){
				  result=fn(object[p],p,object);
				  if(!result)
					  return result;
			  }
		  }
		  return result;
	  }
  },
  /***
   * some property of object ?
   * @param object
   * @param fn
   * @param bind
   * @returns {Boolean}
   */
  some: function(object,fn,bind){
	  if(typeof fn == "function"){
		  var result=false;
		  if(bind)
			  fn=fn.bind(bind);
		  for(var p in object){
			  if(typeof object[p] != "function")
				  result=fn(object[p],p,object);
			  if(result)
				  return result;
		  }
		  return result;
	  }
  },
  /***
   * returns true if the given object contains the given value.
   */
  contains: function(object,value){
	  for(var p in object){
		  if(Jclass.isFunction(object[p])){ 
			  if(Jclass.isFunction(value) && value==object[p])
				  return true;		  
		  }else if((value || typeof value != "object") && value == object[p])
			  return true;
	  }
  },
  /***
   * returns property names of object.
   */
  keys: function(object){
	  var keylist=[];
	  for(var p in object)
		  keylist.push(p);
	  return keylist;
  },
  /***
   * return the values contained in object.
   */
  values: function(object){
	  var keylist=[];
	  for(var p in object)
		  keylist.push(object[p]);
	  return keylist;
  },  
  /***
   * returns the key of given object.
   */
  keyOf: function(object,value){
	  for(var p in object){
		  if(Jclass.isFunction(object[p])){ 
			  if(Jclass.isFunction(value) && value==object[p])
				  return p;
		  }else if((value || typeof value!="object") && value == object[p])
			  return p;
	  }
  },
  /***
   * returns the filtered properties.
   */
  filter: function(object,fn,bind){
	  var result={};
	  if(typeof fn == "function"){
		  if(bind)
			  fn.bind(bind);
		  for(var p in object){
			  if(fn(object[p],p,object))
				  result[p]=object[p];
		  }
	  }
	  return result;
  }   
});
/***
 * extends the native class Function
 */
Jobject.extend(Function.prototype, Japply.onlyIfAbsent, {
	/***
	 * @private
	 */
	builds: function(options){
		var self = this;
		options = options || {};
		return function(event){
			var args = Jobject.splat(options.arguments);
			args.push.apply(args,Array.slice(arguments, (options.event) ? 1 : 0));
			if (options.event) // args = [event || window.event].extend(args);
				args.splice(0,0,event || window.event);
			var returns = function(){
				var result= self.apply(options.scope || null, args);
				if(options.next) 
					options.next();
				return result;
			};
			if (options.delay) 
				return setTimeout(returns, options.delay);
			if (options.periodical) 
				return setInterval(returns, options.periodical);
			return returns();
		};
	},	
	/***
	 * binds the function with passed scope and arguments.
	 */
	bind : function (bind) {
		if (arguments.length <= 1 && !arguments[0]) 
			return this;
		var args=Array.slice(arguments,1);
		return this.builds({scope: bind, arguments: (args.length>0? args : undefined)});
	},
	/***
	 * chain with the passed function.
	 */
	chain: function(method){
		if(typeof method != "function") return this;
		var args=Array.slice(arguments,1);
		return this.builds({next: method.builds({arguments: args.length>0? args: undefined})});
	},
	/***
	 * run the function as a task at the specified time (ms).
	 * @param {ms} the delay time to run the function.
	 */
	delay : function(time, bind, args) {
		if(time <= 0) return this();
		//var args=Array.slice(arguments,2);
		return this.builds({delay: time, scope:bind, arguments: args})();
	},
	/***
	 * repeat the function periodically.
	 */
	periodical: function(period, bind, args){
		//var args=Array.slice(arguments,2);
		return this.builds({periodical: period, scope:bind, arguments: args})();
	}	
});
}
/***
 * extends Object class.
 */
if(!MooTools)
Jobject.extend(Object,Japply.onlyIfAbsent,{
	clone		: function(object){ return Jobject.clone(object); },
	merge		: function(){ return Jobject.merge.apply(Jobject,arguments); },
	getLength	: function(object){ return Jobject.getLength.apply(Jobject,arguments); },
	append		: function(){ return Jobject.append.apply(Jobject,arguments); },
	subset		: function(){ return Jobject.subset.apply(Jobject,arguments); },
	each		: function(){ return Jobject.each.apply(Jobject,arguments); },
	some		: function(){ return Jobject.some.apply(Jobject,arguments); },
	every		: function(){ return Jobject.every.apply(Jobject,arguments); },
	keys		: function(){ return Jobject.keys.apply(Jobject,arguments); },
	values		: function(){ return Jobject.values.apply(Jobject,arguments);},
	contains	: function(){return Jobject.contains.apply(Jobject,arguments); },
	keyOf		: function(){ return Jobject.keyOf.apply(Jobject,arguments); },
	filter		: function(){ return Jobject.filter.apply(Jobject,arguments); }
});
/***
 * 
 */
if(!MooTools/* || !KeyJclass.options.useMooToolsOptions*/){
/***
 * event handle class.
 */
Events = new Class({
	//Implements	: [Options],
	/***
	 * class constructor.
	 */
	initialize	: function(options){
		
	},
	/***
	 * returns true the object has given event.
	 */
	hasEvent: function(eventName){
		return this.$events && this.$events[eventName] && this.$events[eventName].length>0; 
	},
	/***
	 * add events.
	 * @return
	 */
	addEvents: function Events$addEvents(events,prefix){
		var me=this;
		Object.each(events,function(handle,eventName,events){
			if(typeof handle == "function"){
				if(prefix && eventName.indexOf(prefix)==0){
					var l=prefix.length;
					eventName=eventName.charAt(l).toLowerCase()+eventName.substring(l+1);
				}else if(prefix)
					eventName=null;
				if(eventName)	
					me.addEvent(eventName,handle);
			}
		});
		return this;
	},
	/***
	 * add new event listener.
	 * @param eventName - {String} event name
	 * @param handle - {function} event handle
	 * @param internal - (boolean, optional) Sets the function property: internal to true. 
	 *        Internal property is used to prevent removal.
	 * @return
	 */
	addEvent: function Events$addEvent(eventName, handle, internal){
		if(!this.$events)
			this.$events={};
		if(!this.$events[eventName])
			this.$events[eventName]=[];
		var i=this.$events[eventName].indexOf(handle);
		if(i<0)
			this.$events[eventName].push(handle);
		return this;
	},
	/***
	 * Fire the given event.
	 * @param eventName
	 * @param args
	 * @return
	 */
	fireEvent: function Events$fireEvent(eventName, args, delay){
		if(this.$events && this.$events[eventName]){
			this.$events[eventName].each(function(h){
				if(delay)
					h.delay(delay,h,args);
				else
					h.apply(h,args);
			});
		}
		return this;
	},
	/***
	 * remove the event listener.
	 */
	removeEvent: function(eventName, handle) {
		if(this.$events && this.$events[eventName]){
			var i=this.$events[eventName].indexOf(handle);
			if(i>=0)
				this.$events[eventName].splice(i,1);
		}
		return this;
	},
	/***
	 * remove all specified events.
	 * @param events {String|Object} the events to be removed.
	 * @return
	 */
	removeEvents: function Events$removeEvents(events){
		var me=this;
		if(this.$events){
			if(!events){
				this.$events=null;
			}else if(typeof events == "string"){
				if(this.$events[events])
					this.$events[events]=null;
			}else{
				Object.each(this.$events,function(f,n){
					me.removeEvent(n,f);
				});
			}
		}
		return this;
	}	
});
/***
 * @class Options
 * The class to specify the options of other class.
 */
Options=new Class({
	initialize : function(options){
		this.setOptions(options);
	},
	/***
	 * @private
	 * set the options for the class instance.
	 * @param {Object} options class options
	 */
	set$Options: function(options,check){
		if(options){
			this.options = Jobject.merge(this.options,{});
			var applyType = Japply.merge;
			if(check) 
				applyType = applyType | Japply.check;
			Jclass.applys(options,this.options, applyType);
		}
		if(Jclass.instanceOf(this,Events) || typeof this.addEvents == "function"){
			this.addEvents(this.options,"on");
		}
	},
	/***
	 * set object options.
	 * @param options
	 */
	setOptions: function(options){
		this.set$Options(options);
	}
});
// if not use MooTools
if(!MooTools){
	Options=Options;
	Events=Events;
}
//// no extends MooTools class.
}else{
	Events=Events;
	Jobject.extend(Events.prototype, Japply.onlyIfAbsent, {
		hasEvent: function(type){
			return this.$events && this.$events[type] && this.$events[type].length>0; 
		}
	});
	Options=Options;
}
