/***
 * Jclass - Javascript Object Oriented Framework.
 * @version		2.1
 * @copyright	Copyright (c) 2003-2017, NGUYEN S.n.c.
 * @license		MIT-style license
 */
/***
 * the function defines an package.
 * @param name package name
 * @return the package as simple object.
 */
Jnamespace = Jpackage = function (packageHead){
	var name=packageHead;
	var packageBody = null;
	if(packageHead.constructor == Object){
		name=packageHead.name;
		packageBody = packageHead;
	}
	var path=name.split(".");
	var object=window;
	for(var i=0;i<path.length;i++){
		if(!object[path[i]]){
			if(i == path.length-1){
				if(packageBody){
					object[path[i]]=new Jlibrary({Imports: packageBody.Imports});
					Jobject.extend(object[path[i]], Japply.onlyIfNotNull, packageBody);
					Jlibrary.put(object[path[i]]);
				}else
					object[path[i]]={};
			} else {
				object[path[i]]={};
			}
		}else{
			if(i == path.length-1){
				if(packageBody) {
					Jobject.extend(object[path[i]].tags, packageBody.tags || {});
					packageBody.tags=null;
					Jobject.extend(object[path[i]], Japply.onlyIfNotNull, packageBody);
				}
			}
		}
		object=object[path[i]];
	}
	var pack=object;	
	return pack;
};
/***
 * the javascript tag library.
 */
Jlibrary=new Class({
  Implements 	: [Options],
  TAGS			: {},
  tagCount		: 0,
  
  tags			: {},
  xmlns			: null,
  name			: null,
  options		: {
	  Imports : {
		  
	  }
  },
  /***
   * class constructor
   */
  initialize : function(options){
	  options = options || {};
	  options.Assets = options.Imports || {};
	  options.Imports = null;
	  this.setOptions(options);
  },
  /***
   * 
   * @param tags
   */
  addTags: function(tags){
	if(tags == null){
		tags=this.tags;
		this.tags = null;
	}
	tags = tags || {};  
	for(var tag in tags){
		if(!this.TAGS[tag]){
		  var tagClass=null;
		  if(typeof tags[tag] == "string" && typeof this[tags[tag]] == "function"){
			tagClass = this[tags[tag]];
		  }else if(typeof tags[tag] == "function"){
			tagClass = tags[tag];  
		  }
		  this.addTag({name: tag, tagClass: tagClass});
		}
	}
  },
  /***
   * imports the resource from server
   */
  require: function(options) {
	  
  },
  /***
   * initialize library
   */
  setup: function(){
	if(!this._initialized){
		this._initialized=true;
		this.addTags();
		//this.build();
	}
  },
  /***
   * get library URI
   * @returns
   */
  getUri: function() {
	  if(this.uri){
		  return this.uri;
	  }else if(this.xmlns && typeof this.xmlns == "object"){
		return this.xmlns.uri;  
	  }
  },
  /***
   * @private
   */
  getNSPrefix: function(node) {
	  node = node || $(document.body);
	  try {
		  for(var i=0; i<document.documentElement.length; i++){
			  var attrNode=document.documentElement.attributes[i];
			  if(attrNode.nodeName.indexOf("xmlns:")==0 && attrNode.nodeValue==this.getUri()){
				  return attrNode.nodeName.split(":")[1];
			  }	
		  } 
	  }catch(ex){}
	  return this.xmlns && typeof this.xmlns == "object" ? this.xmlns.prefix : this.xmlns;
  },
  /***
   * @private
   */
  /*
  hasNSPrefix: function(node,ns){
	  var nodeName=node.tagName;
	  if(!nodeName)
		  nodeName=node.nodeName;
	  if(Browser.ie && nodeName != "#text" && nodeName != "#document" &&
		 (!node.innerHTML || node.innerHTML == "" || nodeName in this.TAGS))
	  {
		  var text=node.outerHTML;
		  if(!text)
			  return false;
		  if(/^\<\?xml\:namespace/.test(text)){
			  var i=text.indexOf("/>");
			  text=text.substring(i+2);
		  }
		  var regexp=new RegExp("^[ \\t]*\\<"+ns+"\\:");
		  if(regexp.test(text)){
			  return true;
		  }
	  }else{
		  return nodeName.toLowerCase().indexOf(ns+":")==0;
	  }
  },*/
  /***
   * query the html nodes that have the namespace of given package.
   * @return array of found nodes.
   */
  /*
  getElementsByNS: function(node, fn, ns){
	  var nodes=[];
	  node = node || document;
	  var me=this;
	  var test = function(node,ns){
		  return ( me.hasNSPrefix(node,ns) && (!fn || fn(node,ns)) );
	  };
	  if(this.getUri()){
		  ns=this.getNSPrefix(node) || ns;
		  if(ns!=null){
			  ns=ns.toLowerCase();
			  if(test(node,ns)){
				  nodes.push($(node));
			  }
			  if(node.childNodes)
			  for(var i=0; i<node.childNodes.length; i++){
				  var childs=this.getElementsByNS(node.childNodes[i], fn, ns);
				  childs.each(function(e){nodes.push($(e));});
			  }
		  }
	  }
	  return nodes;
  },*/
  /***
   * @protected
   */
  getTag: function(tagName){
	 return this.TAGS[tagName]; 
  },
  /***
   * render the tags.
   * @param nodes
   */
  renderTags: function(nodes){
	  
  },
  /***
   * defines a widget tag type.
   */
  tag: function(name,type) {
	  if(typeof name=="object"){
		var options=name;
		return this.addTag(options);
	  }else {
	    var options={name: name, tagClass: type};
	    return this.addTag(options);
	  }
  },
  /**
   * @private
   * defines a js tag class.
   */
  addTag: function(options){
	  if(options && !options.library)
		  options.library=this;
	  var tag=new Jtag(options);
	  options.library.TAGS[tag.name]=tag;
	  return tag.getTagClass();
  },
  /***
   * return the identifier of given tag.
   * @private
   */
  getTagId: function(el) {
	  if(!el.id || el.id.length==0)
	    el.id=this.getNSPrefix(el)+"$TAG$"+(++this.tagCount);
	  return el.id;
  },
	/***
	 * create a new widget/instance of a class.
	 */
  newWidget: function(options){
		var classNames;
		if(!options['class'] || typeof options['class']=="string"){
			classNames=options['class'] || "widget";
			classNames=classNames.split(" ");
		}else {
			classNames=[options['class']];
		}
		var me=this;
		var el=(options.renderTo && $(options.renderTo)) || $(document.body);
		var xmlns=this.getNSPrefix(el);
		var widgets=[];
		classNames.each(function(name){
		  if(typeof name == "string"){
			  if(name.indexOf(xmlns+"-") == 0){
				  name=name.substring((xmlns+"-").length);
			  }
			  var tag=me.getTag(name),wtype,widget;
			  if(tag && (wtype=tag.getTagClass())){
				  widget = new wtype(options);
				  widgets.push(widget);
			  }
		  }else if(typeof name == "function"){ // element della lista di classi e' una funzione
			  var wtype=name;
			  widget = new wtype(options);
			  widgets.push(widget);			  
		  }
		});
		return widgets;
  }
});
/***
 * Jlibrary's static methods.
 */
Object.append(Jlibrary,{
	libraries: {},
	//buildall : true,
	put		 : function(library){
		this.libraries[library.name]=library;
	}, 
	/***
	 * build all tags defined in libraries.
	 */
	build: function(node, query){
		this.buildTags(node,query);
	},
	/***
	 * @private
	 */
	setup: function() {
		  for (var libname in this.libraries){
			var library=this.libraries[libname];
			var hasTags = Object.getLength(library.TAGS)>0 || Object.getLength(library.tags)>0;
			if(library.xmlns && library.xmlns.prefix && hasTags && library.setup){
				library.setup();
			}
		  }
	},
	  /***
	   * build the widgets in the document.
	   */
	buildTags: function(parent, query) {
		  parent = parent || document;
		  this.setup();
		  //var nodes=[];
		  //if(query)
		  var nodes= this.$$(query,parent);
		  if(nodes.length>0)
			  this.buildElements(nodes);			  
	},
	/***
	 * find library by prefix of the class name.
	 */
	findLibrary: function(className){
		for (var libname in this.libraries){
			var library=this.libraries[libname];
			if(className.indexOf(library.xmlns.prefix+"-")==0){
				return library;
			}
		}
	},
	  /***
	   * @private
	   */
	buildElements: function(els) {
		  var xmlns;
		  els=Jobject.splat(els);
		  //var me=this;
		  for(var i=0; i<els.length; i++){
			try{
			  el=els[i];
			  if(!el || el.$class) // if the element is built, go to the next element.
				  continue;
			  //xmlns=xmlns || this.getNSPrefix(el);
			  var nodeName=el.nodeName.toLowerCase();
			  if(el.renderer)
				  continue;
			  var lib;
			  if(!this.getLibraryByNS){ //if(!(lib=this.getLibraryByNS(el))){
				  var path = el.className.split(" ");
				  for(var j=0; j<path.length; j++){
					  var className=path[j].trim();
					  var name = className;
					  lib = this.findLibrary(className);
					  xmlns = lib && lib.xmlns && lib.xmlns.prefix;
					  var options = {};
					  if(xmlns){
						var options_ = el.getAttribute(xmlns+":options");
						if(options_)
							options = JSON.decode(options_);
					  }
					  if(lib){
						  name = name.substring((xmlns+"-").length);
						  var nsName = xmlns+":"+name;
						  //if(!el.retrieve(className)){
						  var tag = lib.getTag(name), type;
						  type = tag ? tag.getTagClass() : null;
						  if(tag && type 
							 && (!el.retrieve(className) 
								 || !(el.retrieve(className) instanceof type)))
						  {
							  var opt = (el.get(nsName) && JSON.decode(el.get(nsName)))
						  			 	|| (el.get(className) && JSON.decode(el.get(className)))
						  			 	|| (el.retrieve(className))
						  			 	|| (el.retrieve(nsName))
						  			 	|| options[className] || options;
							  
							  var widget=new type(el,opt);
							  // save as principal renderer
							  el.renderer = el.renderer || widget;
							  el.store(className,widget);
							  if(el.get(className) && KeyJclass.options.hideWidgetOptions)
								  el.set(className,"");
							  if(Jclass.instanceOf(widget,JbodyTag))
								  widget.render();						  
							  el.$class = type;
						  }
						  //}
					  }
				  }		  
			  }
			}catch(ex){
			  alert (ex.message);
			  throw ex;
			}
		  }
		  return els;
	},
	/***
	 * 
	 */
	/*
	getLibraryByNS: function(node){
		for (var libname in this.libraries){
			var library=this.libraries[libname];
			if(library.hasNSPrefix(node,library.xmlns.prefix))
				return library;
		}
	},*/
	  /***
	   * widget auto builder
	   */
	
	$$: function(query,node) {
		  node = node || document;
		  var qry = query || "";
		  var els;
		  
		  if(typeof qry == "string" && qry == ""){
			els=[];
			for (var libname in this.libraries){
		      var library=this.libraries[libname];
		      var xmlns=library.xmlns && library.xmlns.prefix;
			  if(xmlns && library.getUri()){
			    for(var p in library.TAGS){
				  toBuild=true;
				  if(qry.length>0)
					  qry += ", ";
				  qry += "."+xmlns+"-"+p;
			    }
				//els.append(library.getElementsByNS(node));
			  }
			  $(node).getElements(qry).each(function(el){els.push(el);});
			}
		  } else {
			  if(typeof qry=="string")
				  els=$(node).getElements(qry);
			  else
				  els=qry;
		  }
		  return els;
	  }	
	  
});

window.addEvent("domready",function(){
	Jlibrary.build(document);
});

/***
 * The tag class.
 * @class
 */
Jtag=new Class({
	library		: null,
	name		: null,
	htmlTag		: "DIV",
	tagClass	: null,
	initialize : function Jtag(options){
		Japply(options,this,Japply.check);
		if(!this.getTagClass()){
			throw Error(new Jtemplate("The tag class of the tag: {name} must be defined!").apply(this));
		}
	},
	/***
	 * returns the tag class.
	 */
	getTagClass: function() {
		return this.tagClass;
	}
});
