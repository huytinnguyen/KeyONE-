/***
 * Jclass - Javascript Object Oriented Framework.
 * @version		2.1
 * @copyright	Copyright (c) 2003-2017 by NGUYEN S.n.c.
 * @license		MIT-style license
 */
KeyJclass={
	name		: "KeyJclass",
	title		: 'KeyONE+ Javascript object oriented Framework',
	version		: 2.1,
	prefix		: "keyjs",
	'@company'	: "NGUYEN S.n.c.",
	'@copyright': 'Copyright (C) 2003-2017, NGUYEN S.n.c.',
	'@license'	: "MIT-style license",
	options		: {
		useMooToolsClass	: true,
		useMooToolsOptions	: true,
		hideWidgetOptions 	: true
	}
};
/**
 * @enum JlogType
 * Log severity type 
 */
JlogType={
  DEBUG:1,
  INFO: 2,
  WARN: 3,
  ERROR:4,
  FATAL:5
};
/*** 
 * Jlogger class
 * @class Jlogger 
 */
function Jlogger(level){
	this.level=level || this.level;
}
/***
 * Log methods & attribute.
 */
Jlogger.prototype={
  level		: JlogType.WARN,
  /** writes a log message. */
  log	: function(severity, message){
    if(severity>=this.level){
      switch(severity){
        case JlogType.DEBUG : alert(message); break;
      	case JlogType.INFO 	: window.status=(message); break;      		              		        
        case JlogType.WARN 	: alert(message); break;
        case JlogType.ERROR : alert(message); break;
        case JlogType.FATAL : alert(message); break;      		
      }
    }
  },
  debug	: function(message){this.log(JlogType.DEBUG,message);},
  info	: function(message){this.log(JlogType.INFO,message);},
  warn	: function(message){this.log(JlogType.WARN,message);},
  error	: function(message){this.log(JlogType.ERROR,message);},
  fatal	: function(message){this.log(JlogType.FATAL,message);}        
};
