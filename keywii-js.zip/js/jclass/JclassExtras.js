/***
 * Jclass - Javascript Object Oriented Framework.
 * @version		2.1
 * @copyright	Copyright (c) 2003-2017, NGUYEN S.n.c.
 * @license		MIT-style license
 */
/***
 * Principal data types.
 */
JdataType={		
	JSON		: 0,
	ARRAY		: 1,
	XML			: 2,
	BEAN		: 3,
	PRIMITIVE	: 4,
	OBJECT		: 5
	
};
/**
 * @class Jtemplate
 * La classe template di stringa.
 */
Jtemplate = new Class({
	template	: "",
	defaultValue: "",	
	matcher		: "\\{(.*?)\\}",
	dataType	: JdataType.JSON,
	
	/**
	 * Il metodo crea un template di stringa. Per esempio:
	 *   var template=new Jtemplate(
	 * 		 "il valore di element/@name e' ${element/@name}",/(\$\{(.*?)\})/g,JdataType.XML);
	 * @param {String} template e' la stringa di template.
	 * @param {RegExpr} pattern e' il pattern per riconoscere i riferimenti alle variabili
	 *        all'interno della stringa di template.
	 * @param {JdataType} dataType tipo del dato.
	 */
    initialize : function Jtemplate(template, pattern) {
	  if(template instanceof Jtemplate)
		  return template;
	  pattern = pattern || this.matcher;
  	  if(typeof template == 'string' || Jclass.isArray(template)){
  		if(Jclass.isArray(template))
  			template=template.join("\n");
    	this.template = template;
  	  }else if(typeof template == "object"){
  		Jclass.applys(template,this);
  	  }
  	  this.matcher = new RegExp(pattern);
  	  this.pattern = new RegExp(pattern,"g");
    },
    /***
     * get type of the passed object
     * @private
     */
    typeOf: function(object){
		var dataType=this.dataType;
		if(Jclass.isArray(object))
			dataType=JdataType.ARRAY;
		else if(object.ownerDocument && object.nodeName)
			dataType=JdataType.XML;
		else if(!object.$class && typeof object.get == "function")
			dataType=JdataType.BEAN;
		return dataType;
    },
    /**
     * replace the match with an object attribute value.
     */
	replaceMatch: function(match,object){
    	var matcher = this.matcher.exec(match);
		var nameMatch = matcher? matcher[1] : match.substring(1,match.length-1);
		nameMatch = nameMatch.split('=');
		var name=nameMatch[0];
		var node, value, defValue = this.defaultValue;
		if(nameMatch.length>1)
			defValue=nameMatch[1];
		var dataType = this.typeOf(object);
		switch(dataType){
		case JdataType.JSON:
			if(name==".")
				value=object;
			else
				value=Jobject.get(object,name);
			if (typeof value == "number" && !value)
				defValue="0";
			return value || defValue;
		case JdataType.ARRAY:
			value = object[name];
			if (typeof value == "number" && !value)
				defValue="0";
			return value || defValue;
		case JdataType.XML:
			node=object.selectSingleNode(name);
			value = (node)!=null? node.nodeValue : defValue;
			return value;
		case JdataType.BEAN:
			value = object.get(name);
			if (typeof value == "number" && !value)
				defValue="0";
			return value || defValue;
		default:
			return match;
		}
	},
	/**
	 * Evaluate the values using the template string.
	 */
    apply: function(object) {
		var self=this;
		var result=this.template.replace(this.pattern, 
			function(match){
				return self.replaceMatch(match,object)
			});
		return result;
    }
});
/***
 * La classe gestisce la comunicazione col server via javascript. La risposta verra pressa attraverso
 * una funcione di callback.
 */
Jscript=new Class({
	Implements	: [Options,Events],
	options		: (JscriptOptions={
		id				: null,
		src				: null,
		url				: null,
		data			: null,
			
		nsPrefix		: "js:",
		AcceptKey		: "Acpt",
		onSuccessKey	: "clbk",
		onFailureKey	: "oner",
		updateDateKey	: "upd"
	}),
	/***
	 * costruttore della classe
	 */
	initialize : function(element,opts) {
    	var el=element;
    	var options = opts || {};
	
		if(arguments.length==1 && el && el.constructor==Object){
			options=el;
			el = options.target || options.renderTo || options.applyTo;
		}
		this.setOptions(options);
		//this.addEvents(options);
		var me=this;
		Object.each(options, function(func,name,object){
			if(/^on/.test(name)){
				var event=name.charAt(2).toLowerCase()+name.substring(3);
				me.addEvent(event,func);
			}
		});
		if(el){
			this.element=$(el);
		}
		this.isDynamic=!this.element;
	},
	/***
	 * send the request to server and get the response by the callback function.
	 */
	load: function(params) {
		var script = this.element || document.createElement("script");
		var uri = new URI(this.options.src||this.options.url);
		var url=this.options.src;
		if(params && params.url){
			var newuri=new URI(params.url,{base: uri});
			url=(newuri.toString());
			this.options.src=url;
		}
		
		var sep=url.indexOf("?")>0? "&" : "?";
		var self=this;
		var scriptId=this.options.id || Jscript.getScriptId();;
		var callbackName=Jscript.getCallbackId(scriptId);
		window[callbackName]=function (response) {  
			self.fireEvent("success",[response]);
			self.close();
			window[callbackName]=null;
		};	
		var data={};
		data[this.getOnSuccessKey()]=callbackName;
		data[this.getAcceptKey()]="text/javascript";
		data[this.getUpdateDateKey()]=(new Date()).format("%xT%X");
		url += sep+Jobject.toQueryString(data);
		
		var data2=params && params.data;
		if(params && !params.data && !params.url && !params.src)
			data2=params;
		if(data2)
			url += "&"+Jobject.toQueryString(data2);
		
		script.setAttribute("id",scriptId);
		script.setAttribute("type","text/javascript");
		script.setAttribute("src",url);
		if(!this.element){
			$(document.body).appendChild(script);
		}
		this.element=$(script);
	},
	/***
	 * returns ns prefix.
	 * @returns
	 */
	getNsPrefix: function() {
		return this.options.nsPrefix;
	},
	/***
	 * returns Accept Key
	 * @returns
	 */
	getAcceptKey: function(){
		return this.options.nsPrefix+this.options.AcceptKey;
	},
	/***
	 * returns onSuccess Key
	 * @returns
	 */
	getOnSuccessKey: function(){
		return this.options.nsPrefix+this.options.onSuccessKey;
	},
	/***
	 * returns onFailure key
	 * @returns
	 */
	getOnFailureKey: function(){
		return this.options.nsPrefix+this.options.onFailureKey;
	},
	/***
	 * returns updateDate key
	 * @returns
	 */
	getUpdateDateKey: function() {
		return this.options.nsPrefix+this.options.updateDateKey;
	},
	/***
	 * returns the script element.
	 */
	getElement: function() {
		return this.element;
	},
	/***
	 * close the script loader and destroy the created element.
	 */
	close: function() {
		if(this.isDynamic && this.getElement()){
			var parent=this.getElement().parentNode;
			parent.removeChild(this.getElement());
			this.element=null;
		}
	}
});
/***
 * Jscript static methods.
 */
Jobject.extend(Jscript,{
	callbackPrefix	: "$cbk",
	counter 		: 0,
	/***
	 * generates the script id.
	 */
	getScriptId		: function() {
		var index= ++this.counter;
		return "_JS$"+(index);
	},
	/***
	 * generates the callback id for a script.
	 */
	getCallbackId	: function(scriptId) {
		return scriptId+this.callbackPrefix;
	},
	/***
	 * search the SCR of the specified script
	 * @param scriptName
	 */
	findScripts: function(scriptName){
		var src;
		$(document).getElements("script").each(function(script){
			if(script.src.indexOf(scriptName)>=0)
				src=script.src;
		});
		return src;
	}
});
/***
 * Html loader. It has the same options of the class: Request of Mootools.
 */
Jloader=new Class({
	Implements	: [Options,Events],
	isHtmlLoader: true,
	/***
	 * loader options
	 */
	options		: (JloaderOptions={
		autoLoad 	: true,
		useFrame	: false,		
		load		: {
			evalScripts	: true,
			onSuccess	: null,
			onFailure	: null,
			encodeNestedData	: false
		}
	}),
	/***
	 * 
	 * @param args
	 */
	parseArguments: function(args){
		return Jloader.parseArguments(args);
	},			
	/***
	 * Class constructor.
	 * @param el
	 * @param options
	 * @return
	 */
	initialize : function Jloader(element,opts) {
		var args=this.parseArguments(arguments);
	    var el=args.element;
		var options=args.options;
		this.setOptions(options);
		this.options.onSuccess=options.onSuccess;
		this.options.onFailure=options.onFailure;
		if(el)
			this.element=$(el);
		if(this.getLoader() && this.options.autoLoad)
			this.load();
	},
	/***
	 * returns the html element.
	 */
	getElement: function(query) {
		if(!query)
			return this.element;
		else
			return this.element.getElement(query);
	},
	/***
	 * returns the body element of widget.
	 */
	getContent: function(){
		return this.getElement();
	},	
	/***
	 * returns the html element.
	 */
	getElements: function(query) {
		if(!query || query.length==0)
			query="*";
		return this.getElement().getElements(query);
	},		
	/***
	 * get the html loader
	 * @private
	 */
	getLoader: function(options){
		
		var myuri=new URI();
		if(!this.loader /*|| options*/){
		  options = options || {};
		  if(!options.data && !options.url && !options.src)
			 options={data: options};
			
		  options = Jobject.merge(this.options.load,options);
		  if(options.url || options.src){
			var uri=new URI(options.url || options.src);
			if(myuri.getHostURL() == uri.getHostURL()){
				var onSuccess=options.onSuccess;
				var onFailure=options.onFailure;
				typeof onSuccess == "function" && this.addEvent("load", onSuccess);
				typeof onFailure == "function" && this.addEvent("failure", onFailure);
				
				options.onSuccess=function(responseTrees,responseElements, responseHtml, responseScripts){
					var response={
						type	: Request,
						trees: responseTrees,
						elements: responseElements,
						html: responseHtml,
						scripts: responseScripts
					};
					this.onLoad(response);
					//this.fireEvent("load",arguments);
				}.bind(this);
				options.onFailure=this.onFailure.bind(this);
				options.onLoadstart=this.onLoadstart.bind(this);
				if(this.options.load.encodeNestedData)
				for(var p in options.data){
					if(options.data[p] && options.data[p].constructor==Object)
						options.data[p]=JSON.encode(options.data[p]);
				}
				this.getContent().set("load",options);
				this.loader=this.getContent();
			}else if(!this.options.useFrame){
				this.loader=new Jscript(options);
				this.isHtmlLoader=false;
				this.isScriptLoader=true;
			}else{
				  var iframe;
				  if(this.getContent().tagName != 'IFRAME'){
					  iframe=this.getContent().getElements("IFRAME")[0];					  
					  if(!iframe){
						  var frametext= this.options.iframe || 
							  "<iframe frameborder='no' style='border:none;width:100%;height:100%;'></iframe>";
						  this.getContent().set("html",frametext);
						  iframe=this.getContent().firstChild;
					  }
				  }else{
					  iframe = this.getContent();
				  }
				  var src = options.src || options.url;
				  var sep = src.indexOf("?")>0 ? "&" : "?";
				  if(options.data){
					  src += sep+Jobject.toQueryString(options.data);
				  }
				  iframe.src = src;
				  this.loader=iframe;				  								
			}
		  }
		}
		return this.loader;
	},
	/***
	 * 
	 * @param response
	 */
	onLoad: function(response){
		//this.fireEvent("load",[response]);
	},
	/***
	 * 
	 * @param xhr
	 */
	onFailure: function(xhr){
		this.fireEvent("failure",[xhr]);
	},
	/***
	 * 
	 * @param ev
	 * @param xhr
	 */
	onLoadstart: function(ev,xhr){
		this.fireEvent("loadstart",[ev,xhr]);
	},
	/***
	 * returns true if the element has html loader. 
	 */
	hasLoader: function(){
		return this.options.load && (this.options.load.url || this.options.load.src);
	},
	/***
	 * load the resource from server.
	 */
	load: function(params){
		var options={};
		params = params || {};
		if(params.url || params.src){
			options=params;
			options.data = options.data || {};
		}else
			options.data=params;
		options.data = Object.merge(Object.clone(this.options.load.data || {}), options.data);
		options.url = options.url || this.options.load.url;
		var loader=this.getLoader(options);
		if(loader){
			if(loader.tagName!='IFRAME'){
				var htmlload=loader.get("load");
				if(this.options.load.encodeNestedData){
					for(var p in options.data){
						if(options.data[p] && options.data[p].constructor==Object)
							options.data[p]=JSON.encode(options.data[p]);
					}
				}
				if(htmlload.options.url != options.url){
					loader.set("load",options);
				}				
				loader.load(options.data);  
			}else{
				var url=options.src || options.url;
				if(!url)
					url=loader.src;
				var sep=url.indexOf("?")>0? "&" : "?";
				if(options.data)
					url += sep + Jobject.toQueryString(options.data);
				loader.src=url;
			}
		}
	},
	/***
	 * evaluates scripts
	 */
	evalScripts: function(scripts,i){
		var me=this;
		var baseURI = new URI(this.options.load.src || this.options.load.url);
		if(i<scripts.length){
			var sc = scripts[i];
			if(sc.src && sc.src.length>0){
				var uri=new URI(sc.src,{base: baseURI});
				var script=new Element("script");
				script.setAttribute("type","text/javascript");
				script.setAttribute("src",uri.toString());
				script.addEvent("load", function(){
					me.evalScripts(scripts,i+1);
				});
				try{
					script.replaces(sc);
				}catch(e){
					me.evalScripts(scripts,i+1);
				}
			}else{
				var script = new Element("script");
				script.setAttribute("type","text/javascript");
				script.set("text", sc.text);
				try {
				  script.replaces(sc);
				}catch(e){
				}
				this.evalScripts(scripts,i+1);
			}				    
		}
	}
	
});
/***
 * Jloader static methods.
 */
Object.append(Jloader,{
	/***
	 * parse the constructor arguments
	 * @param args
	 */
	parseArguments: function(args){
		var argv={};
		for(var i=0; i<2 && i < args.length;i++){
    		if(args[i] && args[i].constructor==Object){
    			argv.options=args[i];
    		}else{
    			argv.element=args[i];
    		}			
		}
		argv.options = argv.options || {};
		argv.element = argv.element || argv.options.element || argv.options.renderTo;
		return argv;
	}	
});
/***
 * extends Mootools Element.
 */
Jelement=new Jnative({
  initialize : function(el) {
	el=$(el);
	for(var f in Jelement.Methods)
	  if(typeof Jelement.Methods[f] == "function" && !(f in el))
		el[f]=Jelement.Methods[f].methodize();
	return el;
  }
});
/***
 * Jelement static methods.
 */
Jelement.Methods={
  decodeEntities: function(encodedString){
	var textArea = document.createElement('textarea');
	textArea.innerHTML = encodedString;
	return textArea.value;
  },
  /***
   * converts the html element in data.
   */
  toData: function(el,tojson){
	el=$(el);
	var data={};
	var object={};
	var results={};
	el.getElements("input,select,textarea,td,span").each(function(e){
		var value;
		var getvalue=false;
		if((!e.name || e.name.length==0) && (!e.getAttribute("name") || e.getAttribute("name").length == 0)) 
			return;
		switch(e.tagName){
		case 'INPUT' :
			switch(e.type){
			case 'text':
			case 'hidden':	
				value=e.get('value');
				getvalue=true;
				break;
			case 'checkbox':
				if(e.checked){
					value=e.value;
					getvalue=true;
				}
				break;
			case 'radio':
				if(e.checked){
					value=e.value;
					getvalue=true;
				}
				break;
			}
			break;
		case 'SELECT':
			if(e.getSelected()){
				value=e.getSelected()[0].value;
			}else
				value="";
			getvalue=true;
			break;
		case 'TEXTAREA':
			value=e.value;
			getvalue=true;
			break;
		case 'TD' :
			value=Jelement.decodeEntities(e.get("html")).trim();
			getvalue=true;
			break;
		case 'SPAN':
			value=Jelement.decodeEntities(e.get("html")).trim();
			getvalue=true;
			break;			
		}
		if(getvalue){
			var name=e.name || e.getAttribute("name");
			if(tojson){
				var subname=name;
				var parsedName=Jbean.parseName(name);
				if(parsedName[0].type.code=="NAME" && /^[0-9]+$/.test(parsedName[0].text)){
					subname = parsedName[1].text + parsedName.slice(2,parsedName.length).join("");
					object = results[parsedName[0].text];
					if(object == null)
						object = results[parsedName[0].text]={};
				}else{
					object = results[results.length];
					if(object==null)
						object = results[results.length] = {};
				}
				var path=Jbean.parseName(subname);
				var subobject=object;
				for(var i=0; i<path.length;i++){
					if(i<path.length-1){
						if(subobject[path[i].text]==null){
							subobject[path[i].text]={};
						}
						subobject = subobject[path[i].text];
					}else
						subobject[path[i].text]=value;
				}
			}else
				data[name]=value;
		}
	});
	if(tojson){
		if(Object.getLength(results)==1){
			for(var p in results){
				return results[p];
			}
		}else
			return results;
	}else
		return data;
  }
};
Jobject.extend(Jelement, Jelement.Methods);
/***
 * expression
 */
JsqlExpr={
		CompareOperators	: ['>=','>','<=','<','=','<>','!=','like '],
		LogicOperators		: ['and','or','not'],
		ArithmeticOperators	: ['+','-','/','*']
};
/***
 * add the method endsWith to String.
 */
if (!String.prototype.endsWith) {
	  String.prototype.endsWith = function(searchString, position) {
	      var subjectString = this.toString();
	      if (typeof position !== 'number' || !isFinite(position) || Math.floor(position) !== position || position > subjectString.length) {
	        position = subjectString.length;
	      }
	      position -= searchString.length;
	      var lastIndex = subjectString.lastIndexOf(searchString, position);
	      return lastIndex !== -1 && lastIndex === position;
	  };
}
if (!String.prototype.startsWith) {
    String.prototype.startsWith = function(searchString, position){
      position = position || 0;
      return this.substr(position, searchString.length) === searchString;
  };
}